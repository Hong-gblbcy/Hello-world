# 寻找 dlib.h
find_path(dlib_INCLUDE_DIR dlib.h PATHS ${DLIB_INSTALL_PATH}/include)
message(STATUS "dlib_INCLUDE_DIR: ${dlib_INCLUDE_DIR}")

# 寻找 libdlib.so
find_library(dlib_LIBRARY dlib PATHS ${DLIB_INSTALL_PATH}/lib)
message(STATUS "dlib_LIBRARY: ${dlib_LIBRARY}")

# 设置 dlib_FOUND 
if(dlib_INCLUDE_DIR AND dlib_LIBRARY)
    set(dlib_FOUND TRUE)
    set(dlib_VERSION 1.0.0)
    set(dlib_AUTHOR "kaka")

    get_filename_component(dlib_LIBRARY_DIR ${dlib_LIBRARY} DIRECTORY) # 方便安装时，查找库文件
endif()
