#include <iostream>
#include "dlib.h"

int main()
{
    std::cout << "Hello world!" << std::endl;
    dlib();
    return 0;
}