cmake -S . -B build -DCMAKE_INSTALL_PREFIX=./installed -DDLIB_INSTALL_PATH=../custom_mod/install
cmake --build build
cmake --install build