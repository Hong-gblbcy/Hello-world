cmake -S ./custom_mod -B ./custom_mod/build -DCMAKE_INSTALL_PREFIX=./custom_mod/install
cmake --build ./custom_mod/build
cmake --install ./custom_mod/build