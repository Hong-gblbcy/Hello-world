cmake -S . -B build -DCMAKE_INSTALL_PREFIX=./installed
cmake --build build
cmake --install build

