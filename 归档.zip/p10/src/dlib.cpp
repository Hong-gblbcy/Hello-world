#include "dlib.h"
#include <iostream>

void dlib()
{
    std::cout << "dlib" << std::endl;
}