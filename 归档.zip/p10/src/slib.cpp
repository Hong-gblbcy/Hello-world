#include "slib.h"
#include <iostream>

void slib()
{
    std::cout << "slib" << std::endl;
}