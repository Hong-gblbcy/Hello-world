#include <iostream>
#include "dlib.h"
#include "slib.h"

int main()
{
    std::cout << "Hello, world!" << std::endl;
    dlib();
    slib();
    return 0;
}