rm -rf ./build
rm -rf ./installed