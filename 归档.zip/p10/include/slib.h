#ifndef SLIB_H
#define SLIB_H
void slib();
#endif