#include <iostream>
#include <gflags/gflags.h>
DEFINE_string(name, "", "name of the person");
DEFINE_int32(age, 0, "age of the person");
int main(int argc, char **argv)
{
    gflags::ParseCommandLineFlags(&argc, &argv, true);
    std::cout << "name: " << FLAGS_name << std::endl;
    std::cout << "age: " << FLAGS_age << std::endl;
    return 0;
}