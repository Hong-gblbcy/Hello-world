#include <iostream>
#include "slib.h"
#include "dlib.h"
int main()
{
    std::cout << "main" << std::endl;
    slib();
    dlib();
    return 0;
}