rm -rf ./build
rm -rf ./install_demo