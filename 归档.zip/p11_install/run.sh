cmake -S . -B build -DCMAKE_INSTALL_PREFIX=./install_demo
cmake --build build
cmake --install build