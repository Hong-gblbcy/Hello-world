-- 监控报警平台初始化数据脚本
-- 插入默认管理员用户 (密码: admin123)
INSERT INTO users (username, email, hashed_password, full_name, role, is_active) VALUES
('admin', 'admin@example.com', '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', '系统管理员', 'admin', TRUE),
('operator1', 'operator1@example.com', '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', '操作员1', 'operator', TRUE),
('viewer1', 'viewer1@example.com', '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', '查看员1', 'viewer', TRUE);

-- 插入示例项目
INSERT INTO projects (name, description, owner_id, is_active) VALUES
('总部大楼监控', '公司总部大楼的安防监控系统', 1, TRUE),
('生产车间监控', '生产车间的设备监控和安全监控', 1, TRUE),
('仓库区域监控', '仓库区域的货物安全和环境监控', 1, TRUE);

-- 插入区域数据
INSERT INTO areas (name, description, project_id, parent_area_id, location, is_active) VALUES
-- 总部大楼区域
('大楼入口', '主入口监控区域', 1, NULL, '{"floor": "1", "coordinates": {"x": 100, "y": 50}}', TRUE),
('大厅', '接待大厅监控区域', 1, NULL, '{"floor": "1", "coordinates": {"x": 150, "y": 100}}', TRUE),
('办公区', '员工办公区域', 1, NULL, '{"floor": "2", "coordinates": {"x": 200, "y": 150}}', TRUE),
('会议室', '会议室监控', 1, 3, '{"floor": "2", "coordinates": {"x": 220, "y": 170}}', TRUE),

-- 生产车间区域
('装配线A', '产品装配线A区域', 2, NULL, '{"workshop": "A", "coordinates": {"x": 50, "y": 30}}', TRUE),
('装配线B', '产品装配线B区域', 2, NULL, '{"workshop": "A", "coordinates": {"x": 150, "y": 30}}', TRUE),
('质检区', '产品质量检测区域', 2, NULL, '{"workshop": "B", "coordinates": {"x": 100, "y": 100}}', TRUE),

-- 仓库区域
('A区货架', 'A区货物存放架', 3, NULL, '{"zone": "A", "coordinates": {"x": 10, "y": 10}}', TRUE),
('B区货架', 'B区货物存放架', 3, NULL, '{"zone": "B", "coordinates": {"x": 60, "y": 10}}', TRUE),
('出入口', '仓库出入口监控', 3, NULL, '{"zone": "ENTRANCE", "coordinates": {"x": 35, "y": 50}}', TRUE);

-- 插入摄像头数据
INSERT INTO cameras (name, description, area_id, rtsp_url, ip_address, port, username, password, model, status, is_active) VALUES
-- 总部大楼摄像头
('入口摄像头1', '主入口监控', 1, 'rtsp://192.168.1.101:554/stream', '192.168.1.101', 554, 'admin', 'password123', 'Hikvision DS-2CD2342WD-I', 'online', TRUE),
('大厅摄像头1', '大厅全景监控', 2, 'rtsp://192.168.1.102:554/stream', '192.168.1.102', 554, 'admin', 'password123', 'Hikvision DS-2CD2342WD-I', 'online', TRUE),
('办公区摄像头1', '办公区监控', 3, 'rtsp://192.168.1.103:554/stream', '192.168.1.103', 554, 'admin', 'password123', 'Dahua IPC-HFW1230S', 'online', TRUE),
('会议室摄像头1', '会议记录', 4, 'rtsp://192.168.1.104:554/stream', '192.168.1.104', 554, 'admin', 'password123', 'Dahua IPC-HFW1230S', 'offline', TRUE),

-- 生产车间摄像头
('装配线A摄像头1', '装配过程监控', 5, 'rtsp://192.168.2.101:554/stream', '192.168.2.101', 554, 'admin', 'password123', 'Hikvision DS-2CD2342WD-I', 'online', TRUE),
('装配线B摄像头1', '装配过程监控', 6, 'rtsp://192.168.2.102:554/stream', '192.168.2.102', 554, 'admin', 'password123', 'Hikvision DS-2CD2342WD-I', 'online', TRUE),
('质检摄像头1', '质量检测监控', 7, 'rtsp://192.168.2.103:554/stream', '192.168.2.103', 554, 'admin', 'password123', 'Hikvision DS-2CD2342WD-I', 'online', TRUE),

-- 仓库摄像头
('货架A摄像头1', '货物安全监控', 8, 'rtsp://192.168.3.101:554/stream', '192.168.3.101', 554, 'admin', 'password123', 'Dahua IPC-HFW1230S', 'online', TRUE),
('货架B摄像头1', '货物安全监控', 9, 'rtsp://192.168.3.102:554/stream', '192.168.3.102', 554, 'admin', 'password123', 'Dahua IPC-HFW1230S', 'online', TRUE),
('出入口摄像头1', '出入口安全监控', 10, 'rtsp://192.168.3.103:554/stream', '192.168.3.103', 554, 'admin', 'password123', 'Hikvision DS-2CD2342WD-I', 'online', TRUE);

-- 插入用户项目权限
INSERT INTO user_project_permissions (user_id, project_id, can_view, can_edit, can_delete, can_manage_users) VALUES
-- 管理员拥有所有权限
(1, 1, TRUE, TRUE, TRUE, TRUE),
(1, 2, TRUE, TRUE, TRUE, TRUE),
(1, 3, TRUE, TRUE, TRUE, TRUE),

-- 操作员1可以查看和编辑项目1和2
(2, 1, TRUE, TRUE, FALSE, FALSE),
(2, 2, TRUE, TRUE, FALSE, FALSE),

-- 查看员1只能查看项目1
(3, 1, TRUE, FALSE, FALSE, FALSE);

-- 插入用户区域权限
INSERT INTO user_area_permissions (user_id, area_id, can_view, can_edit, can_delete) VALUES
-- 管理员拥有所有区域权限
(1, 1, TRUE, TRUE, TRUE),
(1, 2, TRUE, TRUE, TRUE),
(1, 3, TRUE, TRUE, TRUE),
(1, 4, TRUE, TRUE, TRUE),
(1, 5, TRUE, TRUE, TRUE),
(1, 6, TRUE, TRUE, TRUE),
(1, 7, TRUE, TRUE, TRUE),
(1, 8, TRUE, TRUE, TRUE),
(1, 9, TRUE, TRUE, TRUE),
(1, 10, TRUE, TRUE, TRUE),

-- 操作员1可以查看和编辑生产车间区域
(2, 5, TRUE, TRUE, FALSE),
(2, 6, TRUE, TRUE, FALSE),
(2, 7, TRUE, TRUE, FALSE),

-- 查看员1只能查看总部大楼区域
(3, 1, TRUE, FALSE, FALSE),
(3, 2, TRUE, FALSE, FALSE),
(3, 3, TRUE, FALSE, FALSE),
(3, 4, TRUE, FALSE, FALSE);

-- 插入示例报警数据
INSERT INTO alerts (title, description, camera_id, area_id, project_id, alert_level, alert_status, alert_source, metadata) VALUES
('移动检测报警', '检测到未授权移动', 1, 1, 1, 'warning', 'pending', 'camera', '{"detection_type": "motion", "confidence": 0.85}'),
('设备离线', '摄像头连接中断', 4, 4, 1, 'warning', 'processing', 'camera', '{"offline_duration": "2h", "last_online": "2024-01-20T10:00:00"}'),
('高温报警', '环境温度过高', 5, 5, 2, 'critical', 'pending', 'external', '{"temperature": 45.6, "threshold": 40.0}'),
('货物移动', '检测到货物异常移动', 8, 8, 3, 'warning', 'resolved', 'camera', '{"movement_direction": "left", "object_size": "large"}');

-- 插入通知配置
INSERT INTO notification_configs (user_id, notification_type, config, is_active) VALUES
(1, 'email', '{"email": "admin@example.com", "preferences": {"critical": true, "warning": true, "info": false}}', TRUE),
(1, 'sms', '{"phone": "+8613800138000", "preferences": {"critical": true, "warning": false, "info": false}}', TRUE),
(2, 'email', '{"email": "operator1@example.com", "preferences": {"critical": true, "warning": true, "info": false}}', TRUE),
(3, 'email', '{"email": "viewer1@example.com", "preferences": {"critical": false, "warning": true, "info": true}}', TRUE);

-- 插入审计日志示例
INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details, ip_address) VALUES
(1, 'login', 'user', 1, '{"success": true}', '192.168.1.100'),
(1, 'create', 'project', 1, '{"name": "总部大楼监控"}', '192.168.1.100'),
(2, 'login', 'user', 2, '{"success": true}', '192.168.1.101'),
(3, 'view', 'camera', 1, '{"camera_name": "入口摄像头1"}', '192.168.1.102');