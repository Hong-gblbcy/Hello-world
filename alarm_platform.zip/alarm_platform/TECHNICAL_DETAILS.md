# 监控报警平台技术详细文档

## 📋 目录
1. [API路由详细说明](#api路由详细说明)
2. [文件调用关系图](#文件调用关系图)
3. [数据库表结构关系](#数据库表结构关系)
4. [核心代码流程分析](#核心代码流程分析)
5. [权限系统详细说明](#权限系统详细说明)
6. [完整依赖关系](#完整依赖关系)

## API路由详细说明

### 1. 认证API (`/api/auth/*`)

#### POST `/api/auth/login`
- **功能**: 用户登录
- **请求体**: `{"username": "string", "password": "string"}`
- **响应**: JWT Token
- **调用链**: 
  - `app/api/auth.py` → `app/services/auth.py` → `app/core/security.py`
  - 验证用户凭据 → 生成JWT Token → 返回认证信息

#### POST `/api/auth/register`
- **功能**: 用户注册
- **请求体**: UserCreate Schema
- **响应**: 创建的用户信息
- **权限**: 仅超级管理员

#### GET `/api/auth/me`
- **功能**: 获取当前用户信息
- **权限**: 需要认证
- **调用**: `app/services/auth.py.get_current_user()`

### 2. 项目管理API (`/api/projects/*`)

#### GET `/api/projects`
- **功能**: 获取项目列表
- **查询参数**: `skip`, `limit`, `search`
- **权限**: 需要认证，查看权限范围内的项目
- **调用链**: API → PermissionService → Database

#### POST `/api/projects`
- **功能**: 创建新项目
- **权限**: 超级管理员或项目创建权限
- **调用**: `app/services/permission.py.can_create_project()`

#### GET `/api/projects/{project_id}`
- **功能**: 获取项目详情
- **权限**: 项目查看权限
- **调用**: `app/services/permission.py.can_view_project()`

#### PUT `/api/projects/{project_id}`
- **功能**: 更新项目信息
- **权限**: 项目管理员或超级管理员
- **调用**: `app/services/permission.py.can_edit_project()`

#### DELETE `/api/projects/{project_id}`
- **功能**: 删除项目
- **权限**: 超级管理员
- **级联删除**: 关联的区域、摄像头、报警记录

### 3. 区域管理API (`/api/areas/*`)

#### GET `/api/areas`
- **功能**: 获取区域列表
- **查询参数**: `project_id`, `skip`, `limit`
- **权限**: 区域查看权限
- **调用**: `app/services/permission.py.get_accessible_areas()`

#### POST `/api/areas`
- **功能**: 创建区域
- **权限**: 项目管理员
- **验证**: 父区域必须存在且属于同一项目

#### GET `/api/areas/{area_id}`
- **功能**: 获取区域详情
- **包含**: 父区域信息、子区域列表、摄像头列表

#### PUT `/api/areas/{area_id}`
- **功能**: 更新区域信息
- **权限**: 区域管理员或项目管理员

#### DELETE `/api/areas/{area_id}`
- **功能**: 删除区域
- **权限**: 项目管理员
- **级联删除**: 子区域、摄像头、报警记录

### 4. 摄像头管理API (`/api/cameras/*`)

#### GET `/api/cameras`
- **功能**: 获取摄像头列表
- **查询参数**: `area_id`, `project_id`, `status`
- **权限**: 摄像头查看权限

#### POST `/api/cameras`
- **功能**: 创建摄像头
- **权限**: 区域管理员
- **验证**: 区域必须存在且用户有权限

#### GET `/api/cameras/{camera_id}`
- **功能**: 获取摄像头详情
- **包含**: 区域信息、项目信息、报警历史

#### PUT `/api/cameras/{camera_id}`
- **功能**: 更新摄像头信息
- **权限**: 摄像头管理员或区域管理员

#### DELETE `/api/cameras/{camera_id}`
- **功能**: 删除摄像头
- **权限**: 区域管理员
- **级联删除**: 关联的报警记录

### 5. 报警管理API (`/api/alerts/*`)

#### GET `/api/alerts`
- **功能**: 获取报警列表
- **查询参数**: `camera_id`, `area_id`, `project_id`, `status`, `severity`
- **权限**: 报警查看权限
- **调用**: `app/services/permission.py.get_accessible_alerts()`

#### POST `/api/alerts`
- **功能**: 创建报警记录
- **权限**: 系统自动触发或授权用户
- **流程**: 创建报警 → 发送通知 → 记录审计日志

#### GET `/api/alerts/{alert_id}`
- **功能**: 获取报警详情
- **包含**: 摄像头信息、处理人员、时间线

#### PUT `/api/alerts/{alert_id}`
- **功能**: 更新报警状态
- **权限**: 报警处理权限
- **状态流转**: 待处理 → 处理中 → 已解决/已关闭

#### DELETE `/api/alerts/{alert_id}`
- **功能**: 删除报警记录
- **权限**: 超级管理员或项目管理员

### 6. 审计日志API (`/api/audit-logs/*`)

#### GET `/api/audit-logs`
- **功能**: 获取审计日志列表
- **查询参数**: `user_id`, `action_type`, `target_type`, `start_time`, `end_time`
- **权限**: 超级管理员

#### GET `/api/audit-logs/{log_id}`
- **功能**: 获取审计日志详情
- **包含**: 操作用户、操作目标、操作详情

## 文件调用关系图

### 核心调用关系

```
main.py
├── 加载配置 (config.py)
├── 创建数据库引擎 (database.py)
├── 注册中间件 (audit_middleware.py)
├── 包含API路由:
│   ├── auth.py
│   ├── projects.py
│   ├── areas.py
│   ├── cameras.py
│   ├── alerts.py
│   └── audit_logs.py
└── 启动应用
```

### API路由调用关系

```
API路由文件 (如 auth.py)
├── 导入依赖:
│   ├── FastAPI Depends
│   ├── SQLAlchemy AsyncSession
│   ├── Pydantic Schemas
│   ├── 服务层 (auth.py, permission.py)
│   └── 模型层 (user.py)
├── 定义路由端点
├── 参数验证 (Pydantic Schemas)
├── 权限检查 (PermissionService)
├── 业务处理 (各种Service)
└── 数据库操作 (SQLAlchemy Models)
```

### 服务层调用关系

```
AuthService
├── 依赖: Database Session, Security utils
├── 方法: login, register, get_current_user
└── 调用: User模型操作

PermissionService
├── 依赖: Database Session, Current User
├── 方法: 各种权限检查方法
└── 调用: User, Project, Area, Camera模型

NotificationService
├── 依赖: Database Session, PermissionService
├── 方法: send_alert_notification
└── 调用: 获取相关人员，发送通知

AuditLogService
├── 依赖: Database Session
├── 方法: create_log, get_logs
└── 被: 中间件和各个Service调用
```

## 数据库表结构关系

### 1. 用户表 (users)
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    is_superadmin BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 2. 项目表 (projects)
```sql
CREATE TABLE projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_by INTEGER REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 3. 用户项目角色表 (user_project_roles)
```sql
CREATE TABLE user_project_roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'viewer')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, project_id)
);
```

### 4. 区域表 (areas)
```sql
CREATE TABLE areas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    parent_id INTEGER REFERENCES areas(id) ON DELETE SET NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 5. 用户区域权限表 (user_area_permissions)
```sql
CREATE TABLE user_area_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    area_id INTEGER REFERENCES areas(id) ON DELETE CASCADE,
    permission_level VARCHAR(20) NOT NULL CHECK (permission_level IN ('admin', 'viewer')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, area_id)
);
```

### 6. 摄像头表 (cameras)
```sql
CREATE TABLE cameras (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    stream_url VARCHAR(255) NOT NULL,
    area_id INTEGER REFERENCES areas(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'online' CHECK (status IN ('online', 'offline', 'maintenance')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 7. 报警表 (alerts)
```sql
CREATE TABLE alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id INTEGER REFERENCES cameras(id) ON DELETE CASCADE,
    triggered_by INTEGER REFERENCES users(id),
    handled_by INTEGER REFERENCES users(id),
    description TEXT NOT NULL,
    severity VARCHAR(20) DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'resolved', 'closed')),
    triggered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    handled_at DATETIME,
    resolved_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 8. 审计日志表 (audit_logs)
```sql
CREATE TABLE audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id),
    action_type VARCHAR(50) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_id INTEGER,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 9. 区域管理员通知表 (area_admin_notifications)
```sql
CREATE TABLE area_admin_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    area_id INTEGER REFERENCES areas(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    notification_type VARCHAR(50) NOT NULL,
    is_enabled BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(area_id, user_id, notification_type)
);
```

## 核心代码流程分析

### 1. 用户登录流程
```python
# app/api/auth.py
@router.post("/login")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    # 调用AuthService进行认证
    user = await AuthService.authenticate_user(db, form_data.username, form_data.password)
    # 生成访问令牌
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}

# app/services/auth.py
class AuthService:
    @staticmethod
    async def authenticate_user(db: AsyncSession, username: str, password: str):
        # 查询用户
        user = await db.execute(select(User).filter(User.username == username))
        user = user.scalar_one_or_none()
        # 验证密码
        if not user or not verify_password(password, user.password_hash):
            raise HTTPException(status_code=400, detail="用户名或密码错误")
        return user
```

### 2. 权限检查流程
```python
# app/services/permission.py
class AsyncPermissionService:
    async def can_view_project(self, user: User, project_id: int) -> bool:
        # 超级管理员有所有权限
        if user.is_superadmin:
            return True
        
        # 检查用户项目角色
        stmt = select(UserProjectRole).where(
            UserProjectRole.user_id == user.id,
            UserProjectRole.project_id == project_id
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none() is not None
```

### 3. 报警创建流程
```python
# app/api/alerts.py
@router.post("", response_model=AlertResponse)
async def create_alert(
    alert_data: AlertCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # 权限检查
    permission_service = AsyncPermissionService(db)
    if not await permission_service.can_create_alert(current_user, alert_data.camera_id):
        raise HTTPException(status_code=403, detail="没有权限创建报警")
    
    # 创建报警记录
    alert = Alert(**alert_data.dict(), triggered_by=current_user.id)
    db.add(alert)
    await db.commit()
    await db.refresh(alert)
    
    # 发送通知
    await NotificationService.send_alert_notification(db, alert)
    
    # 记录审计日志
    await AuditLogService.create_log(
        db, current_user, "create", "alert", alert.id, f"创建报警: {alert.description}"
    )
    
    return alert
```

### 4. 审计中间件流程
```python
# app/middleware/audit_middleware.py
async def audit_middleware(request: Request, call_next):
    # 跳过某些路径
    if request.url.path in ["/docs", "/redoc", "/openapi.json"]:
        return await call_next(request)
    
    # 获取用户信息
    user = await get_user_from_request(request)
    
    # 处理请求
    response = await call_next(request)
    
    # 记录审计日志
    if user:
        await AuditLogService.create_log(
            request.app.state.db,
            user,
            request.method,
            "request",
            None,
            f"{request.method} {request.url.path} - {response.status_code}"
        )
    
    return response
```

## 权限系统详细说明

### 权限层级结构
```
超级管理员 (is_superadmin = True)
    ├── 所有项目的完全权限
    ├── 所有区域的完全权限  
    ├── 所有摄像头的完全权限
    └── 系统管理功能

项目管理员 (user_project_roles.role = 'admin')
    ├── 指定项目的管理权限
    ├── 创建/删除区域
    ├── 分配区域权限
    └── 查看项目所有内容

区域管理员 (user_area_permissions.permission_level = 'admin')
    ├── 指定区域的管理权限
    ├── 创建/删除摄像头
    ├── 处理区域报警
    └── 查看区域所有内容

普通用户 (viewer权限)
    ├── 查看权限范围内的内容
    └── 需要明确授权才能操作
```

### 权限检查方法
```python
# app/services/permission.py 中的核心方法
class AsyncPermissionService:
    async def can_view_project(self, user: User, project_id: int) -> bool
    async def can_edit_project(self, user: User, project_id: int) -> bool
    async def can_view_area(self, user: User, area_id: int) -> bool
    async def can_edit_area(self, user: User, area_id: int) -> bool
    async def can_view_camera(self, user: User, camera_id: int) -> bool
    async def can_edit_camera(self, user: User, camera_id: int) -> bool
    async def can_view_alert(self, user: User, alert_id: int) -> bool
    async def can_handle_alert(self, user: User, alert_id: int) -> bool
    
    # 获取用户可访问的资源列表
    async def get_accessible_projects(self, user: User) -> List[Project]
    async def get_accessible_areas(self, user: User, project_id: Optional[int] = None) -> List[Area]
    async def get_accessible_cameras(self, user: User, area_id: Optional[int] = None) -> List[Camera]
    async def get_accessible_alerts(self, user: User, filters: Dict = None) -> List[Alert]
```

## 完整依赖关系

### Python包依赖
```python
# requirements.txt 主要依赖
fastapi==0.104.1
uvicorn[standard]==0.24.0
sqlalchemy==2.0.23
aiosqlite==0.19.0
asyncpg==0.29.0
passlib[bcrypt]==1.7.4
python-jose[cryptography]==3.3.0
python-multipart==0.0.6
pydantic==2.5.0
pydantic-settings==2.1.0
python-dotenv==1.0.0
httpx==0.25.2
pytest==7.4.3
pytest-asyncio==0.21.1
```

### 模块间依赖关系

```
app/main.py
├── 依赖: app.core.config
├── 依赖: app.core.database
├── 包含: 所有API路由
└── 注册: 中间件

app/core/config.py
├── 依赖: pydantic_settings
├── 依赖: python-dotenv
└── 被: main.py, services, API路由引用

app/core/database.py
├── 依赖: sqlalchemy.ext.asyncio
├── 提供: get_db依赖注入
└── 被: 所有需要数据库的模块引用

app/core/security.py
├── 依赖: passlib, python-jose
├── 提供: 密码哈希和JWT功能
└── 被: auth服务引用

API路由文件
├── 依赖: 对应的Schemas
├── 依赖: 对应的Services
├── 依赖: 权限服务
└── 使用: 数据库会话

服务层文件
├── 依赖: 数据库会话
├── 依赖: 权限服务(互相引用)
├── 依赖: 对应的Models
└── 被: API路由引用

模型层文件
├── 依赖: sqlalchemy.orm
└── 被: 服务层和数据库操作引用

Schemas文件
├── 依赖: pydantic
└── 被: API路由引用
```

## 🎯 核心设计模式

### 1. 依赖注入模式
```python
# 数据库会话依赖
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

# 在API路由中使用
@router.get("/projects")
async def get_projects(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 使用注入的依赖
    projects = await ProjectService.get_projects(db, current_user)
    return projects
```

### 2. 服务层模式
```python
# 业务逻辑集中在服务层
class ProjectService:
    @staticmethod
    async def get_projects(db: AsyncSession, user: User):
        # 权限检查
        accessible_projects = await PermissionService.get_accessible_projects(user)
        # 业务逻辑处理
        return accessible_projects
```

### 3. 中间件模式
```python
# 审计日志中间件
@app.middleware("http")
async def audit_middleware(request: Request, call_next):
    # 前置处理
    start_time = time.time()
    
    # 调用下一个中间件或路由
    response = await call_next(request)
    
    # 后置处理
    processing_time = time.time() - start_time
    # 记录日志等操作
    return response
```

### 4. 仓储模式(Repository Pattern)
```python
# 数据访问封装
class UserRepository:
    @staticmethod
    async def get_by_username(db: AsyncSession, username: str) -> Optional[User]:
        result = await db.execute(select(User).filter(User.username == username))
        return result.scalar_one_or_none()
    
    @staticmethod
    async def create_user(db: AsyncSession, user_data: Dict) -> User:
        user = User(**user_data)
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user
```

## 🔧 配置管理系统

### 环境配置层级
```
1. 环境变量 (最高优先级)
2. .env文件
3. 默认配置 (config.py)
```

### 核心配置类
```python
# app/core/config.py
class Settings(BaseSettings):
    # 数据库配置
    DATABASE_URL: str = "sqlite+aiosqlite:///./test.db"
    
    # JWT配置
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # 应用配置
    DEBUG: bool = False
    
    class Config:
        env_file = ".env"
        case_sensitive = True
```

## 📊 性能优化策略

### 1. 数据库优化
```python
# 使用selectinload避免N+1查询问题
async def get_project_with_areas(db: AsyncSession, project_id: int):
    stmt = select(Project).options(
        selectinload(Project.areas).selectinload(Area.cameras)
    ).where(Project.id == project_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()
```

### 2. 缓存策略
```python
# 简单的内存缓存示例
from functools import lru_cache

@lru_cache(maxsize=128)
async def get_cached_user(db: AsyncSession, user_id: int):
    return await UserRepository.get_by_id(db, user_id)
```

### 3. 批量操作
```python
# 批量插入数据
async def bulk_create_users(db: AsyncSession, users_data: List[Dict]):
    users = [User(**data) for data in users_data]
    db.add_all(users)
    await db.commit()
```

## 🚨 错误处理机制

### 全局异常处理
```python
# 自定义异常类
class PermissionDeniedError(HTTPException):
    def __init__(self, detail: str = "权限不足"):
        super().__init__(status_code=403, detail=detail)

# 异常处理器
@app.exception_handler(PermissionDeniedError)
async def permission_denied_handler(request: Request, exc: PermissionDeniedError):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail}
    )
```

### 验证错误处理
```python
# Pydantic自动验证
@router.post("/users")
async def create_user(user_data: UserCreate):
    # 自动验证UserCreate schema
    # 如果验证失败，FastAPI会自动返回422错误
    user = await UserService.create_user(user_data)
    return user
```

## 🔄 数据流示例

### 创建报警的完整数据流
```
1. 客户端 → POST /api/alerts (报警数据)
2. API路由 → 验证AlertCreate Schema
3. API路由 → 调用PermissionService检查权限
4. PermissionService → 查询数据库验证权限
5. API路由 → 调用AlertService创建报警
6. AlertService → 插入报警记录到数据库
7. AlertService → 调用NotificationService发送通知
8. NotificationService → 查询相关用户
9. NotificationService → 调用PermissionService获取项目管理员
10. NotificationService → 记录通知发送
11. AlertService → 调用AuditLogService记录操作
12. API路由 → 返回AlertResponse
13. 中间件 → 记录请求审计日志
```

## 📈 监控和日志

### 结构化日志
```python
import logging
import json
from pythonjsonlogger import jsonlogger

# 配置JSON格式日志
logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter()
handler.setFormatter(formatter)
logger.addHandler(handler)

# 使用示例
logger.info("用户登录成功", extra={
    "user_id": user.id,
    "username": user.username,
    "ip_address": request.client.host
})
```

### 性能监控
```python
# 简单的性能监控装饰器
import time
from functools import wraps

def track_performance(func):
    @wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()
        result = await func(*args, **kwargs)
        end_time = time.time()
        
        logger.info("函数执行时间", extra={
            "function": func.__name__,
            "execution_time": end_time - start_time
        })
        return result
    return wrapper
```

## 🎓 开发最佳实践

### 1. 代码组织
- 按功能模块组织代码
- 保持文件职责单一
- 使用清晰的导入结构

### 2. 异步编程
- 所有IO操作使用async/await
- 避免阻塞操作
- 合理使用并发任务

### 3. 错误处理
- 使用具体的异常类型
- 提供有意义的错误信息
- 记录详细的错误日志

### 4. 测试策略
- 编写单元测试覆盖核心逻辑
- 编写集成测试验证API功能
- 使用fixture管理测试数据

### 5. 安全性
- 验证所有输入数据
- 使用参数化查询防止SQL注入
- 实施适当的权限检查

---

这个详细的技术文档提供了项目的完整技术视图，包括API路由、文件调用关系、数据库结构、代码流程、权限系统和最佳实践。希望对您的开发工作有所帮助！
</content>
<line_count>750</line_count>