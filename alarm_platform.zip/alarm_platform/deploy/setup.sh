#!/bin/bash

# 监控报警平台部署脚本
set -e

echo "🚀 开始部署监控报警平台..."

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then
    echo "❌ 请使用sudo运行此脚本"
    exit 1
fi

# 配置变量
APP_DIR="/opt/alarm_platform"
APP_USER="www-data"
APP_GROUP="www-data"

# 安装系统依赖
echo "📦 安装系统依赖..."
if command -v apt &> /dev/null; then
    # Ubuntu/Debian
    apt update
    apt install -y python3 python3-pip python3-venv postgresql redis-server
elif command -v yum &> /dev/null; then
    # CentOS/RHEL
    yum install -y python3 python3-pip postgresql-server redis
    postgresql-setup --initdb
elif command -v dnf &> /dev/null; then
    # Fedora
    dnf install -y python3 python3-pip postgresql-server redis
    postgresql-setup --initdb
else
    echo "❌ 不支持的包管理器"
    exit 1
fi

# 创建应用目录
echo "📁 创建应用目录..."
mkdir -p $APP_DIR
chown $APP_USER:$APP_GROUP $APP_DIR

# 复制应用文件
echo "📋 复制应用文件..."
# 假设当前目录是项目根目录
cp -r . $APP_DIR/
chown -R $APP_USER:$APP_GROUP $APP_DIR

# 配置数据库
echo "🗄️  配置数据库..."
if command -v apt &> /dev/null; then
    systemctl start postgresql
    systemctl enable postgresql
fi

# 创建数据库和用户
sudo -u postgres psql -c "CREATE DATABASE monitoring_alarm_db;" || true
sudo -u postgres psql -c "CREATE USER user WITH PASSWORD 'password';" || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE monitoring_alarm_db TO user;" || true

# 配置Redis
echo "🔴 配置Redis..."
systemctl start redis
systemctl enable redis

# 创建Python虚拟环境
echo "🐍 创建Python虚拟环境..."
sudo -u $APP_USER python3 -m venv $APP_DIR/venv

# 安装Python依赖
echo "📦 安装Python依赖..."
sudo -u $APP_USER $APP_DIR/venv/bin/pip install -r $APP_DIR/requirements.txt

# 初始化数据库
echo "🗃️ 初始化数据库..."
sudo -u $APP_USER $APP_DIR/venv/bin/python $APP_DIR/init_db.py

# 配置Systemd服务
echo "⚙️ 配置Systemd服务..."
cp $APP_DIR/deploy/monitoring.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable monitoring.service
systemctl start monitoring.service

# 配置防火墙（开放8000端口）
echo "🔥 配置防火墙..."
if command -v ufw &> /dev/null; then
    ufw allow 8000
    ufw reload
elif command -v firewall-cmd &> /dev/null; then
    firewall-cmd --permanent --add-port=8000/tcp
    firewall-cmd --reload
fi

echo ""
echo "🎉 部署完成！"
echo ""
echo "📊 服务状态:"
echo "   应用服务: systemctl status monitoring"
echo "   数据库: systemctl status postgresql"
echo "   Redis: systemctl status redis"
echo ""
echo "🌐 访问地址: http://localhost:8000"
echo "📖 API文档: http://localhost:8000/docs"
echo ""
echo "🔐 默认用户:"
echo "   管理员: admin / admin123"
echo "   操作员: operator1 / admin123"
echo "   查看员: viewer1 / admin123"
echo ""
echo "📝 查看日志: journalctl -u monitoring.service -f"