# 监控报警平台项目指南

## 📋 项目概述

这是一个基于 FastAPI 的监控报警管理平台，支持多级权限管理（用户→项目→区域），能够管理 300+ 摄像头并集成外部报警系统。

## 🏗️ 项目架构

### 核心架构模式
- **MVC 模式**: Model-View-Controller 架构
- **分层设计**: API层 → 服务层 → 数据访问层
- **异步处理**: 全栈异步操作提高性能

## 📁 目录结构详解

### 1. 根目录文件
```
├── .env                    # 环境变量配置文件
├── requirements.txt        # Python依赖包列表
├── README.md              # 项目说明文档
├── project_plan.md        # 详细项目计划
├── projectInfo.txt        # 项目基本信息
├── init_db.py            # 数据库初始化脚本
├── start.sh              # 项目启动脚本
├── test_config.py        # 测试配置文件
└── test.db              # SQLite测试数据库
```

### 2. 应用核心目录 (app/)
```
app/
├── main.py               # FastAPI应用入口点
│
├── api/                  # API路由层 - 处理HTTP请求
│   ├── auth.py          # 用户认证API
│   ├── projects.py      # 项目管理API
│   ├── areas.py         # 区域管理API
│   ├── cameras.py       # 摄像头管理API
│   ├── alerts.py        # 报警管理API
│   └── audit_logs.py    # 审计日志API
│
├── core/                 # 核心配置和工具
│   ├── config.py        # 应用配置管理
│   ├── database.py      # 数据库连接和会话管理
│   └── security.py      # 安全相关功能(JWT,密码哈希)
│
├── models/               # 数据模型层 - 数据库表定义
│   ├── user.py          # 用户模型
│   ├── project.py       # 项目模型
│   ├── area.py          # 区域模型
│   ├── camera.py        # 摄像头模型
│   ├── alert.py         # 报警模型
│   └── audit_log.py     # 审计日志模型
│
├── schemas/              # Pydantic模型 - 请求/响应数据验证
│   ├── user.py          # 用户相关Schema
│   ├── project.py       # 项目相关Schema
│   ├── area.py          # 区域相关Schema
│   ├── camera.py        # 摄像头相关Schema
│   ├── alert.py         # 报警相关Schema
│   ├── audit_log.py     # 审计日志Schema
│   └── common.py        # 通用Schema和工具
│
├── services/             # 业务逻辑层 - 核心业务处理
│   ├── auth.py          # 认证服务
│   ├── permission.py    # 权限验证服务
│   ├── notification.py  # 通知服务
│   └── audit_log.py     # 审计日志服务
│
└── middleware/           # 中间件层
    └── audit_middleware.py  # 审计日志中间件
```

### 3. 部署配置 (deploy/)
```
deploy/
├── monitoring.service    # Systemd服务配置文件
└── setup.sh             # 部署安装脚本
```

### 4. 数据库初始化 (init-scripts/)
```
init-scripts/
├── 01-init-database.sql  # 数据库表结构初始化
└── 02-seed-data.sql      # 初始测试数据
```

### 5. 测试目录 (tests/)
```
tests/
├── conftest.py           # pytest测试配置和fixtures
├── test_auth.py          # 认证服务单元测试
├── test_api_auth.py      # 认证API集成测试
├── test_api_projects.py  # 项目API集成测试
├── test_api_areas.py     # 区域API集成测试
├── test_api_cameras.py   # 摄像头API集成测试
├── test_api_alerts.py    # 报警API集成测试
└── test_api_audit_logs.py # 审计日志API集成测试
```

## 🔄 数据流和工作流程

### 1. 典型API请求流程
```
客户端请求 → API路由 → 参数验证(Schema) → 权限检查 → 业务处理(Service) → 数据库操作(Model) → 返回响应
```

### 2. 权限验证流程
```
用户登录 → JWT Token生成 → API请求携带Token → 中间件验证 → 权限服务检查 → 业务处理
```

### 3. 报警处理流程
```
报警触发 → 创建报警记录 → 通知相关人员 → 记录审计日志 → 状态更新
```

## 🗄️ 数据库模型关系

### 核心实体关系
```
用户(User) ──┬── 用户项目角色(UserProjectRole) ── 项目(Project)
            │
            └── 用户区域权限(UserAreaPermission) ── 区域(Area) ── 项目(Project)
                                                      │
                                                      └── 摄像头(Camera) ── 报警(Alert)
```

### 审计日志
```
审计日志(AuditLog) ← 记录所有用户操作
```

## 🛠️ 核心技术栈

- **后端框架**: FastAPI (异步高性能)
- **数据库**: SQLite (开发测试) / PostgreSQL (生产)
- **ORM**: SQLAlchemy + asyncpg/aiosqlite
- **认证**: JWT (JSON Web Tokens)
- **数据验证**: Pydantic
- **测试**: pytest + httpx
- **部署**: Systemd + Nginx (可选)

## 🚀 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 配置环境
复制 `.env` 文件并根据需要修改配置

### 3. 初始化数据库
```bash
python init_db.py
```

### 4. 启动应用
```bash
python -m app.main
# 或使用启动脚本
./start.sh
```

### 5. 访问API文档
打开浏览器访问: http://localhost:8000/docs

## 📊 API端点概览

### 认证相关
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/register` - 用户注册
- `GET /api/auth/me` - 获取当前用户信息

### 项目管理
- `GET /api/projects` - 获取项目列表
- `POST /api/projects` - 创建项目
- `GET /api/projects/{id}` - 获取项目详情
- `PUT /api/projects/{id}` - 更新项目
- `DELETE /api/projects/{id}` - 删除项目

### 区域管理
- `GET /api/areas` - 获取区域列表
- `POST /api/areas` - 创建区域
- `GET /api/areas/{id}` - 获取区域详情
- `PUT /api/areas/{id}` - 更新区域
- `DELETE /api/areas/{id}` - 删除区域

### 摄像头管理
- `GET /api/cameras` - 获取摄像头列表
- `POST /api/cameras` - 创建摄像头
- `GET /api/cameras/{id}` - 获取摄像头详情
- `PUT /api/cameras/{id}` - 更新摄像头
- `DELETE /api/cameras/{id}` - 删除摄像头

### 报警管理
- `GET /api/alerts` - 获取报警列表
- `POST /api/alerts` - 创建报警
- `GET /api/alerts/{id}` - 获取报警详情
- `PUT /api/alerts/{id}` - 更新报警状态
- `DELETE /api/alerts/{id}` - 删除报警

### 审计日志
- `GET /api/audit-logs` - 获取审计日志列表
- `GET /api/audit-logs/{id}` - 获取审计日志详情

## 🔐 权限系统

### 三级权限结构
1. **用户级别**: 基础用户信息和管理
2. **项目级别**: 项目管理和用户角色分配
3. **区域级别**: 区域访问权限和摄像头管理

### 用户角色
- **超级管理员**: 系统最高权限
- **项目管理员**: 管理特定项目
- **区域管理员**: 管理特定区域
- **普通用户**: 查看权限范围内的内容

## 🧪 测试指南

### 运行所有测试
```bash
pytest tests/ -v
```

### 运行特定测试
```bash
pytest tests/test_api_auth.py -v
```

### 测试覆盖率
```bash
pytest --cov=app tests/
```

## 🚨 常见问题

### 1. 数据库连接问题
检查 `.env` 文件中的数据库配置

### 2. 权限验证失败
确保请求头中包含正确的 JWT Token

### 3. 异步操作问题
所有数据库操作都需要使用 `await` 关键字

### 4. 测试运行失败
确保所有依赖已安装，特别是测试相关包

## 📈 扩展建议

### 功能扩展
- 实时视频流集成
- 移动端APP
- 微信/短信通知
- 数据分析报表
- 设备状态监控

### 性能优化
- Redis缓存
- 数据库连接池
- 异步任务队列
- CDN静态资源

## 📞 技术支持

如果遇到问题，请检查：
1. 日志文件中的错误信息
2. API文档中的参数要求
3. 数据库连接状态
4. 权限配置是否正确

---

这个项目采用了现代Python Web开发的最佳实践，包括异步编程、类型注解、依赖注入和全面的测试覆盖。希望这个指南能帮助您快速上手和理解项目结构！