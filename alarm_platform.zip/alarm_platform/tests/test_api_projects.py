import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.models.user import User
from app.models.project import Project, UserProjectRole
from app.core.security import get_password_hash

@pytest.mark.asyncio
async def test_create_project_success(test_client, db_session: AsyncSession, auth_headers):
    """测试创建项目成功"""
    response = test_client.post(
        "/api/projects",
        json={
            "name": "测试项目",
            "description": "这是一个测试项目",
            "status": "active"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_201_CREATED
    data = response.json()
    assert data["name"] == "测试项目"
    assert data["description"] == "这是一个测试项目"
    assert data["status"] == "active"
    assert "id" in data

@pytest.mark.asyncio
async def test_create_project_unauthorized(test_client):
    """测试未授权创建项目"""
    response = test_client.post(
        "/api/projects",
        json={
            "name": "测试项目",
            "description": "这是一个测试项目",
            "status": "active"
        }
    )
    
    assert response.status_code == status.HTTP_307_TEMPORARY_REDIRECT

@pytest.mark.asyncio
async def test_list_projects_empty(test_client, auth_headers):
    """测试获取空项目列表"""
    response = test_client.get("/api/projects", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data == []

@pytest.mark.asyncio
async def test_list_projects_with_data(test_client, db_session: AsyncSession, auth_headers):
    """测试获取有数据的项目列表"""
    # 创建测试项目
    project = Project(
        name="测试项目1",
        description="测试项目1描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    response = test_client.get("/api/projects", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["name"] == "测试项目1"
    assert data[0]["description"] == "测试项目1描述"

@pytest.mark.asyncio
async def test_get_project_by_id(test_client, db_session: AsyncSession, auth_headers):
    """测试根据ID获取项目"""
    # 创建测试项目
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    response = test_client.get(f"/api/projects/{project.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["name"] == "测试项目"
    assert data["description"] == "测试项目描述"
    assert data["id"] == project.id

@pytest.mark.asyncio
async def test_get_nonexistent_project(test_client, auth_headers):
    """测试获取不存在的项目"""
    response = test_client.get("/api/projects/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "项目不存在"

@pytest.mark.asyncio
async def test_update_project(test_client, db_session: AsyncSession, auth_headers):
    """测试更新项目"""
    # 创建测试项目
    project = Project(
        name="原始项目",
        description="原始描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    # 更新项目
    response = test_client.put(
        f"/api/projects/{project.id}",
        json={
            "name": "更新后的项目",
            "description": "更新后的描述",
            "status": "inactive"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["name"] == "更新后的项目"
    assert data["description"] == "更新后的描述"
    assert data["status"] == "inactive"

@pytest.mark.asyncio
async def test_delete_project(test_client, db_session: AsyncSession, auth_headers):
    """测试删除项目"""
    # 创建测试项目
    project = Project(
        name="待删除项目",
        description="将被删除的项目",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    # 删除项目
    response = test_client.delete(f"/api/projects/{project.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_204_NO_CONTENT

    # 验证项目已被删除
    response = test_client.get(f"/api/projects/{project.id}", headers=auth_headers)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.asyncio
async def test_delete_nonexistent_project(test_client, auth_headers):
    """测试删除不存在的项目"""
    response = test_client.delete("/api/projects/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "项目不存在"

@pytest.mark.asyncio
async def test_project_validation(test_client, auth_headers):
    """测试项目数据验证"""
    # 测试缺少必填字段
    response = test_client.post(
        "/api/projects",
        json={
            "description": "只有描述没有名称"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # 测试无效状态
    response = test_client.post(
        "/api/projects",
        json={
            "name": "测试项目",
            "description": "测试描述",
            "status": "invalid_status"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY