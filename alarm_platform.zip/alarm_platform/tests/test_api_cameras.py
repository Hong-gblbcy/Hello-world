import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.project import Project
from app.models.area import Area
from app.models.camera import Camera

@pytest.mark.asyncio
async def test_create_camera_success(test_client, db_session: AsyncSession, auth_headers):
    """测试创建摄像头成功"""
    # 先创建项目和区域
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    response = test_client.post(
        "/api/cameras",
        json={
            "name": "测试摄像头",
            "description": "这是一个测试摄像头",
            "area_id": area.id,
            "stream_url": "rtsp://example.com/stream",
            "status": "active",
            "position": "入口处",
            "model": "IPC-HFW1230S"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_201_CREATED
    data = response.json()
    assert data["name"] == "测试摄像头"
    assert data["description"] == "这是一个测试摄像头"
    assert data["area_id"] == area.id
    assert data["stream_url"] == "rtsp://example.com/stream"
    assert data["status"] == "active"
    assert "id" in data

@pytest.mark.asyncio
async def test_create_camera_nonexistent_area(test_client, auth_headers):
    """测试为不存在的区域创建摄像头"""
    response = test_client.post(
        "/api/cameras",
        json={
            "name": "测试摄像头",
            "description": "测试摄像头描述",
            "area_id": 999,
            "stream_url": "rtsp://example.com/stream",
            "status": "active"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "区域不存在"

@pytest.mark.asyncio
async def test_list_cameras_empty(test_client, auth_headers):
    """测试获取空摄像头列表"""
    response = test_client.get("/api/cameras", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data == []

@pytest.mark.asyncio
async def test_list_cameras_with_data(test_client, db_session: AsyncSession, auth_headers):
    """测试获取有数据的摄像头列表"""
    # 创建项目、区域和摄像头
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()

    response = test_client.get("/api/cameras", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["name"] == "测试摄像头"
    assert data[0]["area_id"] == area.id

@pytest.mark.asyncio
async def test_get_camera_by_id(test_client, db_session: AsyncSession, auth_headers):
    """测试根据ID获取摄像头"""
    # 创建项目、区域和摄像头
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    response = test_client.get(f"/api/cameras/{camera.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["name"] == "测试摄像头"
    assert data["description"] == "测试摄像头描述"
    assert data["id"] == camera.id

@pytest.mark.asyncio
async def test_get_nonexistent_camera(test_client, auth_headers):
    """测试获取不存在的摄像头"""
    response = test_client.get("/api/cameras/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "摄像头不存在"

@pytest.mark.asyncio
async def test_update_camera(test_client, db_session: AsyncSession, auth_headers):
    """测试更新摄像头"""
    # 创建项目、区域和摄像头
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="原始摄像头",
        description="原始描述",
        area_id=area.id,
        stream_url="rtsp://example.com/old",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    # 更新摄像头
    response = test_client.put(
        f"/api/cameras/{camera.id}",
        json={
            "name": "更新后的摄像头",
            "description": "更新后的描述",
            "area_id": area.id,
            "stream_url": "rtsp://example.com/new",
            "status": "inactive"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["name"] == "更新后的摄像头"
    assert data["description"] == "更新后的描述"
    assert data["stream_url"] == "rtsp://example.com/new"
    assert data["status"] == "inactive"

@pytest.mark.asyncio
async def test_delete_camera(test_client, db_session: AsyncSession, auth_headers):
    """测试删除摄像头"""
    # 创建项目、区域和摄像头
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="待删除摄像头",
        description="将被删除的摄像头",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    # 删除摄像头
    response = test_client.delete(f"/api/cameras/{camera.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_204_NO_CONTENT

    # 验证摄像头已被删除
    response = test_client.get(f"/api/cameras/{camera.id}", headers=auth_headers)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.asyncio
async def test_delete_nonexistent_camera(test_client, auth_headers):
    """测试删除不存在的摄像头"""
    response = test_client.delete("/api/cameras/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "摄像头不存在"

@pytest.mark.asyncio
async def test_camera_validation(test_client, auth_headers):
    """测试摄像头数据验证"""
    # 测试缺少必填字段
    response = test_client.post(
        "/api/cameras",
        json={
            "description": "只有描述没有名称"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # 测试无效状态
    response = test_client.post(
        "/api/cameras",
        json={
            "name": "测试摄像头",
            "description": "测试描述",
            "area_id": 1,
            "stream_url": "rtsp://example.com/stream",
            "status": "invalid_status"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

@pytest.mark.asyncio
async def test_get_cameras_by_area(test_client, db_session: AsyncSession, auth_headers):
    """测试根据区域ID获取摄像头"""
    # 创建项目、区域和摄像头
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area1 = Area(
        name="区域1",
        description="区域1描述",
        project_id=project.id,
        status="active"
    )
    area2 = Area(
        name="区域2",
        description="区域2描述",
        project_id=project.id,
        status="active"
    )
    db_session.add_all([area1, area2])
    await db_session.commit()
    await db_session.refresh(area1)
    await db_session.refresh(area2)

    # 为区域1创建摄像头
    camera1 = Camera(
        name="区域1摄像头",
        description="区域1摄像头描述",
        area_id=area1.id,
        stream_url="rtsp://example.com/area1",
        status="active"
    )
    camera2 = Camera(
        name="区域1另一个摄像头",
        description="区域1另一个摄像头描述",
        area_id=area1.id,
        stream_url="rtsp://example.com/area1_2",
        status="active"
    )
    # 为区域2创建摄像头
    camera3 = Camera(
        name="区域2摄像头",
        description="区域2摄像头描述",
        area_id=area2.id,
        stream_url="rtsp://example.com/area2",
        status="active"
    )
    db_session.add_all([camera1, camera2, camera3])
    await db_session.commit()

    # 获取区域1的摄像头
    response = test_client.get(f"/api/cameras?area_id={area1.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 2
    assert all(camera["area_id"] == area1.id for camera in data)