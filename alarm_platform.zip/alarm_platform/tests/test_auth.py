import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.models.user import User
from app.services.auth import AuthService
from app.core.security import get_password_hash

@pytest.mark.asyncio
async def test_authenticate_user_success(db_session: AsyncSession):
    """测试用户认证成功"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试认证
    user = await AuthService.authenticate_user(db_session, "testuser", "testpassword")
    assert user is not None
    assert user.username == "testuser"
    assert user.name == "Test User"

@pytest.mark.asyncio
async def test_authenticate_user_wrong_password(db_session: AsyncSession):
    """测试密码错误"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试错误密码
    user = await AuthService.authenticate_user(db_session, "testuser", "wrongpassword")
    assert user is None

@pytest.mark.asyncio
async def test_authenticate_user_not_found(db_session: AsyncSession):
    """测试用户不存在"""
    user = await AuthService.authenticate_user(db_session, "nonexistent", "password")
    assert user is None

@pytest.mark.asyncio
async def test_authenticate_user_inactive(db_session: AsyncSession):
    """测试用户被禁用"""
    # 创建禁用用户
    test_user = User(
        username="inactiveuser",
        password_hash=get_password_hash("testpassword"),
        name="Inactive User",
        email="inactive@example.com",
        is_active=False
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试认证被禁用用户
    user = await AuthService.authenticate_user(db_session, "inactiveuser", "testpassword")
    assert user is None

@pytest.mark.asyncio
async def test_get_user_by_username(db_session: AsyncSession):
    """测试根据用户名获取用户"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试获取用户
    user = await AuthService.get_user_by_username(db_session, "testuser")
    assert user is not None
    assert user.username == "testuser"

    # 测试获取不存在的用户
    user = await AuthService.get_user_by_username(db_session, "nonexistent")
    assert user is None