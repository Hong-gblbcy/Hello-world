import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
import os

from app.main import app
from app.core.database import Base, get_db
from app.core.config import settings

# 使用内存SQLite数据库进行测试
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

# 创建测试数据库引擎
test_engine = create_async_engine(
    TEST_DATABASE_URL, 
    echo=False,
    connect_args={"check_same_thread": False}
)

# 创建测试会话工厂
TestingSessionLocal = sessionmaker(
    class_=AsyncSession,
    autocommit=False,
    autoflush=False,
    bind=test_engine,
    expire_on_commit=False
)

@pytest.fixture(scope="session", autouse=True)
async def setup_database():
    """设置测试数据库"""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

@pytest.fixture
async def db_session():
    """创建数据库会话"""
    async with TestingSessionLocal() as session:
        yield session
        await session.rollback()

@pytest.fixture
async def test_client():
    """创建测试客户端"""
    # 创建新的数据库会话用于客户端
    async with TestingSessionLocal() as db_session:
        
        async def override_get_db():
            try:
                yield db_session
            finally:
                await db_session.close()
        
        app.dependency_overrides[get_db] = override_get_db
        
        # 使用异步方式创建TestClient
        async with TestClient(app) as client:
            yield client
        
        app.dependency_overrides.clear()

@pytest.fixture
def admin_token(test_client):
    """获取管理员token"""
    # 创建测试管理员用户
    # 在实际测试中需要先创建用户
    return "test_admin_token"

@pytest.fixture
def user_token(test_client):
    """获取普通用户token"""
    # 创建测试普通用户  
    # 在实际测试中需要先创建用户
    return "test_user_token"
@pytest.fixture
def auth_headers(admin_token):
    """创建认证头"""
    return {"Authorization": f"Bearer {admin_token}"}