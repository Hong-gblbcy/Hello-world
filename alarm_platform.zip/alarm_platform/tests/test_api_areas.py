import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.project import Project
from app.models.area import Area

@pytest.mark.asyncio
async def test_create_area_success(test_client, db_session: AsyncSession, auth_headers):
    """测试创建区域成功"""
    # 先创建项目
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    response = test_client.post(
        "/api/areas",
        json={
            "name": "测试区域",
            "description": "这是一个测试区域",
            "project_id": project.id,
            "status": "active"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_201_CREATED
    data = response.json()
    assert data["name"] == "测试区域"
    assert data["description"] == "这是一个测试区域"
    assert data["project_id"] == project.id
    assert data["status"] == "active"
    assert "id" in data

@pytest.mark.asyncio
async def test_create_area_with_parent(test_client, db_session: AsyncSession, auth_headers):
    """测试创建子区域"""
    # 先创建项目和父区域
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    parent_area = Area(
        name="父区域",
        description="父区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(parent_area)
    await db_session.commit()
    await db_session.refresh(parent_area)

    response = test_client.post(
        "/api/areas",
        json={
            "name": "子区域",
            "description": "子区域描述",
            "project_id": project.id,
            "parent_id": parent_area.id,
            "status": "active"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_201_CREATED
    data = response.json()
    assert data["name"] == "子区域"
    assert data["parent_id"] == parent_area.id

@pytest.mark.asyncio
async def test_create_area_nonexistent_project(test_client, auth_headers):
    """测试为不存在的项目创建区域"""
    response = test_client.post(
        "/api/areas",
        json={
            "name": "测试区域",
            "description": "测试区域描述",
            "project_id": 999,
            "status": "active"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "项目不存在"

@pytest.mark.asyncio
async def test_list_areas_empty(test_client, auth_headers):
    """测试获取空区域列表"""
    response = test_client.get("/api/areas", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data == []

@pytest.mark.asyncio
async def test_list_areas_with_data(test_client, db_session: AsyncSession, auth_headers):
    """测试获取有数据的区域列表"""
    # 创建项目和区域
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()

    response = test_client.get("/api/areas", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["name"] == "测试区域"
    assert data[0]["project_id"] == project.id

@pytest.mark.asyncio
async def test_get_area_by_id(test_client, db_session: AsyncSession, auth_headers):
    """测试根据ID获取区域"""
    # 创建项目和区域
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    response = test_client.get(f"/api/areas/{area.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["name"] == "测试区域"
    assert data["description"] == "测试区域描述"
    assert data["id"] == area.id

@pytest.mark.asyncio
async def test_get_nonexistent_area(test_client, auth_headers):
    """测试获取不存在的区域"""
    response = test_client.get("/api/areas/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "区域不存在"

@pytest.mark.asyncio
async def test_update_area(test_client, db_session: AsyncSession, auth_headers):
    """测试更新区域"""
    # 创建项目和区域
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="原始区域",
        description="原始描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    # 更新区域
    response = test_client.put(
        f"/api/areas/{area.id}",
        json={
            "name": "更新后的区域",
            "description": "更新后的描述",
            "project_id": project.id,
            "status": "inactive"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["name"] == "更新后的区域"
    assert data["description"] == "更新后的描述"
    assert data["status"] == "inactive"

@pytest.mark.asyncio
async def test_delete_area(test_client, db_session: AsyncSession, auth_headers):
    """测试删除区域"""
    # 创建项目和区域
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="待删除区域",
        description="将被删除的区域",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    # 删除区域
    response = test_client.delete(f"/api/areas/{area.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_204_NO_CONTENT

    # 验证区域已被删除
    response = test_client.get(f"/api/areas/{area.id}", headers=auth_headers)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.asyncio
async def test_delete_nonexistent_area(test_client, auth_headers):
    """测试删除不存在的区域"""
    response = test_client.delete("/api/areas/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "区域不存在"

@pytest.mark.asyncio
async def test_area_validation(test_client, auth_headers):
    """测试区域数据验证"""
    # 测试缺少必填字段
    response = test_client.post(
        "/api/areas",
        json={
            "description": "只有描述没有名称"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # 测试无效状态
    response = test_client.post(
        "/api/areas",
        json={
            "name": "测试区域",
            "description": "测试描述",
            "project_id": 1,
            "status": "invalid_status"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY