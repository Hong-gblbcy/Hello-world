import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone

from app.models.project import Project
from app.models.area import Area
from app.models.camera import Camera
from app.models.user import User
from app.models.alert import Alert
from app.core.security import get_password_hash

@pytest.mark.asyncio
async def test_create_alert_success(test_client, db_session: AsyncSession, auth_headers):
    """测试创建报警成功"""
    # 创建项目、区域、摄像头和用户
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    response = test_client.post(
        "/api/alerts",
        json={
            "camera_id": camera.id,
            "alert_type": "motion",
            "severity": "high",
            "description": "检测到移动物体",
            "evidence_url": "http://example.com/evidence.jpg",
            "triggered_by": test_user.id
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_201_CREATED
    data = response.json()
    assert data["alert_type"] == "motion"
    assert data["severity"] == "high"
    assert data["description"] == "检测到移动物体"
    assert data["camera_id"] == camera.id
    assert data["triggered_by"] == test_user.id
    assert "id" in data
    assert "triggered_at" in data

@pytest.mark.asyncio
async def test_create_alert_nonexistent_camera(test_client, auth_headers):
    """测试为不存在的摄像头创建报警"""
    response = test_client.post(
        "/api/alerts",
        json={
            "camera_id": 999,
            "alert_type": "motion",
            "severity": "high",
            "description": "检测到移动物体"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "摄像头不存在"

@pytest.mark.asyncio
async def test_list_alerts_empty(test_client, auth_headers):
    """测试获取空报警列表"""
    response = test_client.get("/api/alerts", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data == []

@pytest.mark.asyncio
async def test_list_alerts_with_data(test_client, db_session: AsyncSession, auth_headers):
    """测试获取有数据的报警列表"""
    # 创建项目、区域、摄像头和报警
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    alert = Alert(
        camera_id=camera.id,
        alert_type="motion",
        severity="high",
        description="测试报警",
        status="pending"
    )
    db_session.add(alert)
    await db_session.commit()

    response = test_client.get("/api/alerts", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["alert_type"] == "motion"
    assert data[0]["camera_id"] == camera.id

@pytest.mark.asyncio
async def test_get_alert_by_id(test_client, db_session: AsyncSession, auth_headers):
    """测试根据ID获取报警"""
    # 创建项目、区域、摄像头和报警
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    alert = Alert(
        camera_id=camera.id,
        alert_type="motion",
        severity="high",
        description="测试报警描述",
        status="pending"
    )
    db_session.add(alert)
    await db_session.commit()
    await db_session.refresh(alert)

    response = test_client.get(f"/api/alerts/{alert.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["alert_type"] == "motion"
    assert data["description"] == "测试报警描述"
    assert data["id"] == alert.id

@pytest.mark.asyncio
async def test_get_nonexistent_alert(test_client, auth_headers):
    """测试获取不存在的报警"""
    response = test_client.get("/api/alerts/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "报警不存在"

@pytest.mark.asyncio
async def test_update_alert_status(test_client, db_session: AsyncSession, auth_headers):
    """测试更新报警状态"""
    # 创建项目、区域、摄像头和报警
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    alert = Alert(
        camera_id=camera.id,
        alert_type="motion",
        severity="high",
        description="测试报警",
        status="pending"
    )
    db_session.add(alert)
    await db_session.commit()
    await db_session.refresh(alert)

    # 更新报警状态
    response = test_client.patch(
        f"/api/alerts/{alert.id}",
        json={
            "status": "resolved",
            "resolution_notes": "已处理完成"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["status"] == "resolved"
    assert data["resolution_notes"] == "已处理完成"
    assert "resolved_at" in data

@pytest.mark.asyncio
async def test_delete_alert(test_client, db_session: AsyncSession, auth_headers):
    """测试删除报警"""
    # 创建项目、区域、摄像头和报警
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    alert = Alert(
        camera_id=camera.id,
        alert_type="motion",
        severity="high",
        description="待删除报警",
        status="pending"
    )
    db_session.add(alert)
    await db_session.commit()
    await db_session.refresh(alert)

    # 删除报警
    response = test_client.delete(f"/api/alerts/{alert.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_204_NO_CONTENT

    # 验证报警已被删除
    response = test_client.get(f"/api/alerts/{alert.id}", headers=auth_headers)
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.asyncio
async def test_delete_nonexistent_alert(test_client, auth_headers):
    """测试删除不存在的报警"""
    response = test_client.delete("/api/alerts/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "报警不存在"

@pytest.mark.asyncio
async def test_alert_validation(test_client, auth_headers):
    """测试报警数据验证"""
    # 测试缺少必填字段
    response = test_client.post(
        "/api/alerts",
        json={
            "severity": "high",
            "description": "只有严重程度和描述"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # 测试无效报警类型
    response = test_client.post(
        "/api/alerts",
        json={
            "camera_id": 1,
            "alert_type": "invalid_type",
            "severity": "high",
            "description": "测试描述"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    # 测试无效严重程度
    response = test_client.post(
        "/api/alerts",
        json={
            "camera_id": 1,
            "alert_type": "motion",
            "severity": "invalid_severity",
            "description": "测试描述"
        },
        headers=auth_headers
    )
    
    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

@pytest.mark.asyncio
async def test_get_alerts_by_camera(test_client, db_session: AsyncSession, auth_headers):
    """测试根据摄像头ID获取报警"""
    # 创建项目、区域和摄像头
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera1 = Camera(
        name="摄像头1",
        description="摄像头1描述",
        area_id=area.id,
        stream_url="rtsp://example.com/camera1",
        status="active"
    )
    camera2 = Camera(
        name="摄像头2",
        description="摄像头2描述",
        area_id=area.id,
        stream_url="rtsp://example.com/camera2",
        status="active"
    )
    db_session.add_all([camera1, camera2])
    await db_session.commit()
    await db_session.refresh(camera1)
    await db_session.refresh(camera2)

    # 为摄像头1创建报警
    alert1 = Alert(
        camera_id=camera1.id,
        alert_type="motion",
        severity="high",
        description="摄像头1报警1",
        status="pending"
    )
    alert2 = Alert(
        camera_id=camera1.id,
        alert_type="intrusion",
        severity="medium",
        description="摄像头1报警2",
        status="pending"
    )
    # 为摄像头2创建报警
    alert3 = Alert(
        camera_id=camera2.id,
        alert_type="motion",
        severity="low",
        description="摄像头2报警",
        status="pending"
    )
    db_session.add_all([alert1, alert2, alert3])
    await db_session.commit()

    # 获取摄像头1的报警
    response = test_client.get(f"/api/alerts?camera_id={camera1.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 2
    assert all(alert["camera_id"] == camera1.id for alert in data)

@pytest.mark.asyncio
async def test_get_alerts_by_status(test_client, db_session: AsyncSession, auth_headers):
    """测试根据状态获取报警"""
    # 创建项目、区域、摄像头和报警
    project = Project(
        name="测试项目",
        description="测试项目描述",
        status="active"
    )
    db_session.add(project)
    await db_session.commit()
    await db_session.refresh(project)

    area = Area(
        name="测试区域",
        description="测试区域描述",
        project_id=project.id,
        status="active"
    )
    db_session.add(area)
    await db_session.commit()
    await db_session.refresh(area)

    camera = Camera(
        name="测试摄像头",
        description="测试摄像头描述",
        area_id=area.id,
        stream_url="rtsp://example.com/stream",
        status="active"
    )
    db_session.add(camera)
    await db_session.commit()
    await db_session.refresh(camera)

    # 创建不同状态的报警
    pending_alert = Alert(
        camera_id=camera.id,
        alert_type="motion",
        severity="high",
        description="待处理报警",
        status="pending"
    )
    resolved_alert = Alert(
        camera_id=camera.id,
        alert_type="intrusion",
        severity="medium",
        description="已处理报警",
        status="resolved",
        resolution_notes="已处理完成"
    )
    db_session.add_all([pending_alert, resolved_alert])
    await db_session.commit()

    # 获取待处理状态的报警
    response = test_client.get("/api/alerts?status=pending", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["status"] == "pending"