import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.models.user import User
from app.core.security import get_password_hash

@pytest.mark.asyncio
async def test_login_success(test_client, db_session: AsyncSession):
    """测试登录成功"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试登录
    response = test_client.post(
        "/api/auth/login",
        json={
            "username": "testuser",
            "password": "testpassword"
        }
    )
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"

@pytest.mark.asyncio
async def test_login_wrong_password(test_client, db_session: AsyncSession):
    """测试密码错误"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试错误密码
    response = test_client.post(
        "/api/auth/login",
        json={
            "username": "testuser",
            "password": "wrongpassword"
        }
    )
    
    assert response.status_code == status.HTTP_401_UNAUTHORIZED
    assert response.json()["detail"] == "用户名或密码错误"

@pytest.mark.asyncio
async def test_login_user_not_found(test_client):
    """测试用户不存在"""
    response = test_client.post(
        "/api/auth/login",
        json={
            "username": "nonexistent",
            "password": "password"
        }
    )
    
    assert response.status_code == status.HTTP_401_UNAUTHORIZED
    assert response.json()["detail"] == "用户名或密码错误"

@pytest.mark.asyncio
async def test_login_inactive_user(test_client, db_session: AsyncSession):
    """测试用户被禁用"""
    # 创建禁用用户
    test_user = User(
        username="inactiveuser",
        password_hash=get_password_hash("testpassword"),
        name="Inactive User",
        email="inactive@example.com",
        is_active=False
    )
    db_session.add(test_user)
    await db_session.commit()

    # 测试登录被禁用用户
    response = test_client.post(
        "/api/auth/login",
        json={
            "username": "inactiveuser",
            "password": "testpassword"
        }
    )
    
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert response.json()["detail"] == "用户已被禁用"

@pytest.mark.asyncio
async def test_protected_endpoint_without_token(test_client):
    """测试未认证访问受保护端点"""
    response = test_client.get("/api/areas")
    assert response.status_code == status.HTTP_307_TEMPORARY_REDIRECT

@pytest.mark.asyncio
async def test_protected_endpoint_with_invalid_token(test_client):
    """测试使用无效token访问受保护端点"""
    response = test_client.get(
        "/api/areas",
        headers={"Authorization": "Bearer invalid_token"}
    )
    assert response.status_code == status.HTTP_307_TEMPORARY_REDIRECT

@pytest.mark.asyncio
async def test_health_check(test_client):
    """测试健康检查端点"""
    response = test_client.get("/health")
    assert response.status_code == status.HTTP_200_OK
    assert response.json() == {"status": "healthy"}