import pytest
from fastapi import status
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_log import AuditLog
from app.models.user import User
from app.core.security import get_password_hash

@pytest.mark.asyncio
async def test_list_audit_logs_empty(test_client, auth_headers):
    """测试获取空审计日志列表"""
    response = test_client.get("/api/audit-logs", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data == []

@pytest.mark.asyncio
async def test_list_audit_logs_with_data(test_client, db_session: AsyncSession, auth_headers):
    """测试获取有数据的审计日志列表"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    # 创建审计日志
    audit_log = AuditLog(
        user_id=test_user.id,
        action_type="login",
        target_type="user",
        target_id=test_user.id,
        details="用户登录系统",
        ip_address="127.0.0.1"
    )
    db_session.add(audit_log)
    await db_session.commit()

    response = test_client.get("/api/audit-logs", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["action_type"] == "login"
    assert data[0]["target_type"] == "user"
    assert data[0]["user_id"] == test_user.id

@pytest.mark.asyncio
async def test_get_audit_log_by_id(test_client, db_session: AsyncSession, auth_headers):
    """测试根据ID获取审计日志"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    # 创建审计日志
    audit_log = AuditLog(
        user_id=test_user.id,
        action_type="create",
        target_type="project",
        target_id=1,
        details="创建新项目",
        ip_address="127.0.0.1"
    )
    db_session.add(audit_log)
    await db_session.commit()
    await db_session.refresh(audit_log)

    response = test_client.get(f"/api/audit-logs/{audit_log.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["action_type"] == "create"
    assert data["target_type"] == "project"
    assert data["user_id"] == test_user.id
    assert data["id"] == audit_log.id

@pytest.mark.asyncio
async def test_get_nonexistent_audit_log(test_client, auth_headers):
    """测试获取不存在的审计日志"""
    response = test_client.get("/api/audit-logs/999", headers=auth_headers)
    
    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "审计日志不存在"

@pytest.mark.asyncio
async def test_filter_audit_logs_by_action_type(test_client, db_session: AsyncSession, auth_headers):
    """测试根据操作类型过滤审计日志"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    # 创建不同类型的审计日志
    login_log = AuditLog(
        user_id=test_user.id,
        action_type="login",
        target_type="user",
        target_id=test_user.id,
        details="用户登录",
        ip_address="127.0.0.1"
    )
    create_log = AuditLog(
        user_id=test_user.id,
        action_type="create",
        target_type="project",
        target_id=1,
        details="创建项目",
        ip_address="127.0.0.1"
    )
    update_log = AuditLog(
        user_id=test_user.id,
        action_type="update",
        target_type="project",
        target_id=1,
        details="更新项目",
        ip_address="127.0.0.1"
    )
    db_session.add_all([login_log, create_log, update_log])
    await db_session.commit()

    # 过滤创建类型的操作
    response = test_client.get("/api/audit-logs?action_type=create", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["action_type"] == "create"

@pytest.mark.asyncio
async def test_filter_audit_logs_by_target_type(test_client, db_session: AsyncSession, auth_headers):
    """测试根据目标类型过滤审计日志"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    # 创建不同目标类型的审计日志
    user_log = AuditLog(
        user_id=test_user.id,
        action_type="login",
        target_type="user",
        target_id=test_user.id,
        details="用户操作",
        ip_address="127.0.0.1"
    )
    project_log = AuditLog(
        user_id=test_user.id,
        action_type="create",
        target_type="project",
        target_id=1,
        details="项目操作",
        ip_address="127.0.0.1"
    )
    area_log = AuditLog(
        user_id=test_user.id,
        action_type="create",
        target_type="area",
        target_id=1,
        details="区域操作",
        ip_address="127.0.0.1"
    )
    db_session.add_all([user_log, project_log, area_log])
    await db_session.commit()

    # 过滤项目类型的操作
    response = test_client.get("/api/audit-logs?target_type=project", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["target_type"] == "project"

@pytest.mark.asyncio
async def test_filter_audit_logs_by_user_id(test_client, db_session: AsyncSession, auth_headers):
    """测试根据用户ID过滤审计日志"""
    # 创建两个测试用户
    user1 = User(
        username="user1",
        password_hash=get_password_hash("password1"),
        name="User One",
        email="user1@example.com",
        is_active=True
    )
    user2 = User(
        username="user2",
        password_hash=get_password_hash("password2"),
        name="User Two",
        email="user2@example.com",
        is_active=True
    )
    db_session.add_all([user1, user2])
    await db_session.commit()
    await db_session.refresh(user1)
    await db_session.refresh(user2)

    # 为两个用户创建审计日志
    user1_log = AuditLog(
        user_id=user1.id,
        action_type="login",
        target_type="user",
        target_id=user1.id,
        details="用户1登录",
        ip_address="127.0.0.1"
    )
    user2_log = AuditLog(
        user_id=user2.id,
        action_type="login",
        target_type="user",
        target_id=user2.id,
        details="用户2登录",
        ip_address="127.0.0.1"
    )
    db_session.add_all([user1_log, user2_log])
    await db_session.commit()

    # 过滤用户1的操作
    response = test_client.get(f"/api/audit-logs?user_id={user1.id}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 1
    assert data[0]["user_id"] == user1.id

@pytest.mark.asyncio
async def test_audit_log_pagination(test_client, db_session: AsyncSession, auth_headers):
    """测试审计日志分页"""
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    # 创建多个审计日志
    for i in range(15):
        audit_log = AuditLog(
            user_id=test_user.id,
            action_type=f"action_{i}",
            target_type="test",
            target_id=i,
            details=f"测试操作 {i}",
            ip_address="127.0.0.1"
        )
        db_session.add(audit_log)
    await db_session.commit()

    # 测试第一页
    response = test_client.get("/api/audit-logs?skip=0&limit=10", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 10

    # 测试第二页
    response = test_client.get("/api/audit-logs?skip=10&limit=10", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert len(data) == 5  # 总共15条，第二页应该只有5条

@pytest.mark.asyncio
async def test_audit_log_unauthorized(test_client):
    """测试未授权访问审计日志"""
    response = test_client.get("/api/audit-logs")
    
    assert response.status_code == status.HTTP_307_TEMPORARY_REDIRECT

@pytest.mark.asyncio
async def test_audit_log_timestamp_filter(test_client, db_session: AsyncSession, auth_headers):
    """测试根据时间戳过滤审计日志"""
    import time
    from datetime import datetime, timezone
    
    # 创建测试用户
    test_user = User(
        username="testuser",
        password_hash=get_password_hash("testpassword"),
        name="Test User",
        email="test@example.com",
        is_active=True
    )
    db_session.add(test_user)
    await db_session.commit()
    await db_session.refresh(test_user)

    # 等待一秒确保时间戳不同
    time.sleep(1)
    
    # 记录当前时间
    current_time = datetime.now(timezone.utc)
    
    # 创建审计日志
    audit_log = AuditLog(
        user_id=test_user.id,
        action_type="test",
        target_type="test",
        target_id=1,
        details="测试时间过滤",
        ip_address="127.0.0.1"
    )
    db_session.add(audit_log)
    await db_session.commit()
    await db_session.refresh(audit_log)

    # 获取创建时间之后的日志
    from datetime import timedelta
    start_time = (current_time - timedelta(seconds=2)).isoformat()
    
    response = test_client.get(f"/api/audit-logs?start_time={start_time}", headers=auth_headers)
    
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    # 应该包含我们刚创建的日志
    assert len(data) >= 1
    assert any(log["id"] == audit_log.id for log in data)