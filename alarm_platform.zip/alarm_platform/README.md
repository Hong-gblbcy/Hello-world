# 监控报警管理平台

一个基于 FastAPI 的分布式监控和报警管理系统，支持多级权限控制、摄像头管理、实时报警处理和通知功能。

## 功能特性

- 🔐 **多级权限系统**: 用户 → 项目 → 区域三级权限控制
- 📹 **摄像头管理**: 支持 300+ 摄像头接入和管理
- 🚨 **实时报警**: 摄像头移动检测和外部报警集成
- 📧 **多渠道通知**: 邮件、短信、推送、Webhook 通知
- 📊 **审计日志**: 完整的操作审计和日志记录
- ⚡ **高性能**: 基于 FastAPI 和异步处理

## 技术栈

- **后端框架**: FastAPI + Uvicorn
- **数据库**: PostgreSQL 15
- **缓存/消息队列**: Redis 7
- **任务队列**: Celery + Redis (可选)
- **认证**: JWT + OAuth2
- **部署**: 直接部署，无需容器化

## 系统要求

- **Python**: 3.9+
- **PostgreSQL**: 14+
- **Redis**: 6+ (可选，用于缓存和任务队列)
- **操作系统**: Linux, macOS, Windows (WSL推荐)
- **Web服务器**: 内置Uvicorn (端口8000)

## 快速开始

### 1. 安装系统依赖

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip python3-venv postgresql redis-server

# CentOS/RHEL
sudo yum install python3 python3-pip postgresql-server redis

# macOS (使用Homebrew)
brew install python postgresql redis
```

### 2. 配置数据库和Redis

```bash
# 启动PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# 启动Redis
sudo systemctl start redis
sudo systemctl enable redis

# 创建数据库和用户
sudo -u postgres psql -c "CREATE DATABASE monitoring_alarm_db;"
sudo -u postgres psql -c "CREATE USER user WITH PASSWORD 'password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE monitoring_alarm_db TO user;"
```

### 3. 部署应用

```bash
# 克隆项目
git clone <repository-url>
cd alarm_platform

# 一键启动（自动安装依赖和初始化）
./start.sh

# 或手动安装
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python init_db.py
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

服务启动后访问:
- API 文档: http://localhost:8000/docs
- 健康检查: http://localhost:8000/health

### 4. 环境配置

复制环境配置文件并修改:

```bash
cp .env.example .env
```

编辑 `.env` 文件配置数据库连接、Redis、JWT密钥等。

## 项目结构

```
alarm_platform/
├── app/                    # 应用代码
│   ├── api/               # API 路由
│   ├── core/              # 核心配置和工具
│   ├── models/            # 数据库模型
│   ├── schemas/           # Pydantic 模型
│   ├── services/          # 业务逻辑服务
│   └── main.py           # 应用入口
├── init-scripts/          # 数据库初始化脚本
├── requirements.txt      # Python 依赖
├── start.sh             # 启动脚本
└── README.md           # 项目文档
```

## API 文档

启动后访问 `http://localhost:8000/docs` 查看完整的 API 文档和交互式测试。

### 主要 API 端点

- `POST /api/auth/login` - 用户登录
- `GET /api/auth/me` - 获取当前用户信息
- `GET /api/projects` - 获取项目列表
- `POST /api/projects` - 创建项目
- `GET /api/areas` - 获取区域列表
- `GET /api/cameras` - 获取摄像头列表
- `POST /api/alerts` - 创建报警
- `GET /api/alerts` - 获取报警列表

## 权限系统

系统采用三级权限控制:

1. **用户级别**: 管理员、操作员、查看员
2. **项目级别**: 用户对项目的操作权限
3. **区域级别**: 用户在项目内对区域的操作权限

### 默认用户

- **管理员**: admin/admin123 - 拥有所有权限
- **操作员**: operator1/admin123 - 可以操作指定项目
- **查看员**: viewer1/admin123 - 只能查看指定项目

## 生产环境部署

### 1. 使用Systemd服务

创建服务文件 `/etc/systemd/system/monitoring.service`:

```ini
[Unit]
Description=Monitoring Alarm Platform
After=network.target postgresql.service redis.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/alarm_platform
Environment=PYTHONPATH=/opt/alarm_platform
EnvironmentFile=/opt/alarm_platform/.env
ExecStart=/opt/alarm_platform/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### 2. 使用Nginx反向代理

创建Nginx配置 `/etc/nginx/sites-available/monitoring`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 2. 使用Supervisor进程管理

创建Supervisor配置 `/etc/supervisor/conf.d/monitoring.conf`:

```ini
[program:monitoring]
command=/opt/alarm_platform/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
directory=/opt/alarm_platform
user=www-data
autostart=true
autorestart=true
environment=PYTHONPATH="/opt/alarm_platform"
stdout_logfile=/var/log/monitoring.log
stderr_logfile=/var/log/monitoring.error.log
```

## 监控和日志

### 健康检查端点

- `GET /health` - 应用健康状态
- `GET /health/db` - 数据库健康状态
- `GET /health/redis` - Redis健康状态

### 日志配置

日志输出到标准输出，可以通过系统日志服务收集。

## 故障排除

### 常见问题

1. **数据库连接失败**
   - 检查PostgreSQL服务是否运行: `sudo systemctl status postgresql`
   - 验证连接字符串配置

2. **权限错误**
   - 检查数据库用户权限
   - 验证数据库连接配置

3. **Python依赖问题**
   - 重新创建虚拟环境: `rm -rf venv && python -m venv venv`
   - 重新安装依赖: `pip install -r requirements.txt`

### 获取帮助

- 查看应用日志: `journalctl -u monitoring.service`
- 检查服务状态: `sudo systemctl status monitoring`
- 重启服务: `sudo systemctl restart monitoring`

## 备份和恢复

### 数据库备份
```bash
# 备份
pg_dump -U user -d monitoring_alarm_db > backup_$(date +%Y%m%d).sql

# 恢复
psql -U user -d monitoring_alarm_db < backup.sql
```

## 许可证

MIT License

## 更新日志

### v1.0.0 (2024-01-20)
- 初始版本发布
- 基础监控报警功能
- 多级权限系统
- 直接部署方案