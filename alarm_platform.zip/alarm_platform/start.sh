#!/bin/bash

# 监控报警平台启动脚本（非Docker版本）
set -e

echo "🚀 启动监控报警平台..."

# 检查Python是否安装
if ! command -v python &> /dev/null && ! command -v python3 &> /dev/null; then
    echo "❌ Python 未安装，请先安装 Python 3.9+"
    exit 1
fi

# 使用python3如果可用，否则使用python
PYTHON_CMD=$(command -v python3 2>/dev/null || command -v python)

# 检查Python版本
PYTHON_VERSION=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
if [ $(echo "$PYTHON_VERSION < 3.9" | bc -l) -eq 1 ]; then
    echo "❌ Python 版本需要 3.9+，当前版本: $PYTHON_VERSION"
    exit 1
fi

echo "✅ Python 版本: $PYTHON_VERSION"

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo "⏳ 创建虚拟环境..."
    $PYTHON_CMD -m venv venv
fi

# 激活虚拟环境
echo "⏳ 激活虚拟环境..."
source venv/bin/activate

# 安装依赖
echo "⏳ 安装依赖包..."
pip install -r requirements.txt

# 检查环境文件
if [ ! -f .env ]; then
    echo "⚠️  未找到 .env 文件，创建默认配置..."
    cat > .env << EOF
# 数据库配置
DATABASE_URL=postgresql://user:password@localhost:5432/monitoring_alarm_db

# Redis配置
REDIS_URL=redis://localhost:6379/0

# JWT配置
SECRET_KEY=your-secret-key-change-this-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# 应用配置
DEBUG=True
CORS_ORIGINS=["http://localhost:3000", "http://127.0.0.1:3000"]

# 邮件配置（可选）
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your-email@example.com
SMTP_PASSWORD=your-email-password
EOF
    echo "✅ 已创建 .env 文件，请根据实际情况修改配置"
fi

# 检查PostgreSQL是否运行
echo "⏳ 检查数据库服务..."
if ! command -v psql &> /dev/null; then
    echo "⚠️  PostgreSQL 客户端未安装，跳过数据库检查"
else
    if ! pg_isready -q; then
        echo "❌ PostgreSQL 服务未运行，请先启动 PostgreSQL"
        echo "   启动命令: sudo systemctl start postgresql"
        exit 1
    fi
    echo "✅ PostgreSQL 服务正常运行"
fi

# 检查Redis是否运行
echo "⏳ 检查Redis服务..."
if ! command -v redis-cli &> /dev/null; then
    echo "⚠️  Redis 客户端未安装，跳过Redis检查"
else
    if ! redis-cli ping > /dev/null 2>&1; then
        echo "❌ Redis 服务未运行，请先启动 Redis"
        echo "   启动命令: sudo systemctl start redis"
        exit 1
    fi
    echo "✅ Redis 服务正常运行"
fi

# 初始化数据库
echo "⏳ 初始化数据库..."
$PYTHON_CMD init_db.py

# 启动应用
echo "🎉 启动应用服务器..."
echo "📊 访问地址: http://localhost:8000"
echo "📖 API文档: http://localhost:8000/docs"
echo "🔐 默认用户: admin / admin123"
echo ""
echo "🛑 按 Ctrl+C 停止服务"

uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload