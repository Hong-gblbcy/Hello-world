from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import json
from typing import Optional
from ..services.audit_log import log_audit_event
from ..models.audit_log import AuditLog
from ..core.security import decode_access_token
from ..services.auth import AuthService
from ..core.database import get_db

class AuditMiddleware(BaseHTTPMiddleware):
    """审计日志中间件"""
    
    async def dispatch(self, request: Request, call_next):
        # 跳过健康检查等系统端点
        if request.url.path in ["/health", "/docs", "/openapi.json", "/system/info"]:
            return await call_next(request)
        
        # 执行请求
        response = await call_next(request)
        
        # 获取当前用户信息（如果有）
        user_id = None
        # 尝试从请求状态获取用户信息
        if hasattr(request.state, "user"):
            user_id = request.state.user.id
        else:
            # 从认证头中提取用户信息
            auth_header = request.headers.get("Authorization")
            if auth_header and auth_header.startswith("Bearer "):
                token = auth_header[7:]  # 去掉 "Bearer " 前缀
                try:
                    # 解析JWT token获取用户名
                    payload = decode_access_token(token)
                    username = payload.get("sub")
                    if username:
                        # 获取数据库会话并获取用户信息
                        async for db in get_db():
                            user = await AuthService.get_user_by_username(db, username)
                            if user:
                                user_id = user.id
                except Exception as e:
                    print(f"解析token失败: {e}")
        
        # 记录审计日志（异步执行，不阻塞请求）
        try:
            await self._log_request(request, response, user_id)
        except Exception as e:
            # 记录错误但不影响主流程
            print(f"审计日志记录失败: {e}")
        
        return response
    
    async def _log_request(self, request: Request, response: Response, user_id: Optional[int]):
        """记录请求审计日志"""
        if not user_id:
            return  # 未认证用户不记录详细审计日志
        
        # 解析请求路径获取资源类型和操作
        action, resource_type, resource_id = self._parse_request_info(request)
        
        if not action or not resource_type:
            return  # 无法识别的请求不记录
        
        # 构建描述信息
        description = self._build_description(request, response)
        
        # 记录审计日志
        await log_audit_event(
            user_id=user_id,
            action=action,
            target_type=resource_type,
            target_id=resource_id,
            old_values=None,  # 暂时留空，后续可以扩展
            new_values=None,  # 暂时留空，后续可以扩展
            request=request
        )
    
    def _parse_request_info(self, request: Request) -> tuple[Optional[str], Optional[str], Optional[int]]:
        """解析请求信息获取操作类型和资源类型"""
        path = request.url.path
        method = request.method
        
        # API路径映射
        if path.startswith("/api"):
            path_parts = path.split("/")
            
            if len(path_parts) >= 3:
                resource_type = path_parts[2]  # 例如: users, projects, areas等
                
                # 根据HTTP方法确定操作类型
                if method == "GET":
                    action = AuditLog.ACTION_VIEW
                elif method == "POST":
                    action = AuditLog.ACTION_CREATE
                elif method == "PUT" or method == "PATCH":
                    action = AuditLog.ACTION_UPDATE
                elif method == "DELETE":
                    action = AuditLog.ACTION_DELETE
                else:
                    return None, None, None
                
                # 尝试提取资源ID
                resource_id = None
                if len(path_parts) >= 4 and path_parts[3].isdigit():
                    resource_id = int(path_parts[3])
                
                return action, resource_type, resource_id
        
        # 认证相关操作
        if path == "/api/auth/login":
            return AuditLog.ACTION_LOGIN, AuditLog.RESOURCE_SYSTEM, None
        elif path == "/api/auth/logout":
            return AuditLog.ACTION_LOGOUT, AuditLog.RESOURCE_SYSTEM, None
        
        return None, None, None
    
    def _build_description(self, request: Request, response: Response) -> str:
        """构建审计日志描述信息"""
        description_parts = []
        
        # 请求信息
        description_parts.append(f"请求: {request.method} {request.url.path}")
        
        # 响应状态
        description_parts.append(f"响应: {response.status_code}")
        
        # 查询参数（如果有）
        if request.query_params:
            description_parts.append(f"查询参数: {dict(request.query_params)}")
        
        return " | ".join(description_parts)