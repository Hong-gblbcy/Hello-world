from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.core.database import Base

class Area(Base):
    __tablename__ = "areas"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(String(500), nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    parent_id = Column(Integer, ForeignKey("areas.id"), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # 关系定义
    project = relationship("Project", back_populates="areas")
    parent = relationship("Area", remote_side=[id], backref="children")
    cameras = relationship("Camera", back_populates="area")
    user_permissions = relationship("UserAreaPermission", back_populates="area")
    notifications = relationship("AreaAdminNotification", back_populates="area")

    def __repr__(self):
        return f"<Area(id={self.id}, name={self.name}, project_id={self.project_id})>"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "project_id": self.project_id,
            "parent_id": self.parent_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


class UserAreaPermission(Base):
    __tablename__ = "user_area_permissions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    area_id = Column(Integer, ForeignKey("areas.id"), nullable=False)
    created_at = Column(DateTime, default=func.now())

    # 关系定义
    user = relationship("User", back_populates="area_permissions")
    area = relationship("Area", back_populates="user_permissions")

    def __repr__(self):
        return f"<UserAreaPermission(user_id={self.user_id}, area_id={self.area_id})>"

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "area_id": self.area_id,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


class AreaAdminNotification(Base):
    __tablename__ = "area_admin_notifications"

    id = Column(Integer, primary_key=True, index=True)
    area_id = Column(Integer, ForeignKey("areas.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    alert_level = Column(String(20), nullable=False)  # 'all', 'high', 'normal'
    created_at = Column(DateTime, default=func.now())

    # 关系定义
    area = relationship("Area", back_populates="notifications")
    user = relationship("User", back_populates="notifications")

    def __repr__(self):
        return f"<AreaAdminNotification(area_id={self.area_id}, user_id={self.user_id}, alert_level={self.alert_level})>"

    def to_dict(self):
        return {
            "id": self.id,
            "area_id": self.area_id,
            "user_id": self.user_id,
            "alert_level": self.alert_level,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }