from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import enum

from app.core.database import Base

class AlertLevel(str, enum.Enum):
    HIGH = "high"
    NORMAL = "normal"

class CameraStatus(str, enum.Enum):
    ONLINE = "online"
    OFFLINE = "offline"

class Camera(Base):
    __tablename__ = "cameras"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    stream_url = Column(String(500), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    area_id = Column(Integer, ForeignKey("areas.id"), nullable=False)
    alert_level = Column(Enum(AlertLevel), default=AlertLevel.NORMAL)
    status = Column(Enum(CameraStatus), default=CameraStatus.ONLINE)
    description = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # 关系定义
    project = relationship("Project", back_populates="cameras")
    area = relationship("Area", back_populates="cameras")
    alerts = relationship("Alert", back_populates="camera")

    def __repr__(self):
        return f"<Camera(id={self.id}, name={self.name}, project_id={self.project_id})>"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "stream_url": self.stream_url,
            "project_id": self.project_id,
            "area_id": self.area_id,
            "alert_level": self.alert_level.value if self.alert_level else None,
            "status": self.status.value if self.status else None,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }