from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.core.database import Base

class AuditLog(Base):
    """审计日志模型"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, comment="操作用户ID")
    action = Column(String(100), nullable=False, comment="操作类型")
    target_type = Column(String(50), nullable=False, comment="资源类型")
    target_id = Column(Integer, nullable=True, comment="资源ID")
    old_values = Column(String(2000), nullable=True, comment="旧值")
    new_values = Column(String(2000), nullable=True, comment="新值")
    ip_address = Column(String(45), nullable=True, comment="客户端IP地址")
    created_at = Column(DateTime, default=func.now(), nullable=False, comment="创建时间")

    # 操作类型常量
    ACTION_CREATE = "create"
    ACTION_UPDATE = "update" 
    ACTION_DELETE = "delete"
    ACTION_VIEW = "view"
    ACTION_LOGIN = "login"
    ACTION_LOGOUT = "logout"
    ACTION_ALERT = "alert"
    ACTION_NOTIFICATION = "notification"

    # 资源类型常量
    RESOURCE_USER = "user"
    RESOURCE_PROJECT = "project"
    RESOURCE_AREA = "area"
    RESOURCE_CAMERA = "camera"
    RESOURCE_ALERT = "alert"
    RESOURCE_SYSTEM = "system"

    # 反向关系（暂时移除back_populates以避免循环引用问题）
    user = relationship("User")

    def __repr__(self):
        return f"<AuditLog {self.action} {self.resource_type} by user {self.user_id}>"