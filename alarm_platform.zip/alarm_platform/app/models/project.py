from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.core.database import Base

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(String(500), nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # 关系定义
    areas = relationship("Area", back_populates="project")
    cameras = relationship("Camera", back_populates="project")
    user_roles = relationship("UserProjectRole", back_populates="project")
    
    # 创建者关系
    creator = relationship("User", foreign_keys=[created_by])

    def __repr__(self):
        return f"<Project(id={self.id}, name={self.name})>"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }


class UserProjectRole(Base):
    __tablename__ = "user_project_roles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    role = Column(String(20), nullable=False)  # 'admin' or 'user'
    created_at = Column(DateTime, default=func.now())

    # 关系定义
    user = relationship("User", back_populates="projects")
    project = relationship("Project", back_populates="user_roles")

    def __repr__(self):
        return f"<UserProjectRole(user_id={self.user_id}, project_id={self.project_id}, role={self.role})>"

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "project_id": self.project_id,
            "role": self.role,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }