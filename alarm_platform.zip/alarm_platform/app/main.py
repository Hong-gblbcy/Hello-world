from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.core.config import settings
from app.core.database import async_engine, Base, get_db
from app.api import auth, projects, areas, cameras, alerts, audit_logs
from app.models.user import User
from app.core.security import get_password_hash

# 创建数据库表的异步函数
async def create_tables():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

app = FastAPI(
    title="监控管理与报警系统 API",
    description="基于三级权限管理的监控报警系统后端API",
    version="1.0.0",
    docs_url=None,  # 禁用默认docs，使用自定义
    redoc_url=None,  # 禁用默认redoc
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应限制为具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 添加审计日志中间件
from app.middleware.audit_middleware import AuditMiddleware
app.add_middleware(AuditMiddleware)

# 注册路由
app.include_router(auth.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(areas.router, prefix="/api")
app.include_router(cameras.router, prefix="/api")
app.include_router(alerts.router, prefix="/api")
app.include_router(audit_logs.router, prefix="/api")

# 自定义API文档
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url="/openapi.json",
        title="监控管理与报警系统 API - Swagger UI",
        swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
        swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
    )

@app.get("/openapi.json", include_in_schema=False)
async def get_custom_openapi():
    return get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )

# 健康检查端点
@app.get("/health", tags=["系统"])
async def health_check():
    """系统健康检查"""
    return {"status": "healthy", "message": "系统运行正常"}

# 系统信息端点
@app.get("/system/info", tags=["系统"])
async def system_info():
    """获取系统信息"""
    return {
        "name": "监控管理与报警系统",
        "version": "1.0.0",
        "description": "基于三级权限管理的监控报警系统",
        "author": "系统开发团队",
        "contact": {
            "email": "support@monitoring-system.com"
        }
    }

# 初始化超级管理员账户
@app.on_event("startup")
async def startup_event():
    """应用启动时初始化超级管理员账户"""
    # 先创建数据库表
    await create_tables()
    
    # 然后初始化超级管理员
    async for db in get_db():
        try:
            # 检查是否已存在超级管理员
            from sqlalchemy import select
            result = await db.execute(select(User).filter(User.username == "admin"))
            superadmin = result.scalar_one_or_none()
            if not superadmin:
                # 创建默认超级管理员
                hashed_password = get_password_hash("admin123")
                admin_user = User(
                    username="admin",
                    password_hash=hashed_password,
                    name="系统管理员",
                    email="admin@monitoring-system.com",
                    is_superadmin=True,
                    is_active=True
                )
                db.add(admin_user)
                await db.commit()
                print("✅ 超级管理员账户已创建: admin/admin123")
            else:
                print("✅ 超级管理员账户已存在")
        except Exception as e:
            print(f"❌ 初始化超级管理员失败: {e}")
            await db.rollback()
        finally:
            await db.close()

# 全局异常处理
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "服务器内部错误"},
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info" if settings.DEBUG else "warning"
    )