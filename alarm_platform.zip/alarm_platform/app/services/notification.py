from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
import logging
from datetime import datetime

from app.models.alert import Alert
from app.models.user import User
from app.models.area import AreaAdminNotification
from app.models.camera import Camera
from app.core.config import settings

logger = logging.getLogger(__name__)

class NotificationService:
    """通知服务类，处理报警通知发送"""
    
    @staticmethod
    async def send_alert_notification(db: AsyncSession, alert_id: int) -> bool:
        """
        发送报警通知
        
        Args:
            db: 异步数据库会话
            alert_id: 报警ID
            
        Returns:
            bool: 是否成功发送通知
        """
        try:
            # 获取报警详情
            result = await db.execute(
                select(Alert).filter(Alert.id == alert_id)
            )
            alert = result.scalar_one_or_none()
            if not alert:
                logger.error(f"报警ID {alert_id} 不存在")
                return False
            
            # 获取需要通知的用户
            users_to_notify = await NotificationService._get_users_to_notify(db, alert)
            
            if not users_to_notify:
                logger.warning(f"报警ID {alert_id} 没有需要通知的用户")
                return True
            
            # 发送通知给每个用户
            success_count = 0
            for user in users_to_notify:
                if await NotificationService._send_single_notification(user, alert):
                    success_count += 1
            
            logger.info(f"报警ID {alert_id} 通知发送完成，成功: {success_count}/{len(users_to_notify)}")
            return success_count > 0
            
        except Exception as e:
            logger.error(f"发送报警通知失败: {str(e)}")
            return False
    
    @staticmethod
    async def _get_users_to_notify(db: AsyncSession, alert: Alert) -> List[User]:
        """
        获取需要接收通知的用户列表
        
        Args:
            db: 异步数据库会话
            alert: 报警对象
            
        Returns:
            List[User]: 需要通知的用户列表
        """
        users = []
        
        # 首先获取摄像头信息以获取区域和项目ID
        result = await db.execute(
            select(Camera).filter(Camera.id == alert.camera_id)
        )
        camera = result.scalar_one_or_none()
        
        if not camera:
            logger.error(f"摄像头ID {alert.camera_id} 不存在")
            return []
        
        # 根据报警级别和区域获取需要通知的用户
        if camera.area_id:
            # 获取该区域的通知配置
            result = await db.execute(
                select(AreaAdminNotification).filter(
                    AreaAdminNotification.area_id == camera.area_id
                )
            )
            notifications = result.scalars().all()
            
            for notification in notifications:
                result = await db.execute(
                    select(User).filter(User.id == notification.user_id)
                )
                user = result.scalar_one_or_none()
                if user and user.is_active:
                    # 检查报警级别是否符合通知配置
                    if (notification.alert_level == "all" or
                        notification.alert_level == alert.alert_level):
                        users.append(user)
        
        # 如果没有配置区域通知，通知项目管理员
        if not users and camera.project_id:
            from app.services.permission import AsyncPermissionService
            project_admins = await AsyncPermissionService.get_project_admins(db, camera.project_id)
            users.extend([admin for admin in project_admins if admin.is_active])
        
        # 去重
        unique_users = []
        user_ids = set()
        for user in users:
            if user.id not in user_ids:
                unique_users.append(user)
                user_ids.add(user.id)
        
        return unique_users
    
    @staticmethod
    async def _send_single_notification(user: User, alert: Alert) -> bool:
        """
        发送单个通知给用户
        
        Args:
            user: 用户对象
            alert: 报警对象
            
        Returns:
            bool: 是否成功发送
        """
        try:
            # 构建通知消息
            message = await NotificationService._build_notification_message(alert)
            
            # 根据用户配置发送通知（这里实现多种通知渠道）
            success = True
            
            # 1. 邮件通知
            if user.email and settings.EMAIL_ENABLED:
                success &= await NotificationService._send_email_notification(user.email, message)
            
            # 2. 短信通知（如果配置了手机号）
            if user.phone and settings.SMS_ENABLED:
                success &= await NotificationService._send_sms_notification(user.phone, message)
            
            # 3. 站内消息
            success &= await NotificationService._send_internal_message(user.id, message)
            
            # 4. Webhook 通知（系统集成）
            if settings.WEBHOOK_ENABLED:
                success &= await NotificationService._send_webhook_notification(user, alert, message)
            
            logger.info(f"用户 {user.username} 报警通知发送{'成功' if success else '失败'}")
            return success
            
        except Exception as e:
            logger.error(f"发送用户 {user.username} 通知失败: {str(e)}")
            return False
    
    @staticmethod
    async def _build_notification_message(alert: Alert) -> str:
        """构建通知消息内容"""
        # 由于我们简化了响应模型，这里需要从数据库加载相关对象
        camera_name = "未知"
        area_name = "未知"
        project_name = "未知"
        
        return f"""
报警通知 - {alert.alert_level.upper()} 级别

报警类型: {alert.alert_type}
报警描述: {alert.description or '无详细描述'}
发生时间: {alert.triggered_at.strftime('%Y-%m-%d %H:%M:%S')}
摄像头: {camera_name}
区域: {area_name}
项目: {project_name}

请及时处理！
"""
    
    @staticmethod
    async def _send_email_notification(email: str, message: str) -> bool:
        """发送邮件通知（待实现）"""
        logger.info(f"模拟发送邮件到 {email}: {message[:100]}...")
        return True
    
    @staticmethod
    async def _send_sms_notification(phone: str, message: str) -> bool:
        """发送短信通知（待实现）"""
        logger.info(f"模拟发送短信到 {phone}: {message[:100]}...")
        return True
    
    @staticmethod
    async def _send_internal_message(user_id: int, message: str) -> bool:
        """发送站内消息（待实现）"""
        logger.info(f"模拟发送站内消息给用户 {user_id}: {message[:100]}...")
        return True
    
    @staticmethod
    async def _send_webhook_notification(user: User, alert: Alert, message: str) -> bool:
        """发送Webhook通知（待实现）"""
        logger.info(f"模拟发送Webhook通知: 用户={user.username}, 报警ID={alert.id}")
        return True


# 兼容性函数 - 用于API路由中的异步调用
async def send_alert_notification(alert_id: int) -> bool:
    """
    异步发送报警通知（兼容性函数）
    
    Args:
        alert_id: 报警ID
        
    Returns:
        bool: 是否成功发送
    """
    from app.core.database import AsyncSessionLocal, get_db
    async with AsyncSessionLocal() as db:
        try:
            return await NotificationService.send_alert_notification(db, alert_id)
        except Exception as e:
            logger.error(f"发送通知失败: {str(e)}")
            return False