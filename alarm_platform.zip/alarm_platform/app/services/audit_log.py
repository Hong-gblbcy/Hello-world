from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from fastapi import Request
from ..models.audit_log import AuditLog
from ..schemas.audit_log import AuditLogCreate, AuditLogResponse
from ..core.database import AsyncSessionLocal

class AuditLogService:
    """审计日志服务"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_audit_log(
        self,
        user_id: int,
        action: str,
        target_type: str,
        target_id: Optional[int] = None,
        old_values: Optional[str] = None,
        new_values: Optional[str] = None,
        ip_address: Optional[str] = None
    ) -> AuditLog:
        """创建审计日志记录"""
        audit_log = AuditLog(
            user_id=user_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            old_values=old_values,
            new_values=new_values,
            ip_address=ip_address
        )
        
        self.db.add(audit_log)
        await self.db.commit()
        await self.db.refresh(audit_log)
        return audit_log
    
    async def get_audit_logs(
        self,
        skip: int = 0,
        limit: int = 100,
        user_id: Optional[int] = None,
        action: Optional[str] = None,
        target_type: Optional[str] = None
    ) -> list[AuditLog]:
        """获取审计日志列表"""
        query = select(AuditLog).order_by(AuditLog.created_at.desc())
        
        if user_id:
            query = query.where(AuditLog.user_id == user_id)
        if action:
            query = query.where(AuditLog.action == action)
        if target_type:
            query = query.where(AuditLog.target_type == target_type)
        
        query = query.offset(skip).limit(limit)
        result = await self.db.execute(query)
        return result.scalars().all()
    
    async def get_audit_log_by_id(self, log_id: int) -> Optional[AuditLog]:
        """根据ID获取审计日志"""
        result = await self.db.execute(
            select(AuditLog).where(AuditLog.id == log_id)
        )
        return result.scalar_one_or_none()

async def log_audit_event(
    user_id: int,
    action: str,
    target_type: str,
    target_id: Optional[int] = None,
    old_values: Optional[str] = None,
    new_values: Optional[str] = None,
    request: Optional[Request] = None
) -> None:
    """快速记录审计事件的辅助函数"""
    ip_address = None
    
    if request:
        ip_address = request.client.host if request.client else None
    
    async with AsyncSessionLocal() as db:
        service = AuditLogService(db)
        await service.create_audit_log(
            user_id=user_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            old_values=old_values,
            new_values=new_values,
            ip_address=ip_address
        )

def get_client_info(request: Request) -> tuple[Optional[str], Optional[str]]:
    """从请求中获取客户端信息"""
    ip_address = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    return ip_address, user_agent