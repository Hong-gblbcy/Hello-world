from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from ..core.database import get_db
from ..services.audit_log import AuditLogService
from ..schemas.audit_log import AuditLogResponse, AuditLogQueryParams
from ..services.auth import get_current_user
from ..models.user import User

router = APIRouter(prefix="/audit-logs", tags=["audit-logs"])

@router.get("/", response_model=list[AuditLogResponse])
async def get_audit_logs(
    params: AuditLogQueryParams = Depends(),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取审计日志列表（仅限超级管理员）"""
    if not current_user.is_superadmin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="只有超级管理员可以查看审计日志"
        )
    
    service = AuditLogService(db)
    logs = await service.get_audit_logs(
        skip=params.skip,
        limit=params.limit,
        user_id=params.user_id,
        action=params.action,
        target_type=params.target_type
    )
    return logs

@router.get("/{log_id}", response_model=AuditLogResponse)
async def get_audit_log(
    log_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """根据ID获取审计日志详情（仅限超级管理员）"""
    if not current_user.is_superadmin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="只有超级管理员可以查看审计日志"
        )
    
    service = AuditLogService(db)
    log = await service.get_audit_log_by_id(log_id)
    if not log:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="审计日志不存在"
        )
    return log