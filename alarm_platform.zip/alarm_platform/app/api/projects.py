from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List, Optional, Any
from sqlalchemy import func, desc

from app.core.database import get_db
from app.core.security import get_current_user, get_current_superuser
from app.schemas.project import (
    ProjectCreate, 
    ProjectResponse, 
    ProjectUpdate,
    ProjectListResponse,
    ProjectUserCreate,
    ProjectUserResponse,
    ProjectStatsResponse,
    ProjectSummaryResponse
)
from app.schemas.common import PaginationParams, MessageResponse, ErrorResponse
from app.services.permission import AsyncPermissionService
from app.models.project import Project, UserProjectRole
from app.models.area import Area
from app.models.camera import Camera
from app.models.alert import Alert
from app.models.user import User

router = APIRouter(prefix="/projects", tags=["项目管理"])

@router.get(
    "",
    response_model=ProjectListResponse,
    responses={401: {"model": ErrorResponse, "description": "认证失败"}}
)
async def get_projects(
    pagination: PaginationParams = Depends(),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    获取用户有权限访问的项目列表
    
    - **page**: 页码（默认1）
    - **page_size**: 每页数量（默认20）
    
    返回分页的项目列表
    """
    # 获取用户有权限的项目
    projects = await AsyncPermissionService.get_user_projects(db, current_user.id)
    project_ids = [p.id for p in projects]
    
    if not project_ids:
        return ProjectListResponse(
            items=[], total=0, page=1, page_size=20, total_pages=0
        )
    
    # 分页查询
    total = len(project_ids)
    offset = (pagination.page - 1) * pagination.page_size
    if project_ids:
        result = await db.execute(
            select(Project)
            .filter(Project.id.in_(project_ids))
            .order_by(desc(Project.created_at))
            .offset(offset)
            .limit(pagination.page_size)
        )
        projects_page = result.scalars().all()
    else:
        projects_page = []
    
    total_pages = (total + pagination.page_size - 1) // pagination.page_size
    
    return ProjectListResponse(
        items=projects_page,
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
        total_pages=total_pages
    )

@router.post(
    "",
    response_model=ProjectResponse,
    responses={
        403: {"model": ErrorResponse, "description": "权限不足"},
        400: {"model": ErrorResponse, "description": "项目名称已存在"}
    }
)
async def create_project(
    project_data: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    创建新项目（需要超级管理员权限）
    
    - **name**: 项目名称
    - **description**: 项目描述（可选）
    
    返回创建的项目信息
    """
    # 检查项目名称是否已存在
    result = await db.execute(
        select(Project).filter(Project.name == project_data.name)
    )
    existing_project = result.scalar_one_or_none()
    if existing_project:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="项目名称已存在"
        )
    
    project = Project(
        name=project_data.name,
        description=project_data.description,
        created_by=current_user.id
    )
    
    db.add(project)
    await db.commit()
    await db.refresh(project)
    
    return project

@router.get(
    "/{project_id}",
    response_model=ProjectResponse,
    responses={
        404: {"model": ErrorResponse, "description": "项目不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"}
    }
)
async def get_project(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    获取项目详情
    
    - **project_id**: 项目ID
    
    返回项目详情信息
    """
    # 检查权限
    if not await AsyncPermissionService.check_project_access(db, current_user.id, project_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有访问该项目的权限"
        )
    
    result = await db.execute(select(Project).filter(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="项目不存在"
        )
    
    return project

@router.put(
    "/{project_id}",
    response_model=ProjectResponse,
    responses={
        404: {"model": ErrorResponse, "description": "项目不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"},
        400: {"model": ErrorResponse, "description": "项目名称已存在"}
    }
)
async def update_project(
    project_id: int,
    project_data: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    更新项目信息（需要项目管理员或超级管理员权限）
    
    - **project_id**: 项目ID
    - **name**: 项目名称（可选）
    - **description**: 项目描述（可选）
    
    返回更新后的项目信息
    """
    # 检查权限
    if not await AsyncPermissionService.check_project_admin(db, current_user.id, project_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有修改该项目的权限"
        )
    
    result = await db.execute(select(Project).filter(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="项目不存在"
        )
    
    # 检查项目名称是否已存在（排除当前项目）
    if project_data.name and project_data.name != project.name:
        result = await db.execute(
            select(Project).filter(
                Project.name == project_data.name,
                Project.id != project_id
            )
        )
        existing_project = result.scalar_one_or_none()
        if existing_project:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="项目名称已存在"
            )
        project.name = project_data.name
    
    if project_data.description is not None:
        project.description = project_data.description
    
    await db.commit()
    await db.refresh(project)
    
    return project

@router.delete(
    "/{project_id}",
    response_model=MessageResponse,
    responses={
        404: {"model": ErrorResponse, "description": "项目不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"}
    }
)
async def delete_project(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    删除项目（需要超级管理员权限）
    
    - **project_id**: 项目ID
    
    返回成功消息
    """
    result = await db.execute(select(Project).filter(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="项目不存在"
        )
    
    await db.delete(project)
    await db.commit()
    
    return MessageResponse(message="项目删除成功")

@router.get(
    "/{project_id}/stats",
    response_model=ProjectStatsResponse,
    responses={
        404: {"model": ErrorResponse, "description": "项目不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"}
    }
)
async def get_project_stats(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    获取项目统计信息
    
    - **project_id**: 项目ID
    
    返回项目统计信息
    """
    # 检查权限
    if not await AsyncPermissionService.check_project_access(db, current_user.id, project_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有访问该项目的权限"
        )
    
    # 统计区域数量
    result = await db.execute(
        select(func.count(Area.id)).filter(Area.project_id == project_id)
    )
    area_count = result.scalar_one()
    
    # 统计摄像头数量
    result = await db.execute(
        select(func.count(Camera.id)).filter(Camera.project_id == project_id)
    )
    camera_count = result.scalar_one()
    
    # 统计用户数量（通过区域权限）
    result = await db.execute(
        select(Area).filter(Area.project_id == project_id)
    )
    areas = result.scalars().all()
    area_ids = [area.id for area in areas]
    user_count = 0
    if area_ids:
        from app.models.area import UserAreaPermission
        result = await db.execute(
            select(func.count(func.distinct(UserAreaPermission.user_id)))
            .filter(UserAreaPermission.area_id.in_(area_ids))
        )
        user_count = result.scalar_one()
    
    # 统计报警数量
    result = await db.execute(
        select(func.count(Alert.id))
        .filter(
            Alert.camera_id.in_(
                select(Camera.id).filter(Camera.project_id == project_id)
            ),
            Alert.status.in_(["pending", "processing"])
        )
    )
    active_alerts = result.scalar_one()
    
    result = await db.execute(
        select(func.count(Alert.id))
        .filter(
            Alert.camera_id.in_(
                select(Camera.id).filter(Camera.project_id == project_id)
            ),
            Alert.status == "resolved"
        )
    )
    resolved_alerts = result.scalar_one()
    
    return ProjectStatsResponse(
        total_projects=1,
        total_areas=area_count,
        total_cameras=camera_count,
        total_users=user_count,
        active_alerts=active_alerts,
        resolved_alerts=resolved_alerts
    )

@router.get(
    "/{project_id}/users",
    response_model=List[ProjectUserResponse],
    responses={
        404: {"model": ErrorResponse, "description": "项目不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"}
    }
)
async def get_project_users(
    project_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    获取项目下的用户列表
    
    - **project_id**: 项目ID
    
    返回项目用户列表
    """
    # 检查权限
    if not await AsyncPermissionService.check_project_access(db, current_user.id, project_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有访问该项目的权限"
        )
    
    # 获取项目用户角色
    result = await db.execute(
        select(UserProjectRole).filter(UserProjectRole.project_id == project_id)
    )
    user_roles = result.scalars().all()
    
    return user_roles

@router.post(
    "/{project_id}/users",
    response_model=ProjectUserResponse,
    responses={
        404: {"model": ErrorResponse, "description": "项目或用户不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"},
        400: {"model": ErrorResponse, "description": "用户已在项目中"}
    }
)
async def add_project_user(
    project_id: int,
    user_data: ProjectUserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    添加用户到项目（需要超级管理员权限）
    
    - **project_id**: 项目ID
    - **user_id**: 用户ID
    - **role**: 角色（admin/user）
    
    返回添加的用户角色信息
    """
    # 检查项目是否存在
    result = await db.execute(select(Project).filter(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="项目不存在"
        )
    
    # 检查用户是否存在
    result = await db.execute(select(User).filter(User.id == user_data.user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不存在"
        )
    
    # 检查用户是否已在项目中
    result = await db.execute(
        select(UserProjectRole).filter(
            UserProjectRole.project_id == project_id,
            UserProjectRole.user_id == user_data.user_id
        )
    )
    existing_role = result.scalar_one_or_none()
    if existing_role:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="用户已在项目中"
        )
    
    # 创建用户项目角色
    user_role = UserProjectRole(
        user_id=user_data.user_id,
        project_id=project_id,
        role=user_data.role
    )
    
    db.add(user_role)
    await db.commit()
    await db.refresh(user_role)
    
    return user_role

@router.delete(
    "/{project_id}/users/{user_id}",
    response_model=MessageResponse,
    responses={
        404: {"model": ErrorResponse, "description": "项目或用户不存在"},
        403: {"model": ErrorResponse, "description": "权限不足"}
    }
)
async def remove_project_user(
    project_id: int,
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    从项目中移除用户（需要超级管理员权限）
    
    - **project_id**: 项目ID
    - **user_id**: 用户ID
    
    返回成功消息
    """
    # 检查用户项目角色是否存在
    result = await db.execute(
        select(UserProjectRole).filter(
            UserProjectRole.project_id == project_id,
            UserProjectRole.user_id == user_id
        )
    )
    user_role = result.scalar_one_or_none()
    
    if not user_role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="用户不在项目中"
        )
    
    await db.delete(user_role)
    await db.commit()
    
    return MessageResponse(message="用户已从项目中移除")