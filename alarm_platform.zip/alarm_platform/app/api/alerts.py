from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List, Optional
from sqlalchemy import func
from datetime import datetime, timedelta

from app.core.database import get_db
from app.core.security import get_current_user
from app.services.permission import check_project_permission, check_area_permission, check_camera_permission
from app.models.alert import Alert
from app.models.camera import Camera
from app.models.area import Area
from app.models.project import Project
from app.models.user import User
from app.schemas.alert import AlertCreate, AlertUpdate, AlertResponse, AlertStatus, AlertLevel
from app.services.notification import send_alert_notification

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("/", response_model=List[AlertResponse], summary="获取报警列表")
async def list_alerts(
    project_id: Optional[int] = None,
    area_id: Optional[int] = None,
    camera_id: Optional[int] = None,
    status: Optional[AlertStatus] = None,
    level: Optional[AlertLevel] = None,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    page: int = 1,
    page_size: int = 20,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取报警列表，支持多种过滤条件
    """
    # 构建查询条件
    conditions = []
    
    if project_id is not None:
        # 检查项目权限
        await check_project_permission(db, current_user.id, project_id, "view")
        conditions.append(Alert.project_id == project_id)
    
    if area_id is not None:
        # 检查区域权限
        await check_area_permission(db, current_user.id, area_id, "view")
        conditions.append(Alert.area_id == area_id)
    
    if camera_id is not None:
        # 检查摄像头权限
        await check_camera_permission(db, current_user.id, camera_id, "view")
        conditions.append(Alert.camera_id == camera_id)
    
    if status is not None:
        conditions.append(Alert.status == status)
    
    if level is not None:
        conditions.append(Alert.alert_level == level)
    
    if start_time is not None:
        conditions.append(Alert.triggered_at >= start_time)
    
    if end_time is not None:
        conditions.append(Alert.triggered_at <= end_time)
    
    # 计算分页
    offset = (page - 1) * page_size
    
    # 执行查询
    result = await db.execute(
        select(Alert)
        .filter(*conditions)
        .order_by(Alert.triggered_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    alerts = result.scalars().all()
    
    return alerts


@router.get("/{alert_id}", response_model=AlertResponse, summary="获取报警详情")
async def get_alert(
    alert_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    根据ID获取报警详情
    """
    result = await db.execute(select(Alert).filter(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="报警记录不存在"
        )
    
    # 检查权限
    if alert.project_id:
        await check_project_permission(db, current_user.id, alert.project_id, "view")
    
    return alert


@router.post("/", response_model=AlertResponse, status_code=status.HTTP_201_CREATED, summary="创建报警")
async def create_alert(
    alert_data: AlertCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    创建新报警记录（支持外部系统集成）
    """
    # 验证摄像头权限
    if not alert_data.camera_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="必须指定摄像头ID"
        )
    
    await check_camera_permission(db, current_user.id, alert_data.camera_id, "view")
    
    # 创建报警
    alert = Alert(**alert_data.dict())
    db.add(alert)
    await db.commit()
    await db.refresh(alert)
    
    # 后台发送通知
    background_tasks.add_task(send_alert_notification, alert.id)
    
    return alert


@router.put("/{alert_id}", response_model=AlertResponse, summary="更新报警信息")
async def update_alert(
    alert_id: int,
    alert_data: AlertUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    更新报警信息
    """
    result = await db.execute(select(Alert).filter(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="报警记录不存在"
        )
    
    # 检查权限
    if alert.project_id:
        await check_project_permission(db, current_user.id, alert.project_id, "edit")
    
    # 更新报警信息
    update_data = alert_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(alert, field, value)
    
    await db.commit()
    await db.refresh(alert)
    
    return alert


@router.patch("/{alert_id}/acknowledge", response_model=AlertResponse, summary="确认报警")
async def acknowledge_alert(
    alert_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    确认报警（标记为处理中）
    """
    result = await db.execute(select(Alert).filter(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="报警记录不存在"
        )
    
    # 检查权限
    if alert.project_id:
        await check_project_permission(db, current_user.id, alert.project_id, "edit")
    
    # 更新报警状态
    alert.status = "processing"
    
    await db.commit()
    await db.refresh(alert)
    
    return alert


@router.patch("/{alert_id}/resolve", response_model=AlertResponse, summary="解决报警")
async def resolve_alert(
    alert_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    解决报警（标记为已解决）
    """
    result = await db.execute(select(Alert).filter(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="报警记录不存在"
        )
    
    # 检查权限
    if alert.project_id:
        await check_project_permission(db, current_user.id, alert.project_id, "edit")
    
    # 更新报警状态
    alert.status = "resolved"
    alert.resolved_by = current_user.id
    alert.resolved_at = datetime.utcnow()
    
    await db.commit()
    await db.refresh(alert)
    
    return alert


@router.patch("/{alert_id}/close", response_model=AlertResponse, summary="关闭报警")
async def close_alert(
    alert_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    关闭报警（标记为已关闭）
    """
    result = await db.execute(select(Alert).filter(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="报警记录不存在"
        )
    
    # 检查权限
    if alert.project_id:
        await check_project_permission(db, current_user.id, alert.project_id, "edit")
    
    # 更新报警状态
    alert.status = "closed"
    
    await db.commit()
    await db.refresh(alert)
    
    return alert


@router.get("/project/{project_id}/stats", summary="获取项目报警统计")
async def get_alert_stats(
    project_id: int,
    period: str = "24h",  # 24h, 7d, 30d
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取项目的报警统计信息
    """
    # 检查项目权限
    await check_project_permission(db, current_user.id, project_id, "view")
    
    # 计算时间范围
    now = datetime.utcnow()
    if period == "24h":
        start_time = now - timedelta(hours=24)
    elif period == "7d":
        start_time = now - timedelta(days=7)
    elif period == "30d":
        start_time = now - timedelta(days=30)
    else:
        start_time = now - timedelta(hours=24)
    
    # 获取报警统计
    result = await db.execute(
        select(
            Alert.alert_level,
            Alert.status,
            func.count(Alert.id)
        ).filter(
            Alert.project_id == project_id,
            Alert.triggered_at >= start_time
        ).group_by(Alert.alert_level, Alert.alert_status)
    )
    
    stats = result.all()
    
    # 组织统计结果
    summary = {
        "total": 0,
        "by_level": {"critical": 0, "warning": 0, "info": 0},
        "by_status": {"pending": 0, "processing": 0, "resolved": 0, "closed": 0},
        "time_period": period
    }
    
    for level, status, count in stats:
        summary["total"] += count
        summary["by_level"][level] += count
        summary["by_status"][status] += count
    
    return summary


@router.get("/recent/unresolved", response_model=List[AlertResponse], summary="获取未解决的报警")
async def get_unresolved_alerts(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取用户有权限查看的未解决报警
    """
    # 获取用户有权限的项目
    from app.services.permission import get_user_accessible_projects
    accessible_projects = await get_user_accessible_projects(db, current_user.id)
    
    if not accessible_projects:
        return []
    
    # 获取未解决的报警
    result = await db.execute(
        select(Alert).filter(
            Alert.project_id.in_(accessible_projects),
            Alert.status.in_(["pending", "processing"])
        ).order_by(
            Alert.alert_level.desc(),
            Alert.triggered_at.desc()
        ).limit(50)
    )
    
    alerts = result.scalars().all()
    return alerts


@router.post("/external", response_model=AlertResponse, status_code=status.HTTP_201_CREATED, summary="外部系统创建报警")
async def create_external_alert(
    alert_data: AlertCreate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    外部系统创建报警（无需认证，用于系统集成）
    """
    # 验证必要字段
    if not alert_data.alert_source == "external":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="外部报警必须指定alert_source为'external'"
        )
    
    if not alert_data.external_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="外部报警必须提供external_id"
        )
    
    # 检查是否已存在相同external_id的报警
    result = await db.execute(
        select(Alert).filter(Alert.external_id == alert_data.external_id)
    )
    existing_alert = result.scalar_one_or_none()
    
    if existing_alert:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="已存在相同external_id的报警"
        )
    
    # 创建报警
    alert = Alert(**alert_data.dict())
    db.add(alert)
    await db.commit()
    await db.refresh(alert)
    
    # 后台发送通知
    background_tasks.add_task(send_alert_notification, alert.id)
    
    return alert