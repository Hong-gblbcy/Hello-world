from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List, Optional

from app.core.database import get_db
from app.core.security import get_current_user
from app.services.permission import check_project_permission, check_area_permission
from app.models.area import Area
from app.models.project import Project
from app.models.user import User
from app.schemas.area import AreaCreate, AreaUpdate, AreaResponse, AreaTreeResponse

router = APIRouter(prefix="/areas", tags=["areas"])


@router.get("/", response_model=List[AreaResponse], summary="获取区域列表")
async def list_areas(
    project_id: Optional[int] = None,
    parent_id: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取区域列表，支持按项目和父区域过滤
    """
    # 构建查询条件
    conditions = []
    if project_id is not None:
        # 检查项目权限
        await check_project_permission(db, current_user.id, project_id, "view")
        conditions.append(Area.project_id == project_id)
    if parent_id is not None:
        conditions.append(Area.parent_id == parent_id)
    else:
        conditions.append(Area.parent_id.is_(None))
    
    # 执行查询
    result = await db.execute(
        select(Area).filter(*conditions).order_by(Area.name)
    )
    areas = result.scalars().all()
    
    return areas


@router.get("/tree", response_model=List[AreaTreeResponse], summary="获取区域树形结构")
async def get_area_tree(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取项目的区域树形结构
    """
    # 检查项目权限
    await check_project_permission(db, current_user.id, project_id, "view")
    
    # 获取所有区域
    result = await db.execute(
        select(Area).filter(Area.project_id == project_id).order_by(Area.name)
    )
    areas = result.scalars().all()
    
    # 构建树形结构
    area_dict = {area.id: AreaTreeResponse(**area.__dict__, children=[]) for area in areas}
    tree = []
    
    for area in areas:
        if area.parent_id is None:
            tree.append(area_dict[area.id])
        else:
            parent = area_dict.get(area.parent_id)
            if parent:
                parent.children.append(area_dict[area.id])
    
    return tree


@router.get("/{area_id}", response_model=AreaResponse, summary="获取区域详情")
async def get_area(
    area_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    根据ID获取区域详情
    """
    # 检查区域权限
    await check_area_permission(db, current_user.id, area_id, "view")
    
    result = await db.execute(select(Area).filter(Area.id == area_id))
    area = result.scalar_one_or_none()
    
    if not area:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="区域不存在"
        )
    
    return area


@router.post("/", response_model=AreaResponse, status_code=status.HTTP_201_CREATED, summary="创建区域")
async def create_area(
    area_data: AreaCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    创建新区域
    """
    # 检查项目权限
    await check_project_permission(db, current_user.id, area_data.project_id, "edit")
    
    # 如果指定了父区域，检查父区域权限
    if area_data.parent_id:
        await check_area_permission(db, current_user.id, area_data.parent_id, "edit")
    
    # 检查区域名称是否重复
    result = await db.execute(
        select(Area).filter(
            Area.project_id == area_data.project_id,
            Area.name == area_data.name
        )
    )
    existing_area = result.scalar_one_or_none()
    if existing_area:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="同一项目中区域名称不能重复"
        )
    
    # 创建区域
    area = Area(**area_data.dict())
    db.add(area)
    await db.commit()
    await db.refresh(area)
    
    # 重新查询以确保所有关系字段被正确加载
    result = await db.execute(
        select(Area).filter(Area.id == area.id)
    )
    area = result.scalar_one()
    
    return area


@router.put("/{area_id}", response_model=AreaResponse, summary="更新区域")
async def update_area(
    area_id: int,
    area_data: AreaUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    更新区域信息
    """
    # 检查区域权限
    await check_area_permission(db, current_user.id, area_id, "edit")
    
    result = await db.execute(select(Area).filter(Area.id == area_id))
    area = result.scalar_one_or_none()
    
    if not area:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="区域不存在"
        )
    
    # 如果修改了名称，检查是否重复
    if area_data.name and area_data.name != area.name:
        result = await db.execute(
            select(Area).filter(
                Area.project_id == area.project_id,
                Area.name == area_data.name,
                Area.id != area_id
            )
        )
        existing_area = result.scalar_one_or_none()
        if existing_area:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="同一项目中区域名称不能重复"
            )
    
    # 更新区域信息
    update_data = area_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(area, field, value)
    
    await db.commit()
    await db.refresh(area)
    
    return area


@router.delete("/{area_id}", status_code=status.HTTP_204_NO_CONTENT, summary="删除区域")
async def delete_area(
    area_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    删除区域（会同时删除子区域）
    """
    # 检查区域权限
    await check_area_permission(db, current_user.id, area_id, "delete")
    
    result = await db.execute(select(Area).filter(Area.id == area_id))
    area = result.scalar_one_or_none()
    
    if not area:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="区域不存在"
        )
    
    # 检查是否有子区域
    result = await db.execute(
        select(Area).filter(Area.parent_id == area_id)
    )
    child_areas = result.scalars().all()
    
    if child_areas:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请先删除所有子区域"
        )
    
    # 删除区域
    await db.delete(area)
    await db.commit()
    
    return None


@router.get("/project/{project_id}/hierarchy", response_model=List[AreaTreeResponse], summary="获取项目区域层级")
async def get_project_area_hierarchy(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取项目的完整区域层级结构
    """
    # 检查项目权限
    await check_project_permission(db, current_user.id, project_id, "view")
    
    return await get_area_tree(project_id, current_user, db)