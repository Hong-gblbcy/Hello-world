from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List, Optional
from sqlalchemy import func

from app.core.database import get_db
from app.core.security import get_current_user
from app.services.permission import check_area_permission, check_project_permission
from app.models.camera import Camera
from app.models.area import Area
from app.models.user import User
from app.schemas.camera import CameraCreate, CameraUpdate, CameraResponse, CameraStatus

router = APIRouter(prefix="/cameras", tags=["cameras"])


@router.get("/", response_model=List[CameraResponse], summary="获取摄像头列表")
async def list_cameras(
    area_id: Optional[int] = None,
    project_id: Optional[int] = None,
    status: Optional[CameraStatus] = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取摄像头列表，支持按区域、项目和状态过滤
    """
    # 构建查询条件
    conditions = []
    
    if area_id is not None:
        # 检查区域权限
        await check_area_permission(db, current_user.id, area_id, "view")
        conditions.append(Camera.area_id == area_id)
    elif project_id is not None:
        # 检查项目权限
        await check_project_permission(db, current_user.id, project_id, "view")
        # 获取项目下的所有区域
        result = await db.execute(
            select(Area.id).filter(Area.project_id == project_id)
        )
        area_ids = [area_id for (area_id,) in result.all()]
        if area_ids:
            conditions.append(Camera.area_id.in_(area_ids))
        else:
            return []
    
    if status is not None:
        conditions.append(Camera.status == status)
    
    # 执行查询
    result = await db.execute(
        select(Camera).filter(*conditions).order_by(Camera.name)
    )
    cameras = result.scalars().all()
    
    return cameras


@router.get("/{camera_id}", response_model=CameraResponse, summary="获取摄像头详情")
async def get_camera(
    camera_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    根据ID获取摄像头详情
    """
    result = await db.execute(select(Camera).filter(Camera.id == camera_id))
    camera = result.scalar_one_or_none()
    
    if not camera:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="摄像头不存在"
        )
    
    # 检查区域权限
    await check_area_permission(db, current_user.id, camera.area_id, "view")
    
    return camera


@router.post("/", response_model=CameraResponse, status_code=status.HTTP_201_CREATED, summary="创建摄像头")
async def create_camera(
    camera_data: CameraCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    创建新摄像头
    """
    # 检查区域权限
    await check_area_permission(db, current_user.id, camera_data.area_id, "edit")
    
    # 检查摄像头名称是否重复（在同一区域内）
    result = await db.execute(
        select(Camera).filter(
            Camera.area_id == camera_data.area_id,
            Camera.name == camera_data.name
        )
    )
    existing_camera = result.scalar_one_or_none()
    if existing_camera:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="同一区域内摄像头名称不能重复"
        )
    
    # 创建摄像头
    camera = Camera(**camera_data.dict())
    db.add(camera)
    await db.commit()
    await db.refresh(camera)
    
    return camera


@router.put("/{camera_id}", response_model=CameraResponse, summary="更新摄像头")
async def update_camera(
    camera_id: int,
    camera_data: CameraUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    更新摄像头信息
    """
    result = await db.execute(select(Camera).filter(Camera.id == camera_id))
    camera = result.scalar_one_or_none()
    
    if not camera:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="摄像头不存在"
        )
    
    # 检查区域权限
    await check_area_permission(db, current_user.id, camera.area_id, "edit")
    
    # 如果修改了区域，检查新区域的权限
    if camera_data.area_id and camera_data.area_id != camera.area_id:
        await check_area_permission(db, current_user.id, camera_data.area_id, "edit")
    
    # 如果修改了名称，检查是否重复
    if camera_data.name and camera_data.name != camera.name:
        result = await db.execute(
            select(Camera).filter(
                Camera.area_id == camera.area_id,
                Camera.name == camera_data.name,
                Camera.id != camera_id
            )
        )
        existing_camera = result.scalar_one_or_none()
        if existing_camera:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="同一区域内摄像头名称不能重复"
            )
    
    # 更新摄像头信息
    update_data = camera_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(camera, field, value)
    
    await db.commit()
    await db.refresh(camera)
    
    return camera


@router.delete("/{camera_id}", status_code=status.HTTP_204_NO_CONTENT, summary="删除摄像头")
async def delete_camera(
    camera_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    删除摄像头
    """
    result = await db.execute(select(Camera).filter(Camera.id == camera_id))
    camera = result.scalar_one_or_none()
    
    if not camera:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="摄像头不存在"
        )
    
    # 检查区域权限
    await check_area_permission(db, current_user.id, camera.area_id, "delete")
    
    # 删除摄像头
    await db.delete(camera)
    await db.commit()
    
    return None


@router.patch("/{camera_id}/status", response_model=CameraResponse, summary="更新摄像头状态")
async def update_camera_status(
    camera_id: int,
    status: CameraStatus,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    更新摄像头状态（在线/离线）
    """
    result = await db.execute(select(Camera).filter(Camera.id == camera_id))
    camera = result.scalar_one_or_none()
    
    if not camera:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="摄像头不存在"
        )
    
    # 检查区域权限
    await check_area_permission(db, current_user.id, camera.area_id, "edit")
    
    # 更新状态
    camera.status = status
    await db.commit()
    await db.refresh(camera)
    
    return camera


@router.patch("/{camera_id}/heartbeat", response_model=CameraResponse, summary="摄像头心跳检测")
async def camera_heartbeat(
    camera_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    摄像头心跳检测，更新最后活跃时间
    """
    result = await db.execute(select(Camera).filter(Camera.id == camera_id))
    camera = result.scalar_one_or_none()
    
    if not camera:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="摄像头不存在"
        )
    
    # 检查区域权限
    await check_area_permission(db, current_user.id, camera.area_id, "edit")
    
    # 更新最后心跳时间
    from datetime import datetime
    camera.last_heartbeat = datetime.utcnow()
    camera.status = "online"
    
    await db.commit()
    await db.refresh(camera)
    
    return camera


@router.get("/project/{project_id}/stats", summary="获取项目摄像头统计")
async def get_camera_stats(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    获取项目的摄像头统计信息
    """
    # 检查项目权限
    await check_project_permission(db, current_user.id, project_id, "view")
    
    # 获取项目下的所有区域
    result = await db.execute(
        select(Area.id).filter(Area.project_id == project_id)
    )
    area_ids = [area_id for (area_id,) in result.all()]
    
    if not area_ids:
        return {
            "total": 0,
            "online": 0,
            "offline": 0,
            "online_rate": 0
        }
    
    # 获取摄像头统计
    result = await db.execute(
        select(
            Camera.status,
            func.count(Camera.id)
        ).filter(
            Camera.area_id.in_(area_ids)
        ).group_by(Camera.status)
    )
    
    stats = result.all()
    total = 0
    online = 0
    offline = 0
    
    for status, count in stats:
        total += count
        if status == "online":
            online = count
        elif status == "offline":
            offline = count
    
    online_rate = (online / total * 100) if total > 0 else 0
    
    return {
        "total": total,
        "online": online,
        "offline": offline,
        "online_rate": round(online_rate, 2)
    }