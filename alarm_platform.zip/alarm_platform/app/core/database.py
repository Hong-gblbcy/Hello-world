from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from .config import settings

# 创建异步数据库引擎
# 根据数据库类型配置不同的参数
if settings.DATABASE_URL.startswith("sqlite"):
    # SQLite配置 - 使用aiosqlite
    async_engine = create_async_engine(
        settings.DATABASE_URL.replace("sqlite:///", "sqlite+aiosqlite:///"),
        connect_args={"check_same_thread": False},  # SQLite需要这个参数
        echo=settings.DEBUG,
        poolclass=NullPool  # SQLite异步需要NullPool
    )
else:
    # PostgreSQL配置 - 使用asyncpg
    async_engine = create_async_engine(
        settings.DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://"),
        pool_size=20,
        max_overflow=10,
        pool_timeout=30,
        pool_recycle=1800,
        echo=settings.DEBUG
    )

# 创建异步会话工厂
AsyncSessionLocal = sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)

# 声明基类
Base = declarative_base()

# 依赖注入函数 - 异步版本
async def get_db():
    """
    获取异步数据库会话的依赖函数
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

# 数据库工具函数
def init_db():
    """
    初始化数据库，创建所有表
    """
    Base.metadata.create_all(bind=engine)

def drop_db():
    """
    删除所有表（用于测试和开发）
    """
    Base.metadata.drop_all(bind=engine)