from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

from .common import ProjectBase, BaseResponse, PaginatedResponse
from .user import UserResponse

class ProjectCreate(ProjectBase):
    """项目创建模型"""
    pass


class ProjectUpdate(BaseModel):
    """项目更新模型"""
    name: Optional[str] = None
    description: Optional[str] = None


class ProjectResponse(ProjectBase, BaseResponse):
    """项目响应模型"""
    created_by: int
    creator: Optional[UserResponse] = None

    class Config:
        from_attributes = True


class ProjectWithStatsResponse(ProjectResponse):
    """带统计信息的项目响应模型"""
    area_count: int = 0
    camera_count: int = 0
    user_count: int = 0


class ProjectListResponse(PaginatedResponse):
    """项目列表响应"""
    items: List[ProjectResponse]


class ProjectUserResponse(BaseModel):
    """项目用户响应模型"""
    id: int
    user: UserResponse
    role: str
    created_at: datetime

    class Config:
        from_attributes = True


class ProjectUserCreate(BaseModel):
    """项目用户添加模型"""
    user_id: int
    role: str = Field(..., pattern="^(admin|user)$")


class ProjectUserUpdate(BaseModel):
    """项目用户更新模型"""
    role: str = Field(..., pattern="^(admin|user)$")


class ProjectStatsResponse(BaseModel):
    """项目统计信息响应"""
    total_projects: int
    total_areas: int
    total_cameras: int
    total_users: int
    active_alerts: int
    resolved_alerts: int


class ProjectSummaryResponse(BaseModel):
    """项目概要响应"""
    id: int
    name: str
    description: Optional[str]
    created_at: datetime
    area_count: int
    camera_count: int
    user_count: int

    class Config:
        from_attributes = True