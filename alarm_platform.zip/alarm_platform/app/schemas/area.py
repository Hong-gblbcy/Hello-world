from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from .common import AreaBase, BaseResponse, PaginatedResponse
from .project import ProjectResponse
from .user import UserResponse

class AreaCreate(AreaBase):
    """区域创建模型"""
    pass


class AreaUpdate(BaseModel):
    """区域更新模型"""
    name: Optional[str] = None
    description: Optional[str] = None
    parent_id: Optional[int] = None


class AreaResponse(AreaBase, BaseResponse):
    """区域响应模型"""
    project_id: int

    class Config:
        from_attributes = True


class AreaWithStatsResponse(AreaResponse):
    """带统计信息的区域响应模型"""
    camera_count: int = 0
    user_count: int = 0
    notification_count: int = 0


class AreaListResponse(PaginatedResponse):
    """区域列表响应"""
    items: List[AreaResponse]


class AreaTreeResponse(BaseModel):
    """区域树形结构响应"""
    id: int
    name: str
    description: Optional[str]
    project_id: int
    parent_id: Optional[int]
    children: List['AreaTreeResponse'] = []
    camera_count: int = 0

    class Config:
        from_attributes = True


class AreaUserResponse(BaseModel):
    """区域用户响应模型"""
    id: int
    user: UserResponse
    created_at: datetime

    class Config:
        from_attributes = True


class AreaNotificationResponse(BaseModel):
    """区域通知配置响应模型"""
    id: int
    user: UserResponse
    alert_level: str
    created_at: datetime

    class Config:
        from_attributes = True


class AreaStatsResponse(BaseModel):
    """区域统计信息响应"""
    total_areas: int
    total_cameras: int
    total_users: int
    total_notifications: int
    active_alerts: int


class AreaSummaryResponse(BaseModel):
    """区域概要响应"""
    id: int
    name: str
    description: Optional[str]
    project_id: int
    parent_id: Optional[int]
    created_at: datetime
    camera_count: int
    user_count: int

    class Config:
        from_attributes = True