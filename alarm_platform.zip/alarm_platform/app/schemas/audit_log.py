from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class AuditLogBase(BaseModel):
    """审计日志基础模型"""
    user_id: int
    action: str
    target_type: str
    target_id: Optional[int] = None
    old_values: Optional[str] = None
    new_values: Optional[str] = None
    ip_address: Optional[str] = None

class AuditLogCreate(AuditLogBase):
    """创建审计日志的请求模型"""
    pass

class AuditLogResponse(AuditLogBase):
    """审计日志响应模型"""
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

class AuditLogQueryParams(BaseModel):
    """审计日志查询参数"""
    skip: int = 0
    limit: int = 100
    user_id: Optional[int] = None
    action: Optional[str] = None
    target_type: Optional[str] = None