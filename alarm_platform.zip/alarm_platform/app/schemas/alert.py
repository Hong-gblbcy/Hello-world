from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum

from .common import AlertBase, BaseResponse, PaginatedResponse
from .camera import CameraResponse
from .user import UserResponse


class AlertStatus(str, Enum):
    """报警状态枚举"""
    PENDING = "pending"
    PROCESSING = "processing"
    RESOLVED = "resolved"
    CLOSED = "closed"


class AlertLevel(str, Enum):
    """报警级别枚举"""
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"

class AlertCreate(AlertBase):
    """报警创建模型"""
    pass


class AlertTrigger(BaseModel):
    """报警触发模型（外部API使用）"""
    camera_id: int
    alert_level: str = Field(..., pattern="^(high|normal)$")
    alert_type: str
    description: Optional[str] = None
    video_snapshot_url: Optional[str] = None


class AlertUpdate(BaseModel):
    """报警更新模型"""
    description: Optional[str] = None
    status: Optional[str] = Field(None, pattern="^(pending|processing|resolved)$")


class AlertResolve(BaseModel):
    """报警解决模型"""
    resolved_by: int
    resolution_notes: Optional[str] = None


class AlertResponse(AlertBase):
    """报警响应模型"""
    id: int
    triggered_at: datetime
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[int] = None

    class Config:
        from_attributes = True


class AlertListResponse(PaginatedResponse):
    """报警列表响应"""
    items: List[AlertResponse]


class AlertStatsResponse(BaseModel):
    """报警统计信息响应"""
    total_alerts: int
    pending_alerts: int
    processing_alerts: int
    resolved_alerts: int
    high_alerts: int
    normal_alerts: int
    today_alerts: int
    week_alerts: int
    month_alerts: int


class AlertTimelineResponse(BaseModel):
    """报警时间线响应"""
    date: str
    count: int
    high_count: int
    normal_count: int


class AlertSummaryResponse(BaseModel):
    """报警概要响应"""
    id: int
    camera_id: int
    camera_name: str
    alert_level: str
    alert_type: str
    status: str
    triggered_at: datetime
    resolved_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AlertFilterParams(BaseModel):
    """报警过滤参数"""
    camera_id: Optional[int] = None
    project_id: Optional[int] = None
    area_id: Optional[int] = None
    alert_level: Optional[str] = Field(None, pattern="^(high|normal)$")
    status: Optional[str] = Field(None, pattern="^(pending|processing|resolved)$")
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    page: int = 1
    page_size: int = 20