from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime

from .common import UserBase, BaseResponse

class UserCreate(UserBase):
    """用户创建模型"""
    password: str = Field(..., min_length=6, max_length=100)


class UserUpdate(BaseModel):
    """用户更新模型"""
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = None


class UserResponse(UserBase, BaseResponse):
    """用户响应模型"""
    is_superadmin: bool
    is_active: bool

    class Config:
        from_attributes = True


class UserLogin(BaseModel):
    """用户登录模型"""
    username: str
    password: str


class UserInDB(UserResponse):
    """数据库中的用户模型"""
    password_hash: str


class UserProjectRoleCreate(BaseModel):
    """用户项目角色创建模型"""
    user_id: int
    project_id: int
    role: str = Field(..., pattern="^(admin|user)$")


class UserProjectRoleResponse(BaseModel):
    """用户项目角色响应模型"""
    id: int
    user_id: int
    project_id: int
    role: str
    created_at: datetime

    class Config:
        from_attributes = True


class UserAreaPermissionCreate(BaseModel):
    """用户区域权限创建模型"""
    user_id: int
    area_id: int


class UserAreaPermissionResponse(BaseModel):
    """用户区域权限响应模型"""
    id: int
    user_id: int
    area_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    """认证令牌模型"""
    access_token: str
    token_type: str = "bearer"


class MessageResponse(BaseModel):
    """通用消息响应模型"""
    message: str


class AreaNotificationCreate(BaseModel):
    """区域通知配置创建模型"""
    user_id: int
    alert_level: str = Field(..., pattern="^(all|high|normal)$")


class AreaNotificationResponse(BaseModel):
    """区域通知配置响应模型"""
    id: int
    area_id: int
    user_id: int
    alert_level: str
    created_at: datetime

    class Config:
        from_attributes = True