from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum

from .common import CameraBase, BaseResponse, PaginatedResponse
from .project import ProjectResponse
from .area import AreaResponse


class CameraStatus(str, Enum):
    """摄像头状态枚举"""
    ONLINE = "online"
    OFFLINE = "offline"

class CameraCreate(CameraBase):
    """摄像头创建模型"""
    pass


class CameraUpdate(BaseModel):
    """摄像头更新模型"""
    name: Optional[str] = None
    stream_url: Optional[str] = None
    alert_level: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = Field(None, pattern="^(online|offline)$")


class CameraResponse(CameraBase, BaseResponse):
    """摄像头响应模型"""
    status: str

    class Config:
        from_attributes = True


class CameraListResponse(PaginatedResponse):
    """摄像头列表响应"""
    items: List[CameraResponse]


class CameraStatsResponse(BaseModel):
    """摄像头统计信息响应"""
    total_cameras: int
    online_cameras: int
    offline_cameras: int
    high_alert_cameras: int
    normal_alert_cameras: int


class CameraStatusUpdate(BaseModel):
    """摄像头状态更新模型"""
    status: str = Field(..., pattern="^(online|offline)$")


class CameraAlertLevelUpdate(BaseModel):
    """摄像头报警级别更新模型"""
    alert_level: str = Field(..., pattern="^(high|normal)$")


class CameraSummaryResponse(BaseModel):
    """摄像头概要响应"""
    id: int
    name: str
    stream_url: str
    project_id: int
    area_id: int
    alert_level: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class CameraWithAlertsResponse(CameraResponse):
    """带报警信息的摄像头响应"""
    active_alerts: int = 0
    total_alerts: int = 0
    last_alert_time: Optional[datetime] = None