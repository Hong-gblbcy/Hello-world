from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class BaseResponse(BaseModel):
    """基础响应模型"""
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class PaginationParams(BaseModel):
    """分页参数"""
    page: int = 1
    page_size: int = 20


class PaginatedResponse(BaseModel):
    """分页响应"""
    items: list
    total: int
    page: int
    page_size: int
    total_pages: int


class Token(BaseModel):
    """Token响应"""
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    """Token数据"""
    username: Optional[str] = None


class MessageResponse(BaseModel):
    """消息响应"""
    message: str


class ErrorResponse(BaseModel):
    """错误响应"""
    detail: str


class UserBase(BaseModel):
    """用户基础模型"""
    username: str
    email: EmailStr
    name: str
    phone: Optional[str] = None


class ProjectBase(BaseModel):
    """项目基础模型"""
    name: str
    description: Optional[str] = None


class AreaBase(BaseModel):
    """区域基础模型"""
    name: str
    description: Optional[str] = None
    project_id: int
    parent_id: Optional[int] = None


class CameraBase(BaseModel):
    """摄像头基础模型"""
    name: str
    stream_url: str
    project_id: int
    area_id: int
    alert_level: Optional[str] = "normal"
    description: Optional[str] = None


class AlertBase(BaseModel):
    """报警基础模型"""
    camera_id: int
    alert_level: str
    alert_type: str
    description: Optional[str] = None
    video_snapshot_url: Optional[str] = None
    status: Optional[str] = "pending"