#!/usr/bin/env python3
"""
数据库初始化脚本
用于创建数据库表和初始化数据
"""

import sys
import os

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy.orm import Session
from app.core.database import engine, Base, SessionLocal
from app.models.user import User
from app.core.security import get_password_hash

def init_database():
    """初始化数据库"""
    print("🚀 开始初始化数据库...")
    
    # 创建所有表
    try:
        Base.metadata.create_all(bind=engine)
        print("✅ 数据库表创建成功")
    except Exception as e:
        print(f"❌ 创建数据库表失败: {e}")
        return False
    
    # 初始化默认数据
    try:
        db = SessionLocal()
        
        # 创建默认超级管理员
        admin_user = db.query(User).filter(User.username == "admin").first()
        if not admin_user:
            admin_user = User(
                username="admin",
                password_hash=get_password_hash("admin123"),
                name="系统管理员",
                email="admin@monitoring-system.com",
                is_superadmin=True,
                is_active=True
            )
            db.add(admin_user)
            db.commit()
            print("✅ 超级管理员账户创建成功: admin/admin123")
        else:
            print("✅ 超级管理员账户已存在")
        
        # 创建测试用户
        test_user = db.query(User).filter(User.username == "testuser").first()
        if not test_user:
            test_user = User(
                username="testuser",
                password_hash=get_password_hash("test123"),
                name="测试用户",
                email="test@monitoring-system.com",
                is_superadmin=False,
                is_active=True
            )
            db.add(test_user)
            db.commit()
            print("✅ 测试用户创建成功: testuser/test123")
        else:
            print("✅ 测试用户已存在")
        
        db.close()
        print("✅ 数据库初始化完成")
        return True
        
    except Exception as e:
        print(f"❌ 初始化数据失败: {e}")
        db.rollback()
        db.close()
        return False

def drop_database():
    """删除所有表（谨慎使用）"""
    print("⚠️  开始删除数据库表...")
    confirm = input("确认要删除所有表吗？此操作不可逆！(y/N): ")
    
    if confirm.lower() != 'y':
        print("操作已取消")
        return
    
    try:
        Base.metadata.drop_all(bind=engine)
        print("✅ 数据库表删除成功")
    except Exception as e:
        print(f"❌ 删除数据库表失败: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "drop":
        drop_database()
    else:
        init_database()