#!/usr/bin/env python3
"""测试配置读取"""

from app.core.config import settings

print("=== 当前配置 ===")
print(f"DATABASE_URL: {settings.DATABASE_URL}")
print(f"DEBUG: {settings.DEBUG}")
print(f"HOST: {settings.HOST}")
print(f"PORT: {settings.PORT}")

# 测试数据库连接
from sqlalchemy import create_engine
try:
    if settings.DATABASE_URL.startswith("sqlite"):
        engine = create_engine(
            settings.DATABASE_URL,
            connect_args={"check_same_thread": False},
            echo=True
        )
        with engine.connect() as conn:
            print("✅ SQLite连接成功")
    else:
        engine = create_engine(settings.DATABASE_URL, echo=True)
        with engine.connect() as conn:
            print("✅ PostgreSQL连接成功")
except Exception as e:
    print(f"❌ 数据库连接失败: {e}")