from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.core.config import settings
from app.core.database import async_engine, Base, get_db
from app.api import auth, projects, areas, cameras, alerts, audit_logs
from app.models.user import User
from app.core.security import get_password_hash

# 创建数据库表的异步函数
async def create_tables():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

# 创建数据库表的异步函数
async def create_tables():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

# 初始化超级管理员账户的异步函数
async def init_superadmin():
    async for db in get_db():
        try:
            from sqlalchemy import select
            result = await db.execute(select(User).filter(User.username == "admin"))
            superadmin = result.scalar_one_or_none()
            if not superadmin:
                hashed_password = get_password_hash("admin123")
                admin_user = User(
                    username="admin",
                    password_hash=hashed_password,
                    name="系统管理员",
                    email="admin@monitoring-system.com",
                    is_superadmin=True,
                    is_active=True
                )
                db.add(admin_user)
                await db.commit()
                print("✅ 超级管理员账户已创建: admin/admin123")
            else:
                print("✅ 超级管理员账户已存在")
        except Exception as e:
            print(f"❌ 初始化超级管理员失败: {e}")
            await db.rollback()
        finally:
            await db.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时执行的操作
    await create_tables()
    await init_superadmin()
    yield
    # 关闭时执行的操作（可选）
    # 可以在这里添加数据库连接关闭等清理操作

app = FastAPI(
    title="监控管理与报警系统 API",
    description="基于三级权限管理的监控报警系统后端API",
    version="1.0.0",
    docs_url=None,
    redoc_url=None,
    lifespan=lifespan  # 添加lifespan参数
)

app = FastAPI(
    title="监控管理与报警系统 API",
    description="基于三级权限管理的监控报警系统后端API",
    version="1.0.0",
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应限制为具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 添加审计日志中间件
from app.middleware.audit_middleware import AuditMiddleware
app.add_middleware(AuditMiddleware)

# 注册路由
app.include_router(auth.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(areas.router, prefix="/api")
app.include_router(cameras.router, prefix="/api")
app.include_router(alerts.router, prefix="/api")
app.include_router(audit_logs.router, prefix="/api")


# 健康检查端点
@app.get("/health", tags=["系统"])
async def health_check():
    """系统健康检查"""
    return {"status": "healthy", "message": "系统运行正常"}

# 系统信息端点
@app.get("/system/info", tags=["系统"])
async def system_info():
    """获取系统信息"""
    return {
        "name": "监控管理与报警系统",
        "version": "1.0.0",
        "description": "基于三级权限管理的监控报警系统",
        "author": "系统开发团队",
        "contact": {
            "email": "support@monitoring-system.com"
        }
    }


# 全局异常处理
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "服务器内部错误"},
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info" if settings.DEBUG else "warning"
    )