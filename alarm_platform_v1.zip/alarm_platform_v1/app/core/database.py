from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from .config import settings

# 创建异步数据库引擎
# 根据数据库类型配置不同的参数
if settings.DATABASE_URL.startswith("sqlite"):
    # SQLite配置 - 使用aiosqlite
    async_engine = create_async_engine(
        settings.DATABASE_URL.replace("sqlite:///", "sqlite+aiosqlite:///"),
        connect_args={"check_same_thread": False},  # SQLite需要这个参数
        echo=settings.DEBUG,
        poolclass=NullPool  # SQLite异步需要NullPool
    )
    
    # 同步SQLite引擎（用于脚本）
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        echo=settings.DEBUG
    )
else:
    # PostgreSQL配置 - 使用asyncpg
    async_engine = create_async_engine(
        settings.DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://"),
        pool_size=20,
        max_overflow=10,
        pool_timeout=30,
        pool_recycle=1800,
        echo=settings.DEBUG
    )
    
    # 同步PostgreSQL引擎（用于脚本）
    engine = create_engine(
        settings.DATABASE_URL,
        pool_size=20,
        max_overflow=10,
        pool_timeout=30,
        pool_recycle=1800,
        echo=settings.DEBUG
    )

# 创建异步会话工厂
AsyncSessionLocal = sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)

# 创建同步会话工厂（用于脚本）
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# 声明基类
Base = declarative_base()

# 依赖注入函数 - 异步版本
async def get_db():
    """
    获取异步数据库会话的依赖函数
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

# 数据库工具函数 - 异步版本
async def async_init_db():
    """
    异步初始化数据库，创建所有表
    """
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def async_drop_db():
    """
    异步删除所有表（用于测试和开发）
    """
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

# 数据库工具函数 - 同步版本（用于脚本）
def init_db():
    """
    同步初始化数据库，创建所有表
    """
    Base.metadata.create_all(bind=engine)

def drop_db():
    """
    同步删除所有表（用于测试和开发）
    """
    Base.metadata.drop_all(bind=engine)