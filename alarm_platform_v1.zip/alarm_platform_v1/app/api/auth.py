from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import Any

from app.core.database import get_db
from app.core.security import get_current_user, get_current_superuser
from app.schemas.user import (
    UserCreate, 
    UserResponse, 
    Token, 
    UserLogin,
    MessageResponse
)
from app.schemas.common import ErrorResponse
from app.services.auth import AuthService
from app.models.user import User

router = APIRouter(prefix="/auth", tags=["认证"])

@router.post(
    "/login",
    response_model=Token,
    responses={
        401: {"model": ErrorResponse, "description": "认证失败"},
        400: {"model": ErrorResponse, "description": "用户被禁用"}
    }
)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
) -> Any:
    """
    用户登录 (OAuth2 密码流)
    
    - **username**: 用户名
    - **password**: 密码
    - **client_id**: 客户端ID (可选)
    - **client_secret**: 客户端密钥 (可选)
    
    返回访问令牌
    """
    # 创建 UserLogin 对象从表单数据
    login_data = UserLogin(username=form_data.username, password=form_data.password)
    return await AuthService.login_user(db, login_data)

@router.post(
    "/register",
    response_model=UserResponse,
    responses={
        403: {"model": ErrorResponse, "description": "权限不足"},
        400: {"model": ErrorResponse, "description": "用户名或邮箱已存在"}
    }
)
async def register(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    注册新用户（需要超级管理员权限）
    
    - **username**: 用户名（唯一）
    - **password**: 密码（至少6位）
    - **name**: 真实姓名
    - **email**: 邮箱（唯一）
    - **phone**: 手机号（可选）
    
    返回创建的用户信息
    """
    return await AuthService.register_user(db, user_data, current_user)

@router.get(
    "/me",
    response_model=dict,
    responses={401: {"model": ErrorResponse, "description": "认证失败"}}
)
async def get_me(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    获取当前用户信息及权限
    
    返回用户信息和权限详情
    """
    return await AuthService.get_current_user_info(db, current_user)

@router.put(
    "/me",
    response_model=UserResponse,
    responses={
        401: {"model": ErrorResponse, "description": "认证失败"},
        400: {"model": ErrorResponse, "description": "邮箱已被使用"}
    }
)
async def update_me(
    update_data: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    更新当前用户个人信息
    
    - **name**: 真实姓名（可选）
    - **email**: 邮箱（可选，唯一）
    - **phone**: 手机号（可选）
    
    返回更新后的用户信息
    """
    return await AuthService.update_user_profile(db, current_user, update_data)

@router.post(
    "/change-password",
    response_model=MessageResponse,
    responses={
        401: {"model": ErrorResponse, "description": "认证失败"},
        400: {"model": ErrorResponse, "description": "原密码错误"}
    }
)
async def change_password(
    old_password: str,
    new_password: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Any:
    """
    修改当前用户密码
    
    - **old_password**: 原密码
    - **new_password**: 新密码（至少6位）
    
    返回成功消息
    """
    await AuthService.change_password(db, current_user, old_password, new_password)
    return MessageResponse(message="密码修改成功")

@router.post(
    "/users/{user_id}/deactivate",
    response_model=MessageResponse,
    responses={
        403: {"model": ErrorResponse, "description": "权限不足"},
        404: {"model": ErrorResponse, "description": "用户不存在"},
        400: {"model": ErrorResponse, "description": "不能禁用自己"}
    }
)
async def deactivate_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    禁用用户（需要超级管理员权限）
    
    - **user_id**: 用户ID
    
    返回成功消息
    """
    await AuthService.deactivate_user(db, user_id, current_user)
    return MessageResponse(message="用户禁用成功")

@router.post(
    "/users/{user_id}/activate",
    response_model=MessageResponse,
    responses={
        403: {"model": ErrorResponse, "description": "权限不足"},
        404: {"model": ErrorResponse, "description": "用户不存在"}
    }
)
async def activate_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    启用用户（需要超级管理员权限）
    
    - **user_id**: 用户ID
    
    返回成功消息
    """
    await AuthService.activate_user(db, user_id, current_user)
    return MessageResponse(message="用户启用成功")

@router.get(
    "/users",
    response_model=list[UserResponse],
    responses={403: {"model": ErrorResponse, "description": "权限不足"}}
)
async def get_all_users(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_superuser)
) -> Any:
    """
    获取所有用户列表（需要超级管理员权限）
    
    返回用户列表
    """
    result = await db.execute(select(User))
    users = result.scalars().all()
    return users