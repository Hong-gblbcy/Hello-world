from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import enum
import json

from app.core.database import Base

class AlertLevel(str, enum.Enum):
    HIGH = "high"
    NORMAL = "normal"

class AlertStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    RESOLVED = "resolved"
    CLOSED = "closed"

class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    area_id = Column(Integer, ForeignKey("areas.id"), nullable=True)
    camera_id = Column(Integer, ForeignKey("cameras.id"), nullable=False)
    alert_level = Column(Enum(AlertLevel), nullable=False)
    alert_type = Column(String(100), nullable=False)
    description = Column(String(500), nullable=True)
    triggered_at = Column(DateTime, default=func.now())
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    video_snapshot_url = Column(String(500), nullable=True)
    status = Column(Enum(AlertStatus, values_callable=lambda x: [e.value for e in x]), default=AlertStatus.PENDING)
    alert_source = Column(String(50), default="internal")
    external_id = Column(String(100), nullable=True)

    # 关系定义
    camera = relationship("Camera", back_populates="alerts")
    resolved_by_user = relationship("User", back_populates="resolved_alerts")
    project = relationship("Project")
    area = relationship("Area")

    def __repr__(self):
        return f"<Alert(id={self.id}, camera_id={self.camera_id}, alert_type={self.alert_type})>"

    def to_dict(self):
        return {
            "id": self.id,
            "project_id": self.project_id,
            "area_id": self.area_id,
            "camera_id": self.camera_id,
            "alert_level": self.alert_level.value if self.alert_level else None,
            "alert_type": self.alert_type,
            "description": self.description,
            "triggered_at": self.triggered_at.isoformat() if self.triggered_at else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_by": self.resolved_by,
            "video_snapshot_url": self.video_snapshot_url,
            "status": self.status.value if self.status else None,
            "alert_source": self.alert_source,
            "external_id": self.external_id
        }

