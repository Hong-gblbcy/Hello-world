from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, select

from app.models.user import User
from app.models.project import Project, UserProjectRole
from app.models.area import Area, UserAreaPermission
from app.models.camera import Camera
from app.core.security import get_current_user

class PermissionService:
    """同步权限服务类，处理三级权限验证"""

    @staticmethod
    def check_project_access(db: Session, user_id: int, project_id: int) -> bool:
        """
        检查用户是否有项目访问权限
        """
        # 超级管理员可以访问所有项目
        user = db.query(User).filter(User.id == user_id).first()
        if user and user.is_superadmin:
            return True

        # 检查用户项目角色
        user_role = db.query(UserProjectRole).filter(
            and_(
                UserProjectRole.user_id == user_id,
                UserProjectRole.project_id == project_id
            )
        ).first()
        
        return user_role is not None

    @staticmethod
    def check_project_admin(db: Session, user_id: int, project_id: int) -> bool:
        """
        检查用户是否是项目管理员
        """
        # 超级管理员自动拥有所有项目管理权限
        user = db.query(User).filter(User.id == user_id).first()
        if user and user.is_superadmin:
            return True

        # 检查用户项目管理员角色
        user_role = db.query(UserProjectRole).filter(
            and_(
                UserProjectRole.user_id == user_id,
                UserProjectRole.project_id == project_id,
                UserProjectRole.role == 'admin'
            )
        ).first()
        
        return user_role is not None

    @staticmethod
    def check_area_access(db: Session, user_id: int, area_id: int) -> bool:
        """
        检查用户是否有区域访问权限
        """
        # 超级管理员可以访问所有区域
        user = db.query(User).filter(User.id == user_id).first()
        if user and user.is_superadmin:
            return True

        # 检查用户区域权限
        area_permission = db.query(UserAreaPermission).filter(
            and_(
                UserAreaPermission.user_id == user_id,
                UserAreaPermission.area_id == area_id
            )
        ).first()
        
        return area_permission is not None

    @staticmethod
    def check_camera_access(db: Session, user_id: int, camera_id: int) -> bool:
        """
        检查用户是否有摄像头访问权限
        """
        # 获取摄像头所属区域
        camera = db.query(Camera).filter(Camera.id == camera_id).first()
        if not camera:
            return False
        
        # 检查用户区域权限
        return PermissionService.check_area_access(db, user_id, camera.area_id)

    @staticmethod
    def get_user_projects(db: Session, user_id: int) -> List[Project]:
        """
        获取用户有权限访问的项目列表
        """
        # 超级管理员获取所有项目
        user = db.query(User).filter(User.id == user_id).first()
        if user and user.is_superadmin:
            return db.query(Project).all()

        # 获取用户有角色的项目
        user_roles = db.query(UserProjectRole).filter(
            UserProjectRole.user_id == user_id
        ).all()
        
        project_ids = [role.project_id for role in user_roles]
        return db.query(Project).filter(Project.id.in_(project_ids)).all()

    @staticmethod
    def get_user_areas(db: Session, user_id: int, project_id: Optional[int] = None) -> List[Area]:
        """
        获取用户有权限访问的区域列表
        """
        # 超级管理员获取所有区域
        user = db.query(User).filter(User.id == user_id).first()
        if user and user.is_superadmin:
            if project_id:
                return db.query(Area).filter(Area.project_id == project_id).all()
            return db.query(Area).all()

        # 获取用户有权限的区域
        area_permissions = db.query(UserAreaPermission).filter(
            UserAreaPermission.user_id == user_id
        ).all()
        
        area_ids = [perm.area_id for perm in area_permissions]
        if not area_ids:
            return []
        
        query = db.query(Area).filter(Area.id.in_(area_ids))
        if project_id:
            query = query.filter(Area.project_id == project_id)
        
        return query.all()

    @staticmethod
    def get_user_cameras(db: Session, user_id: int, area_id: Optional[int] = None) -> List[Camera]:
        """
        获取用户有权限访问的摄像头列表
        """
        # 获取用户有权限的区域
        user_areas = PermissionService.get_user_areas(db, user_id)
        area_ids = [area.id for area in user_areas]
        
        if not area_ids:
            return []
        
        query = db.query(Camera).filter(Camera.area_id.in_(area_ids))
        if area_id:
            # 确保请求的区域在用户权限范围内
            if area_id not in area_ids:
                return []
            query = query.filter(Camera.area_id == area_id)
        
        return query.all()


class AsyncPermissionService:
    """异步权限服务类，处理三级权限验证"""

    @staticmethod
    async def check_project_access(db: AsyncSession, user_id: int, project_id: int) -> bool:
        """
        检查用户是否有项目访问权限
        """
        # 超级管理员可以访问所有项目
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if user and user.is_superadmin:
            return True

        # 检查用户项目角色
        result = await db.execute(
            select(UserProjectRole).filter(
                and_(
                    UserProjectRole.user_id == user_id,
                    UserProjectRole.project_id == project_id
                )
            )
        )
        user_role = result.scalar_one_or_none()
        
        return user_role is not None

    @staticmethod
    async def check_project_admin(db: AsyncSession, user_id: int, project_id: int) -> bool:
        """
        检查用户是否是项目管理员
        """
        # 超级管理员自动拥有所有项目管理权限
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if user and user.is_superadmin:
            return True

        # 检查用户项目管理员角色
        result = await db.execute(
            select(UserProjectRole).filter(
                and_(
                    UserProjectRole.user_id == user_id,
                    UserProjectRole.project_id == project_id,
                    UserProjectRole.role == 'admin'
                )
            )
        )
        user_role = result.scalar_one_or_none()
        
        return user_role is not None

    @staticmethod
    async def check_area_access(db: AsyncSession, user_id: int, area_id: int) -> bool:
        """
        检查用户是否有区域访问权限
        """
        # 超级管理员可以访问所有区域
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if user and user.is_superadmin:
            return True

        # 检查用户区域权限
        result = await db.execute(
            select(UserAreaPermission).filter(
                and_(
                    UserAreaPermission.user_id == user_id,
                    UserAreaPermission.area_id == area_id
                )
            )
        )
        area_permission = result.scalar_one_or_none()
        
        return area_permission is not None

    @staticmethod
    async def check_camera_access(db: AsyncSession, user_id: int, camera_id: int) -> bool:
        """
        检查用户是否有摄像头访问权限
        """
        # 获取摄像头所属区域
        result = await db.execute(select(Camera).filter(Camera.id == camera_id))
        camera = result.scalar_one_or_none()
        if not camera:
            return False
        
        # 检查用户区域权限
        return await AsyncPermissionService.check_area_access(db, user_id, camera.area_id)

    @staticmethod
    async def get_user_projects(db: AsyncSession, user_id: int) -> List[Project]:
        """
        获取用户有权限访问的项目列表
        """
        # 超级管理员获取所有项目
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if user and user.is_superadmin:
            result = await db.execute(select(Project))
            return result.scalars().all()

        # 获取用户有角色的项目
        result = await db.execute(
            select(UserProjectRole).filter(UserProjectRole.user_id == user_id)
        )
        user_roles = result.scalars().all()
        
        project_ids = [role.project_id for role in user_roles]
        if not project_ids:
            return []
            
        result = await db.execute(
            select(Project).filter(Project.id.in_(project_ids))
        )
        return result.scalars().all()

    @staticmethod
    async def get_project_admins(db: AsyncSession, project_id: int) -> List[User]:
        """
        获取项目的管理员用户列表
        
        Args:
            db: 异步数据库会话
            project_id: 项目ID
            
        Returns:
            List[User]: 项目管理员用户列表
        """
        # 获取项目管理员角色
        result = await db.execute(
            select(UserProjectRole).filter(
                and_(
                    UserProjectRole.project_id == project_id,
                    UserProjectRole.role == 'admin'
                )
            )
        )
        admin_roles = result.scalars().all()
        
        if not admin_roles:
            return []
        
        # 获取对应的用户
        user_ids = [role.user_id for role in admin_roles]
        result = await db.execute(
            select(User).filter(User.id.in_(user_ids))
        )
        return result.scalars().all()


    @staticmethod
    async def get_user_areas(db: AsyncSession, user_id: int, project_id: Optional[int] = None) -> List[Area]:
        """
        获取用户有权限访问的区域列表
        """
        # 超级管理员获取所有区域
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if user and user.is_superadmin:
            if project_id:
                result = await db.execute(select(Area).filter(Area.project_id == project_id))
                return result.scalars().all()
            result = await db.execute(select(Area))
            return result.scalars().all()

        # 获取用户有权限的区域
        result = await db.execute(
            select(UserAreaPermission).filter(UserAreaPermission.user_id == user_id)
        )
        area_permissions = result.scalars().all()
        
        area_ids = [perm.area_id for perm in area_permissions]
        if not area_ids:
            return []
        
        query = select(Area).filter(Area.id.in_(area_ids))
        if project_id:
            query = query.filter(Area.project_id == project_id)
        
        result = await db.execute(query)
        return result.scalars().all()

    @staticmethod
    async def get_user_cameras(db: AsyncSession, user_id: int, area_id: Optional[int] = None) -> List[Camera]:
        """
        获取用户有权限访问的摄像头列表
        """
        # 获取用户有权限的区域
        user_areas = await AsyncPermissionService.get_user_areas(db, user_id)
        area_ids = [area.id for area in user_areas]
        
        if not area_ids:
            return []
        
        query = select(Camera).filter(Camera.area_id.in_(area_ids))
        if area_id:
            # 确保请求的区域在用户权限范围内
            if area_id not in area_ids:
                return []
            query = query.filter(Camera.area_id == area_id)
        
        result = await db.execute(query)
        return result.scalars().all()


# 异步权限检查函数 - 用于API路由
async def check_project_permission(db: AsyncSession, user_id: int, project_id: int, permission_type: str = "view") -> bool:
    """
    检查用户项目权限
    """
    if permission_type == "view":
        return await AsyncPermissionService.check_project_access(db, user_id, project_id)
    elif permission_type in ["edit", "delete", "admin"]:
        return await AsyncPermissionService.check_project_admin(db, user_id, project_id)
    return False


async def check_area_permission(db: AsyncSession, user_id: int, area_id: int, permission_type: str = "view") -> bool:
    """
    检查用户区域权限
    """
    if not await AsyncPermissionService.check_area_access(db, user_id, area_id):
        return False
    
    # 对于编辑和删除权限，需要检查用户是否是项目管理员
    if permission_type in ["edit", "delete"]:
        # 获取区域所属项目
        result = await db.execute(select(Area).filter(Area.id == area_id))
        area = result.scalar_one_or_none()
        if area:
            return await AsyncPermissionService.check_project_admin(db, user_id, area.project_id)
    
    return True


async def check_camera_permission(db: AsyncSession, user_id: int, camera_id: int, permission_type: str = "view") -> bool:
    """
    检查用户摄像头权限
    """
    if not await AsyncPermissionService.check_camera_access(db, user_id, camera_id):
        return False
    
    # 对于编辑和删除权限，需要检查用户是否是项目管理员
    if permission_type in ["edit", "delete"]:
        # 获取摄像头所属区域
        result = await db.execute(select(Camera).filter(Camera.id == camera_id))
        camera = result.scalar_one_or_none()
        if camera:
            # 获取区域所属项目
            result = await db.execute(select(Area).filter(Area.id == camera.area_id))
            area = result.scalar_one_or_none()
            if area:
                return await AsyncPermissionService.check_project_admin(db, user_id, area.project_id)
    
    return True