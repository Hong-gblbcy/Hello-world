from datetime import datetime, timedelta
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from fastapi import HTTPException, status, Depends
from fastapi.security import OAuth2PasswordBearer
from app.services.permission import AsyncPermissionService

from app.models.user import User
from app.core.security import (
    verify_password, 
    get_password_hash, 
    create_access_token,
    get_current_user
)
from app.core.config import settings
from app.schemas.user import UserCreate, UserLogin, Token
from app.services.permission import PermissionService

class AuthService:
    """认证服务类"""

    @staticmethod
    async def get_user_by_username(db: AsyncSession, username: str) -> Optional[User]:
        """
        根据用户名获取用户
        """
        result = await db.execute(select(User).filter(User.username == username))
        user = result.scalar_one_or_none()
        return user

    @staticmethod
    async def authenticate_user(db: AsyncSession, username: str, password: str) -> Optional[User]:
        """
        验证用户凭据
        """
        user = await AuthService.get_user_by_username(db, username)
        if not user:
            return None
        if not verify_password(password, user.password_hash):
            return None
        return user

    @staticmethod
    async def login_user(db: AsyncSession, login_data: UserLogin) -> Token:
        """
        用户登录
        """
        user = await AuthService.authenticate_user(db, login_data.username, login_data.password)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="用户名或密码错误",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="用户已被禁用"
            )
        
        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": user.username},
            expires_delta=access_token_expires
        )
        
        return Token(access_token=access_token, token_type="bearer")

    @staticmethod
    async def register_user(db: AsyncSession, user_data: UserCreate, current_user: User) -> User:
        """
        注册新用户（需要超级管理员权限）
        """
        # 检查权限
        if not current_user.is_superadmin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="需要超级管理员权限"
            )
        
        # 检查用户名是否已存在
        result = await db.execute(select(User).filter(User.username == user_data.username))
        existing_user = result.scalar_one_or_none()
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="用户名已存在"
            )
        
        # 检查邮箱是否已存在
        result = await db.execute(select(User).filter(User.email == user_data.email))
        existing_email = result.scalar_one_or_none()
        if existing_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="邮箱已存在"
            )
        
        # 创建用户
        hashed_password = get_password_hash(user_data.password)
        user = User(
            username=user_data.username,
            password_hash=hashed_password,
            name=user_data.name,
            phone=user_data.phone,
            email=user_data.email,
            is_superadmin=False,
            is_active=True
        )
        
        db.add(user)
        await db.commit()
        await db.refresh(user)
        
        return user

    @staticmethod
    async def get_current_user_info(db: AsyncSession, current_user: User) -> dict:
        """
        获取当前用户信息及权限
        """
        # 获取用户有权限的项目
        projects = await AsyncPermissionService.get_user_projects(db, current_user.id)
        
        # 获取用户有权限的区域
        areas = await AsyncPermissionService.get_user_areas(db, current_user.id)
        
        # 获取用户有权限的摄像头
        cameras = await AsyncPermissionService.get_user_cameras(db, current_user.id)
        
        return {
            "user": {
                "id": current_user.id,
                "username": current_user.username,
                "name": current_user.name,
                "email": current_user.email,
                "phone": current_user.phone,
                "is_superadmin": current_user.is_superadmin,
                "is_active": current_user.is_active
            },
            "permissions": {
                "project_count": len(projects),
                "area_count": len(areas),
                "camera_count": len(cameras),
                "projects": [{"id": p.id, "name": p.name} for p in projects],
                "areas": [{"id": a.id, "name": a.name} for a in areas]
            }
        }

    @staticmethod
    async def update_user_profile(db: AsyncSession, current_user: User, update_data: dict) -> User:
        """
        更新用户个人信息
        """
        if "name" in update_data and update_data["name"]:
            current_user.name = update_data["name"]
        
        if "phone" in update_data:
            current_user.phone = update_data["phone"]
        
        if "email" in update_data and update_data["email"]:
            # 检查邮箱是否已被其他用户使用
            result = await db.execute(select(User).filter(
                User.email == update_data["email"],
                User.id != current_user.id
            ))
            existing_email = result.scalar_one_or_none()
            if existing_email:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="邮箱已被其他用户使用"
                )
            current_user.email = update_data["email"]
        
        await db.commit()
        await db.refresh(current_user)
        return current_user

    @staticmethod
    async def change_password(db: AsyncSession, current_user: User, old_password: str, new_password: str) -> bool:
        """
        修改用户密码
        """
        if not verify_password(old_password, current_user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="原密码错误"
            )
        
        current_user.password_hash = get_password_hash(new_password)
        await db.commit()
        return True

    @staticmethod
    async def deactivate_user(db: AsyncSession, user_id: int, current_user: User) -> bool:
        """
        禁用用户（需要超级管理员权限）
        """
        if not current_user.is_superadmin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="需要超级管理员权限"
            )
        
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )
        
        if user.id == current_user.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="不能禁用自己"
            )
        
        user.is_active = False
        await db.commit()
        return True

    @staticmethod
    async def activate_user(db: AsyncSession, user_id: int, current_user: User) -> bool:
        """
        启用用户（需要超级管理员权限）
        """
        if not current_user.is_superadmin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="需要超级管理员权限"
            )
        
        result = await db.execute(select(User).filter(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )
        
        user.is_active = True
        await db.commit()
        return True