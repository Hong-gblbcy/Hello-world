#!/usr/bin/env python3
"""
监控报警系统API全面测试脚本
测试所有http://localhost:8000/docs中的API端点
"""

import asyncio
import httpx
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List

# API基础配置
BASE_URL = "http://localhost:8000"
LOGIN_CREDENTIALS = {
    "username": "admin",
    "password": "admin123"
}

class ComprehensiveAPITester:
    def __init__(self):
        self.client = httpx.AsyncClient(base_url=BASE_URL)
        self.token = None
        self.headers = {}
        self.test_data = {
            "project_id": None,
            "area_id": None,
            "camera_id": None,
            "alert_id": None,
            "user_id": None,
            "other_user_id": None  # 用于测试用户管理
        }

    async def login(self):
        """登录获取访问令牌"""
        print("🔐 正在登录...")
        try:
            response = await self.client.post(
                "/api/auth/login",
                data={
                    "username": LOGIN_CREDENTIALS["username"],
                    "password": LOGIN_CREDENTIALS["password"],
                    "grant_type": "password"
                }
            )
            response.raise_for_status()
            token_data = response.json()
            self.token = token_data["access_token"]
            self.headers = {"Authorization": f"Bearer {self.token}"}
            print("✅ 登录成功")
            return True
        except Exception as e:
            print(f"❌ 登录失败: {e}")
            return False

    async def test_health_check(self):
        """测试健康检查端点"""
        print("\n🏥 测试健康检查...")
        try:
            response = await self.client.get("/health")
            response.raise_for_status()
            print(f"✅ 健康检查: {response.json()}")
            return True
        except Exception as e:
            print(f"❌ 健康检查失败: {e}")
            return False

    async def test_system_info(self):
        """测试系统信息端点"""
        print("\nℹ️  测试系统信息...")
        try:
            response = await self.client.get("/system/info")
            response.raise_for_status()
            print(f"✅ 系统信息: {response.json()}")
            return True
        except Exception as e:
            print(f"❌ 系统信息失败: {e}")
            return False

    async def test_auth_endpoints(self):
        """测试认证相关端点"""
        print("\n🔐 测试认证端点...")
        
        success_count = 0
        total_tests = 0
        
        # 获取当前用户信息
        total_tests += 1
        try:
            response = await self.client.get("/api/auth/me", headers=self.headers)
            response.raise_for_status()
            user_info = response.json()
            self.test_data["user_id"] = user_info["user"]["id"]
            print(f"✅ 获取用户信息: {user_info['user']['username']}")
            success_count += 1
        except Exception as e:
            print(f"❌ 获取用户信息失败: {e}")
        
        # 更新用户信息
        total_tests += 1
        try:
            update_data = {
                "name": "系统管理员(测试)",
                "email": "admin@monitoring-system.com"
            }
            response = await self.client.put("/api/auth/me", json=update_data, headers=self.headers)
            response.raise_for_status()
            print("✅ 更新用户信息成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  更新用户信息失败（可能权限限制）: {e}")
        
        # 修改密码
        total_tests += 1
        try:
            # 使用查询参数而不是表单数据，因为端点期望查询参数
            response = await self.client.post(
                "/api/auth/change-password",
                params={
                    "old_password": "admin123",
                    "new_password": "admin123"
                },
                headers=self.headers
            )
            response.raise_for_status()
            print("✅ 修改密码成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  修改密码失败: {e}")
        
        # 获取所有用户
        total_tests += 1
        try:
            response = await self.client.get("/api/auth/users", headers=self.headers)
            response.raise_for_status()
            users = response.json()
            print(f"✅ 获取用户列表: 共{len(users)}个用户")
            
            # 保存另一个用户ID用于测试
            if len(users) > 1:
                self.test_data["other_user_id"] = users[1]["id"]
            
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取用户列表失败（可能权限不足）: {e}")
        
        return success_count == total_tests

    async def test_project_endpoints(self):
        """测试项目相关端点"""
        print("\n📁 测试项目管理端点...")
        
        success_count = 0
        total_tests = 0
        
        # 获取项目列表
        total_tests += 1
        try:
            response = await self.client.get("/api/projects", headers=self.headers)
            response.raise_for_status()
            projects = response.json()
            print(f"✅ 获取项目列表: 共{projects['total']}个项目")
            
            # 如果已有项目，使用第一个项目
            if projects["total"] > 0:
                self.test_data["project_id"] = projects["items"][0]["id"]
                print(f"📋 使用现有项目: ID {self.test_data['project_id']}")
            
            success_count += 1
        except Exception as e:
            print(f"❌ 获取项目列表失败: {e}")
            return False
        
        # 如果没有项目，创建新项目
        if not self.test_data["project_id"]:
            total_tests += 1
            project_data = {
                "name": f"测试项目_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "description": "自动化测试创建的项目"
            }
            
            try:
                response = await self.client.post(
                    "/api/projects",
                    json=project_data,
                    headers=self.headers
                )
                response.raise_for_status()
                project = response.json()
                self.test_data["project_id"] = project["id"]
                print(f"✅ 创建项目成功: {project['name']} (ID: {project['id']})")
                success_count += 1
            except Exception as e:
                print(f"❌ 创建项目失败: {e}")
                return False
        
        # 获取单个项目详情
        total_tests += 1
        try:
            response = await self.client.get(f"/api/projects/{self.test_data['project_id']}", headers=self.headers)
            response.raise_for_status()
            project = response.json()
            print(f"✅ 获取项目详情: {project['name']}")
            success_count += 1
        except Exception as e:
            print(f"❌ 获取项目详情失败: {e}")
        
        # 更新项目
        total_tests += 1
        try:
            update_data = {
                "name": f"更新后的项目_{datetime.now().strftime('%H%M%S')}",
                "description": "自动化测试更新的项目"
            }
            response = await self.client.put(f"/api/projects/{self.test_data['project_id']}", json=update_data, headers=self.headers)
            response.raise_for_status()
            print("✅ 更新项目成功")
            success_count += 1
        except Exception as e:
            print(f"❌ 更新项目失败: {e}")
        
        # 获取项目统计
        total_tests += 1
        try:
            response = await self.client.get(f"/api/projects/{self.test_data['project_id']}/stats", headers=self.headers)
            response.raise_for_status()
            stats = response.json()
            print(f"✅ 获取项目统计: {stats}")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取项目统计失败: {e}")
        
        # 获取项目用户
        total_tests += 1
        try:
            response = await self.client.get(f"/api/projects/{self.test_data['project_id']}/users", headers=self.headers)
            response.raise_for_status()
            users = response.json()
            print(f"✅ 获取项目用户: 共{len(users)}个用户")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取项目用户失败: {e}")
        
        return success_count >= 3  # 至少基本操作成功

    async def test_area_endpoints(self):
        """测试区域相关端点"""
        if not self.test_data["project_id"]:
            print("⚠️  跳过区域测试：无项目ID")
            return False

        print("\n🗺️  测试区域管理端点...")
        
        success_count = 0
        total_tests = 0
        
        # 获取区域列表
        total_tests += 1
        try:
            response = await self.client.get(
                f"/api/areas/?project_id={self.test_data['project_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            areas = response.json()
            print(f"✅ 获取区域列表: 共{len(areas)}个区域")
            
            # 如果已有区域，使用第一个区域
            if len(areas) > 0:
                self.test_data["area_id"] = areas[0]["id"]
                print(f"📋 使用现有区域: ID {self.test_data['area_id']}")
            
            success_count += 1
        except Exception as e:
            print(f"❌ 获取区域列表失败: {e}")

        # 如果没有区域，创建新区域
        if not self.test_data["area_id"]:
            total_tests += 1
            area_data = {
                "name": f"测试区域_{datetime.now().strftime('%H%M%S')}",
                "description": "自动化测试创建的区域",
                "project_id": self.test_data["project_id"]
            }
            
            try:
                response = await self.client.post(
                    "/api/areas/",
                    json=area_data,
                    headers=self.headers
                )
                response.raise_for_status()
                area = response.json()
                self.test_data["area_id"] = area["id"]
                print(f"✅ 创建区域成功: {area['name']} (ID: {area['id']})")
                success_count += 1
            except Exception as e:
                print(f"❌ 创建区域失败: {e}")
                return False
        
        # 获取区域树形结构
        total_tests += 1
        try:
            response = await self.client.get(
                f"/api/areas/tree?project_id={self.test_data['project_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            tree = response.json()
            print(f"✅ 获取区域树形结构: 共{len(tree)}个节点")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取区域树形结构失败: {e}")
        
        # 获取单个区域详情
        total_tests += 1
        try:
            response = await self.client.get(f"/api/areas/{self.test_data['area_id']}", headers=self.headers)
            response.raise_for_status()
            area = response.json()
            print(f"✅ 获取区域详情: {area['name']}")
            success_count += 1
        except Exception as e:
            print(f"❌ 获取区域详情失败: {e}")
        
        # 更新区域
        total_tests += 1
        try:
            update_data = {
                "name": f"更新后的区域_{datetime.now().strftime('%H%M%S')}",
                "description": "自动化测试更新的区域"
            }
            response = await self.client.put(f"/api/areas/{self.test_data['area_id']}", json=update_data, headers=self.headers)
            response.raise_for_status()
            print("✅ 更新区域成功")
            success_count += 1
        except Exception as e:
            print(f"❌ 更新区域失败: {e}")
        
        # 获取项目区域层级
        total_tests += 1
        try:
            response = await self.client.get(f"/api/areas/project/{self.test_data['project_id']}/hierarchy", headers=self.headers)
            response.raise_for_status()
            hierarchy = response.json()
            print(f"✅ 获取项目区域层级: 共{len(hierarchy)}个层级")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取项目区域层级失败: {e}")
        
        return success_count >= 3  # 至少基本操作成功

    async def test_camera_endpoints(self):
        """测试摄像头相关端点"""
        if not self.test_data["area_id"]:
            print("⚠️  跳过摄像头测试：无区域ID")
            return False

        print("\n📷 测试摄像头管理端点...")
        
        success_count = 0
        total_tests = 0
        
        # 获取摄像头列表
        total_tests += 1
        try:
            response = await self.client.get(
                f"/api/cameras/?area_id={self.test_data['area_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            cameras = response.json()
            print(f"✅ 获取摄像头列表: 共{len(cameras)}个摄像头")
            
            # 如果已有摄像头，使用第一个摄像头
            if len(cameras) > 0:
                self.test_data["camera_id"] = cameras[0]["id"]
                print(f"📋 使用现有摄像头: ID {self.test_data['camera_id']}")
            
            success_count += 1
        except Exception as e:
            print(f"❌ 获取摄像头列表失败: {e}")

        # 如果没有摄像头，创建新摄像头
        if not self.test_data["camera_id"]:
            total_tests += 1
            camera_data = {
                "name": f"测试摄像头_{datetime.now().strftime('%H%M%S')}",
                "description": "自动化测试创建的摄像头",
                "stream_url": "rtsp://test.example.com/stream",
                "area_id": self.test_data["area_id"],
                "project_id": self.test_data["project_id"],
                "alert_level": "normal"
            }
            
            try:
                response = await self.client.post(
                    "/api/cameras/",
                    json=camera_data,
                    headers=self.headers
                )
                response.raise_for_status()
                camera = response.json()
                self.test_data["camera_id"] = camera["id"]
                print(f"✅ 创建摄像头成功: {camera['name']} (ID: {camera['id']})")
                success_count += 1
            except Exception as e:
                print(f"❌ 创建摄像头失败: {e}")
                return False
        
        # 获取单个摄像头详情
        total_tests += 1
        try:
            response = await self.client.get(f"/api/cameras/{self.test_data['camera_id']}", headers=self.headers)
            response.raise_for_status()
            camera = response.json()
            print(f"✅ 获取摄像头详情: {camera['name']}")
            success_count += 1
        except Exception as e:
            print(f"❌ 获取摄像头详情失败: {e}")
        
        # 更新摄像头
        total_tests += 1
        try:
            update_data = {
                "name": f"更新后的摄像头_{datetime.now().strftime('%H%M%S')}",
                "description": "自动化测试更新的摄像头"
            }
            response = await self.client.put(f"/api/cameras/{self.test_data['camera_id']}", json=update_data, headers=self.headers)
            response.raise_for_status()
            print("✅ 更新摄像头成功")
            success_count += 1
        except Exception as e:
            print(f"❌ 更新摄像头失败: {e}")
        
        # 更新摄像头状态
        total_tests += 1
        try:
            response = await self.client.patch(f"/api/cameras/{self.test_data['camera_id']}/status?status=online", headers=self.headers)
            response.raise_for_status()
            print("✅ 更新摄像头状态成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  更新摄像头状态失败: {e}")
        
        # 摄像头心跳检测
        total_tests += 1
        try:
            response = await self.client.patch(f"/api/cameras/{self.test_data['camera_id']}/heartbeat", headers=self.headers)
            response.raise_for_status()
            print("✅ 摄像头心跳检测成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  摄像头心跳检测失败: {e}")
        
        # 获取项目摄像头统计
        total_tests += 1
        try:
            response = await self.client.get(f"/api/cameras/project/{self.test_data['project_id']}/stats", headers=self.headers)
            response.raise_for_status()
            stats = response.json()
            print(f"✅ 获取项目摄像头统计: {stats}")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取项目摄像头统计失败: {e}")
        
        return success_count >= 3  # 至少基本操作成功

    async def test_alert_endpoints(self):
        """测试报警相关端点"""
        if not self.test_data["camera_id"]:
            print("⚠️  跳过报警测试：无摄像头ID")
            return False

        print("\n🚨 测试报警管理端点...")
        
        success_count = 0
        total_tests = 0
        
        # 获取报警列表
        total_tests += 1
        try:
            response = await self.client.get(
                f"/api/alerts/?camera_id={self.test_data['camera_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            alerts = response.json()
            print(f"✅ 获取报警列表: 共{len(alerts)}个报警")
            
            # 如果已有报警，使用第一个报警
            if len(alerts) > 0:
                self.test_data["alert_id"] = alerts[0]["id"]
                print(f"📋 使用现有报警: ID {self.test_data['alert_id']}")
            
            success_count += 1
        except Exception as e:
            print(f"❌ 获取报警列表失败: {e}")

        # 如果没有报警，创建新报警
        if not self.test_data["alert_id"]:
            total_tests += 1
            alert_data = {
                "alert_type": "motion",
                "description": "自动化测试创建的报警",
                "alert_level": "normal",
                "camera_id": self.test_data["camera_id"]
            }
            
            try:
                response = await self.client.post(
                    "/api/alerts/",
                    json=alert_data,
                    headers=self.headers
                )
                response.raise_for_status()
                alert = response.json()
                self.test_data["alert_id"] = alert["id"]
                print(f"✅ 创建报警成功: {alert['alert_type']} (ID: {alert['id']})")
                success_count += 1
            except Exception as e:
                print(f"❌ 创建报警失败: {e}")
                return False
        
        # 获取单个报警详情
        total_tests += 1
        try:
            response = await self.client.get(f"/api/alerts/{self.test_data['alert_id']}", headers=self.headers)
            response.raise_for_status()
            alert = response.json()
            print(f"✅ 获取报警详情: {alert['alert_type']}")
            success_count += 1
        except Exception as e:
            print(f"❌ 获取报警详情失败: {e}")
        
        # 更新报警信息
        total_tests += 1
        try:
            update_data = {
                "description": "更新后的报警描述"
            }
            response = await self.client.put(f"/api/alerts/{self.test_data['alert_id']}", json=update_data, headers=self.headers)
            response.raise_for_status()
            print("✅ 更新报警信息成功")
            success_count += 1
        except Exception as e:
            print(f"❌ 更新报警信息失败: {e}")
        
        # 确认报警
        total_tests += 1
        try:
            response = await self.client.patch(f"/api/alerts/{self.test_data['alert_id']}/acknowledge", headers=self.headers)
            response.raise_for_status()
            print("✅ 确认报警成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  确认报警失败: {e}")
        
        # 解决报警
        total_tests += 1
        try:
            response = await self.client.patch(f"/api/alerts/{self.test_data['alert_id']}/resolve", headers=self.headers)
            response.raise_for_status()
            print("✅ 解决报警成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  解决报警失败: {e}")
        
        # 关闭报警
        total_tests += 1
        try:
            response = await self.client.patch(f"/api/alerts/{self.test_data['alert_id']}/close", headers=self.headers)
            response.raise_for_status()
            print("✅ 关闭报警成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  关闭报警失败: {e}")
        
        # 获取项目报警统计
        total_tests += 1
        try:
            response = await self.client.get(f"/api/alerts/project/{self.test_data['project_id']}/stats", headers=self.headers)
            response.raise_for_status()
            stats = response.json()
            print(f"✅ 获取项目报警统计: {stats}")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取项目报警统计失败: {e}")
        
        # 获取未解决的报警
        total_tests += 1
        try:
            response = await self.client.get("/api/alerts/recent/unresolved", headers=self.headers)
            response.raise_for_status()
            alerts = response.json()
            print(f"✅ 获取未解决的报警: 共{len(alerts)}个")
            success_count += 1
        except Exception as e:
            print(f"⚠️  获取未解决的报警失败: {e}")
        
        # 测试外部报警创建
        total_tests += 1
        try:
            external_alert_data = {
                "camera_id": self.test_data["camera_id"],
                "alert_level": "normal",
                "alert_type": "external_test",
                "description": "外部系统创建的测试报警",
                "alert_source": "external",
                "external_id": f"ext_test_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            }
            response = await self.client.post("/api/alerts/external", json=external_alert_data)
            response.raise_for_status()
            print("✅ 外部报警创建成功")
            success_count += 1
        except Exception as e:
            print(f"⚠️  外部报警创建失败: {e}")
        
        return success_count >= 3  # 至少基本操作成功

    async def test_audit_logs(self):
        """测试审计日志端点"""
        print("\n📊 测试审计日志端点...")
        
        success_count = 0
        total_tests = 0
        
        # 获取审计日志列表
        total_tests += 1
        try:
            response = await self.client.get("/api/audit-logs/", headers=self.headers)
            if response.status_code == 403:
                print("⚠️  无权限访问审计日志（需要超级管理员权限）")
                return True
            response.raise_for_status()
            logs = response.json()
            print(f"✅ 获取审计日志: 共{len(logs)}条记录")
            
            # 如果有日志，使用第一条日志
            if len(logs) > 0:
                log_id = logs[0]["id"]
                
                # 获取单个审计日志详情
                total_tests += 1
                try:
                    response = await self.client.get(f"/api/audit-logs/{log_id}", headers=self.headers)
                    response.raise_for_status()
                    log_detail = response.json()
                    print(f"✅ 获取审计日志详情: ID {log_id}")
                    success_count += 1
                except Exception as e:
                    print(f"❌ 获取审计日志详情失败: {e}")
            
            success_count += 1
        except Exception as e:
            print(f"❌ 审计日志测试失败: {e}")
            return False
        
        return success_count >= 1  # 至少获取列表成功

    async def test_all_endpoints(self):
        """测试所有API端点"""
        print("=" * 60)
        print("🚀 开始全面测试监控报警系统所有API端点")
        print("=" * 60)
        
        # 登录获取token
        if not await self.login():
            return False
        
        test_results = {}
        
        # 测试各个模块
        test_results["health_check"] = await self.test_health_check()
        test_results["system_info"] = await self.test_system_info()
        test_results["auth_endpoints"] = await self.test_auth_endpoints()
        test_results["project_endpoints"] = await self.test_project_endpoints()
        test_results["area_endpoints"] = await self.test_area_endpoints()
        test_results["camera_endpoints"] = await self.test_camera_endpoints()
        test_results["alert_endpoints"] = await self.test_alert_endpoints()
        test_results["audit_logs"] = await self.test_audit_logs()
        
        # 输出测试总结
        print("\n" + "=" * 60)
        print("📊 全面测试结果总结")
        print("=" * 60)
        
        total_tests = len(test_results)
        passed_tests = sum(1 for result in test_results.values() if result)
        
        for test_name, result in test_results.items():
            status = "✅ 通过" if result else "❌ 失败"
            print(f"{test_name}: {status}")
        
        print(f"\n📈 总计: {passed_tests}/{total_tests} 个测试模块通过")
        
        if passed_tests == total_tests:
            print("🎉 所有API测试模块通过！")
        else:
            print("⚠️  部分测试模块失败，请检查API服务状态")
        
        return passed_tests == total_tests

    async def close(self):
        """关闭客户端连接"""
        await self.client.aclose()

async def main():
    """主函数"""
    tester = ComprehensiveAPITester()
    try:
        success = await tester.test_all_endpoints()
        exit_code = 0 if success else 1
    except Exception as e:
        print(f"💥 测试过程中发生异常: {e}")
        exit_code = 1
    finally:
        await tester.close()
    
    return exit_code

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)