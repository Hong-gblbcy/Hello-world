#!/usr/bin/env python3
"""
监控报警系统API全面测试脚本
测试所有http://localhost:8000/docs中的API端点
"""

import asyncio
import httpx
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List

# API基础配置
BASE_URL = "http://localhost:8000"
LOGIN_CREDENTIALS = {
    "username": "admin",
    "password": "admin123"
}

class APITester:
    def __init__(self):
        self.client = httpx.AsyncClient(base_url=BASE_URL)
        self.token = None
        self.headers = {}
        self.test_data = {
            "project_id": None,
            "area_id": None,
            "camera_id": None,
            "alert_id": None,
            "user_id": None
        }

    async def login(self):
        """登录获取访问令牌"""
        print("🔐 正在登录...")
        try:
            response = await self.client.post(
                "/api/auth/login",
                data={
                    "username": LOGIN_CREDENTIALS["username"],
                    "password": LOGIN_CREDENTIALS["password"],
                    "grant_type": "password"
                }
            )
            response.raise_for_status()
            token_data = response.json()
            self.token = token_data["access_token"]
            self.headers = {"Authorization": f"Bearer {self.token}"}
            print("✅ 登录成功")
            return True
        except Exception as e:
            print(f"❌ 登录失败: {e}")
            return False

    async def test_health_check(self):
        """测试健康检查端点"""
        print("\n🏥 测试健康检查...")
        try:
            response = await self.client.get("/health")
            response.raise_for_status()
            print(f"✅ 健康检查: {response.json()}")
            return True
        except Exception as e:
            print(f"❌ 健康检查失败: {e}")
            return False

    async def test_system_info(self):
        """测试系统信息端点"""
        print("\nℹ️  测试系统信息...")
        try:
            response = await self.client.get("/system/info")
            response.raise_for_status()
            print(f"✅ 系统信息: {response.json()}")
            return True
        except Exception as e:
            print(f"❌ 系统信息失败: {e}")
            return False

    async def test_auth_endpoints(self):
        """测试认证相关端点"""
        print("\n🔐 测试认证端点...")
        
        # 获取当前用户信息
        try:
            response = await self.client.get("/api/auth/me", headers=self.headers)
            response.raise_for_status()
            user_info = response.json()
            self.test_data["user_id"] = user_info["user"]["id"]
            print(f"✅ 获取用户信息: {user_info['user']['username']}")
        except Exception as e:
            print(f"❌ 获取用户信息失败: {e}")
            return False

        # 获取所有用户（需要超级管理员权限）
        try:
            response = await self.client.get("/api/auth/users", headers=self.headers)
            response.raise_for_status()
            users = response.json()
            print(f"✅ 获取用户列表: 共{len(users)}个用户")
        except Exception as e:
            print(f"⚠️  获取用户列表失败（可能权限不足）: {e}")

        return True

    async def test_project_endpoints(self):
        """测试项目相关端点"""
        print("\n📁 测试项目管理端点...")
        
        # 获取项目列表
        try:
            response = await self.client.get("/api/projects", headers=self.headers)
            response.raise_for_status()
            projects = response.json()
            print(f"✅ 获取项目列表: 共{projects['total']}个项目")
            
            # 如果已有项目，使用第一个项目
            if projects["total"] > 0:
                self.test_data["project_id"] = projects["items"][0]["id"]
                print(f"📋 使用现有项目: ID {self.test_data['project_id']}")
                return True
        except Exception as e:
            print(f"❌ 获取项目列表失败: {e}")
            return False

        # 创建新项目
        project_data = {
            "name": f"测试项目_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "description": "自动化测试创建的项目"
        }
        
        try:
            response = await self.client.post(
                "/api/projects",
                json=project_data,
                headers=self.headers
            )
            response.raise_for_status()
            project = response.json()
            self.test_data["project_id"] = project["id"]
            print(f"✅ 创建项目成功: {project['name']} (ID: {project['id']})")
            return True
        except Exception as e:
            print(f"❌ 创建项目失败: {e}")
            return False

    async def test_area_endpoints(self):
        """测试区域相关端点"""
        if not self.test_data["project_id"]:
            print("⚠️  跳过区域测试：无项目ID")
            return False

        print("\n🗺️  测试区域管理端点...")
        
        # 获取区域列表
        try:
            response = await self.client.get(
                f"/api/areas/?project_id={self.test_data['project_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            areas = response.json()
            print(f"✅ 获取区域列表: 共{len(areas)}个区域")
            
            # 如果已有区域，使用第一个区域
            if len(areas) > 0:
                self.test_data["area_id"] = areas[0]["id"]
                print(f"📋 使用现有区域: ID {self.test_data['area_id']}")
                return True
        except Exception as e:
            print(f"❌ 获取区域列表失败: {e}")

        # 创建新区域
        area_data = {
            "name": f"测试区域_{datetime.now().strftime('%H%M%S')}",
            "description": "自动化测试创建的区域",
            "project_id": self.test_data["project_id"]
        }
        
        try:
            response = await self.client.post(
                "/api/areas/",
                json=area_data,
                headers=self.headers
            )
            response.raise_for_status()
            area = response.json()
            self.test_data["area_id"] = area["id"]
            print(f"✅ 创建区域成功: {area['name']} (ID: {area['id']})")
            return True
        except Exception as e:
            print(f"❌ 创建区域失败: {e}")
            return False

    async def test_camera_endpoints(self):
        """测试摄像头相关端点"""
        if not self.test_data["area_id"]:
            print("⚠️  跳过摄像头测试：无区域ID")
            return False

        print("\n📷 测试摄像头管理端点...")
        
        # 获取摄像头列表
        try:
            response = await self.client.get(
                f"/api/cameras/?area_id={self.test_data['area_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            cameras = response.json()
            print(f"✅ 获取摄像头列表: 共{len(cameras)}个摄像头")
            
            # 如果已有摄像头，使用第一个摄像头
            if len(cameras) > 0:
                self.test_data["camera_id"] = cameras[0]["id"]
                print(f"📋 使用现有摄像头: ID {self.test_data['camera_id']}")
                return True
        except Exception as e:
            print(f"❌ 获取摄像头列表失败: {e}")

        # 创建新摄像头
        camera_data = {
            "name": f"测试摄像头_{datetime.now().strftime('%H%M%S')}",
            "description": "自动化测试创建的摄像头",
            "stream_url": "rtsp://test.example.com/stream",
            "area_id": self.test_data["area_id"],
            "project_id": self.test_data["project_id"],
            "alert_level": "normal"
        }
        
        try:
            response = await self.client.post(
                "/api/cameras/",
                json=camera_data,
                headers=self.headers
            )
            response.raise_for_status()
            camera = response.json()
            self.test_data["camera_id"] = camera["id"]
            print(f"✅ 创建摄像头成功: {camera['name']} (ID: {camera['id']})")
            return True
        except Exception as e:
            print(f"❌ 创建摄像头失败: {e}")
            return False

    async def test_alert_endpoints(self):
        """测试报警相关端点"""
        if not self.test_data["camera_id"]:
            print("⚠️  跳过报警测试：无摄像头ID")
            return False

        print("\n🚨 测试报警管理端点...")
        
        # 获取报警列表
        try:
            response = await self.client.get(
                f"/api/alerts/?camera_id={self.test_data['camera_id']}",
                headers=self.headers
            )
            response.raise_for_status()
            alerts = response.json()
            print(f"✅ 获取报警列表: 共{len(alerts)}个报警")
            
            # 如果已有报警，使用第一个报警
            if len(alerts) > 0:
                self.test_data["alert_id"] = alerts[0]["id"]
                print(f"📋 使用现有报警: ID {self.test_data['alert_id']}")
                return True
        except Exception as e:
            print(f"❌ 获取报警列表失败: {e}")

        # 创建新报警
        alert_data = {
            "alert_type": "motion",
            "description": "自动化测试创建的报警",
            "alert_level": "normal",
            "camera_id": self.test_data["camera_id"]
        }
        
        try:
            response = await self.client.post(
                "/api/alerts/",
                json=alert_data,
                headers=self.headers
            )
            response.raise_for_status()
            alert = response.json()
            self.test_data["alert_id"] = alert["id"]
            print(f"✅ 创建报警成功: {alert['alert_type']} (ID: {alert['id']})")
            return True
        except Exception as e:
            print(f"❌ 创建报警失败: {e}")
            return False

    async def test_audit_logs(self):
        """测试审计日志端点"""
        print("\n📊 测试审计日志端点...")
        
        try:
            response = await self.client.get("/api/audit-logs/", headers=self.headers)
            if response.status_code == 403:
                print("⚠️  无权限访问审计日志（需要超级管理员权限）")
                return True
            response.raise_for_status()
            logs = response.json()
            print(f"✅ 获取审计日志: 共{len(logs)}条记录")
            return True
        except Exception as e:
            print(f"❌ 审计日志测试失败: {e}")
            return False

    async def test_all_endpoints(self):
        """测试所有API端点"""
        print("=" * 60)
        print("🚀 开始测试监控报警系统所有API端点")
        print("=" * 60)
        
        # 登录获取token
        if not await self.login():
            return False
        
        test_results = {}
        
        # 测试各个模块
        test_results["health_check"] = await self.test_health_check()
        test_results["system_info"] = await self.test_system_info()
        test_results["auth_endpoints"] = await self.test_auth_endpoints()
        test_results["project_endpoints"] = await self.test_project_endpoints()
        test_results["area_endpoints"] = await self.test_area_endpoints()
        test_results["camera_endpoints"] = await self.test_camera_endpoints()
        test_results["alert_endpoints"] = await self.test_alert_endpoints()
        test_results["audit_logs"] = await self.test_audit_logs()
        
        # 输出测试总结
        print("\n" + "=" * 60)
        print("📊 测试结果总结")
        print("=" * 60)
        
        total_tests = len(test_results)
        passed_tests = sum(test_results.values())
        
        for test_name, result in test_results.items():
            status = "✅ 通过" if result else "❌ 失败"
            print(f"{test_name}: {status}")
        
        print(f"\n📈 总计: {passed_tests}/{total_tests} 个测试通过")
        
        if passed_tests == total_tests:
            print("🎉 所有API测试通过！")
        else:
            print("⚠️  部分测试失败，请检查API服务状态")
        
        return passed_tests == total_tests

    async def close(self):
        """关闭客户端连接"""
        await self.client.aclose()

async def main():
    """主函数"""
    tester = APITester()
    try:
        success = await tester.test_all_endpoints()
        exit_code = 0 if success else 1
    except Exception as e:
        print(f"💥 测试过程中发生异常: {e}")
        exit_code = 1
    finally:
        await tester.close()
    
    return exit_code

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)